"""Contains `sharp train` CLI implementation.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import copy
import logging
import pathlib
import sys

import click
import torch

from sharp.utils import logging as logging_utils

LOGGER = logging.getLogger(__name__)

SUPPORTED_DEVICE_TYPES = {"cpu", "mps", "cuda"}


def _load_predictor_weights(
    predictor: torch.nn.Module,
    weights_path: pathlib.Path,
    *,
    label: str,
) -> None:
    """Load either raw predictor state_dict or a training checkpoint."""
    raw = torch.load(weights_path, map_location="cpu", weights_only=True)
    state_dict = raw.get("model_state_dict", raw) if isinstance(raw, dict) else raw
    if not isinstance(state_dict, dict):
        raise click.ClickException(f"{label} weights are not a state_dict: {weights_path}")
    missing, unexpected = predictor.load_state_dict(state_dict, strict=False)
    if missing:
        LOGGER.warning("%s load: %d missing keys (e.g. %s)", label, len(missing), missing[:3])
    if unexpected:
        LOGGER.warning(
            "%s load: %d unexpected keys (e.g. %s)", label, len(unexpected), unexpected[:3]
        )


def _resolve_device(device_str: str) -> torch.device:
    """Resolve a device string to a torch.device, validating availability.

    Mirrors the device resolution logic in predict.py: if "default" is given,
    auto-selects cuda > mps > cpu. Otherwise validates the user's selection.

    Args:
        device_str: One of "default", "cpu", "mps", "cuda", or an indexed CUDA
            device such as "cuda:0".

    Returns:
        A torch.device for the resolved device.

    Raises:
        click.ClickException: If the device type is unsupported or unavailable.
    """
    if device_str == "default":
        if torch.cuda.is_available():
            return torch.device("cuda", torch.cuda.current_device())
        elif torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            return torch.device("cpu")

    try:
        resolved = torch.device(device_str)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(
            f"Unsupported device type '{device_str}'. "
            f"Supported device types: {sorted(SUPPORTED_DEVICE_TYPES)}"
        ) from exc

    if resolved.type not in SUPPORTED_DEVICE_TYPES:
        raise click.ClickException(
            f"Unsupported device type '{device_str}'. "
            f"Supported device types: {sorted(SUPPORTED_DEVICE_TYPES)}"
        )

    # Check availability
    if resolved.type == "cuda" and not torch.cuda.is_available():
        raise click.ClickException(
            f"Device 'cuda' is not available on this host. "
            f"No CUDA-capable GPU was detected."
        )
    if resolved.type == "cuda" and resolved.index is not None:
        device_count = torch.cuda.device_count()
        if resolved.index >= device_count:
            raise click.ClickException(
                f"Device '{device_str}' is not available on this host. "
                f"Detected {device_count} CUDA device(s)."
            )
    if resolved.type == "mps" and not torch.backends.mps.is_available():
        raise click.ClickException(
            f"Device 'mps' is not available on this host. "
            f"MPS backend is not supported on this system."
        )

    if resolved.type == "cuda" and resolved.index is None:
        resolved = torch.device("cuda", torch.cuda.current_device())
    return resolved


@click.command()
@click.option(
    "--config",
    "config_path",
    type=click.Path(path_type=pathlib.Path, dir_okay=False),
    required=True,
    help="Path to a JSON or YAML training configuration file.",
)
@click.option(
    "--output-dir",
    type=click.Path(path_type=pathlib.Path, file_okay=False),
    required=True,
    help="Directory for checkpoint files and training logs.",
)
@click.option(
    "--resume",
    "resume_path",
    type=click.Path(path_type=pathlib.Path, dir_okay=False),
    default=None,
    help="Path to a checkpoint file to resume training from.",
)
@click.option(
    "--stage",
    type=click.Choice(["stage1", "stage2"], case_sensitive=False),
    default=None,
    help="Training stage: stage1 (synthetic GT) or stage2 (self-supervised).",
)
@click.option(
    "--device",
    type=str,
    default="default",
    help="Device to run on: cpu, mps, cuda, or default (auto-detect).",
)
@click.option(
    "--data-root",
    type=click.Path(path_type=pathlib.Path, file_okay=True),
    default=None,
    help="Stage 1 dataset root, or Stage 2 real-image file/directory.",
)
@click.option(
    "--init-weights",
    "init_weights_path",
    type=click.Path(path_type=pathlib.Path, dir_okay=False),
    default=None,
    help="Pretrained SHARP .pt (raw state_dict) to initialize the predictor for fine-tuning.",
)
@click.option(
    "--teacher-weights",
    "teacher_weights_path",
    type=click.Path(path_type=pathlib.Path, dir_okay=False),
    default=None,
    help="Frozen Stage-1 teacher weights for Stage 2 SSFT. Defaults to --init-weights.",
)
@click.option(
    "--pairs-per-scene",
    type=int,
    default=4,
    help="Number of (source, target) view pairs sampled per scene per epoch.",
)
@click.option(
    "--max-steps",
    type=int,
    default=None,
    help="Cap total training steps (smoke test). Overrides config when smaller.",
)
@click.option(
    "--log-every",
    type=int,
    default=1,
    help="Log per-step loss every N steps (0 disables).",
)
@click.option("-v", "--verbose", is_flag=True, help="Activate debug logs.")
def train_cli(
    config_path: pathlib.Path,
    output_dir: pathlib.Path,
    resume_path: pathlib.Path | None,
    stage: str | None,
    device: str,
    data_root: pathlib.Path | None,
    init_weights_path: pathlib.Path | None,
    teacher_weights_path: pathlib.Path | None,
    pairs_per_scene: int,
    max_steps: int | None,
    log_every: int,
    verbose: bool,
) -> None:
    """Train the SHARP model."""
    logging_utils.configure(logging.DEBUG if verbose else logging.INFO)

    # --- Validate config before any work (Req 1.7) ---
    try:
        from sharp.training.config import load_training_config

        config = load_training_config(config_path)
    except (FileNotFoundError, ValueError, ImportError) as e:
        raise click.ClickException(
            f"Invalid configuration: {e}"
        ) from e

    # --- Override stage if specified on CLI (Req 1.4) ---
    if stage is not None:
        config.stage.name = stage
        if stage == "stage1":
            config.stage.total_steps = 100000
        elif stage == "stage2":
            config.stage.total_steps = 60000

    # --- Cap total steps for a smoke run (Req: fast feasibility check) ---
    if max_steps is not None and max_steps > 0:
        config.stage.total_steps = min(config.stage.total_steps, max_steps)

    # --- Validate resume checkpoint before any work (Req 1.8) ---
    resume_step = 0
    resume_checkpoint = None
    if resume_path is not None:
        if not resume_path.exists():
            raise click.ClickException(
                f"Resume checkpoint does not exist: {resume_path}"
            )
        if not resume_path.is_file():
            raise click.ClickException(
                f"Resume checkpoint is not a file: {resume_path}"
            )
        try:
            # Attempt to read and validate the checkpoint
            from sharp.training.checkpoint import CheckpointManager

            mgr = CheckpointManager(
                output_dir=output_dir,
                checkpoint_interval=config.checkpoint_interval,
            )
            resume_checkpoint = mgr.load(resume_path)
            resume_step = resume_checkpoint["step"]
        except (FileNotFoundError, ValueError, RuntimeError, Exception) as e:
            raise click.ClickException(
                f"Cannot load resume checkpoint: {e}"
            ) from e

    # --- Resolve and validate device (Req 1.5, 1.9, 22.2) ---
    resolved_device = _resolve_device(device)

    # --- Check renderer+CUDA constraint (Req 1.6, 22.3) ---
    if config.requires_renderer and resolved_device.type != "cuda":
        raise click.ClickException(
            "Differentiable rendering requires a CUDA device, "
            f"but selected device is '{resolved_device.type}'. "
            "Set requires_renderer=False in config or select a CUDA device."
        )

    # --- Validate data root before any work ---
    if data_root is None:
        raise click.ClickException("--data-root is required to build the training pipeline.")
    if not data_root.exists():
        raise click.ClickException(f"Dataset root invalid (does not exist): {data_root}")
    if config.stage.name == "stage1" and not (data_root / "stage1_manifest.json").exists():
        raise click.ClickException(
            f"Dataset root invalid (missing stage1_manifest.json): {data_root}"
        )

    # --- Validate init-weights before any work ---
    if init_weights_path is not None and not init_weights_path.is_file():
        raise click.ClickException(
            f"Pretrained weights file not found: {init_weights_path}"
        )

    stage2_teacher_path = teacher_weights_path or init_weights_path
    if config.stage.name == "stage2":
        if stage2_teacher_path is None:
            raise click.ClickException(
                "Stage 2 requires --teacher-weights or --init-weights for the frozen teacher."
            )
        if not stage2_teacher_path.is_file():
            raise click.ClickException(
                f"Stage 2 teacher weights file not found: {stage2_teacher_path}"
            )

    # --- All validation passed: create output directory (Req 1.2) ---
    output_dir.mkdir(parents=True, exist_ok=True)
    LOGGER.info("Output directory: %s", output_dir)
    LOGGER.info("Using device: %s", resolved_device)
    LOGGER.info("Stage: %s (total_steps=%d)", config.stage.name, config.stage.total_steps)

    if resume_path is not None:
        LOGGER.info("Resuming from checkpoint: %s (step %d)", resume_path, resume_step)

    # --- Build model and training loop ---
    from sharp.models import create_predictor
    from sharp.training.loop import TrainingLoop

    predictor = create_predictor(copy.deepcopy(config.predictor))

    # Initialize from a pretrained SHARP checkpoint for fine-tuning (raw
    # state_dict, the same format the predict CLI loads).
    if init_weights_path is not None:
        LOGGER.info("Initializing predictor from pretrained weights: %s", init_weights_path)
        _load_predictor_weights(predictor, init_weights_path, label="Pretrained")

    # Restore model weights from a training checkpoint if resuming
    if resume_checkpoint is not None:
        predictor.load_state_dict(resume_checkpoint["model_state_dict"])
        LOGGER.info("Restored model weights from checkpoint.")

    # Create renderer (only when required and on CUDA)
    renderer = None
    if config.requires_renderer:
        from sharp.utils.gsplat import GSplatRenderer

        renderer = GSplatRenderer()

    # Instantiate the training loop
    loop = TrainingLoop(
        config=config,
        predictor=predictor,
        renderer=renderer,
        device=resolved_device,
        output_dir=output_dir,
        resume_step=resume_step,
    )

    # Restore optimizer state if resuming
    if resume_checkpoint is not None:
        loop.optim_scheduler.optimizer.load_state_dict(
            resume_checkpoint["optimizer_state_dict"]
        )
        LOGGER.info("Restored optimizer state from checkpoint.")

    # --- Build data pipeline and run ---
    from sharp.training.data_sources import RealImageSource, Stage1SceneSource
    from sharp.training.pipeline import Stage1_Pipeline, Stage2_Pipeline, Stage2ReplayPipeline

    if config.stage.name == "stage2":
        from sharp.models import create_predictor as create_teacher_predictor
        from sharp.training.ssft import FrozenTeacherPseudoViewGenerator

        source = RealImageSource(data_root, shuffle=True, seed=0)
        teacher = create_teacher_predictor(copy.deepcopy(config.predictor))
        assert stage2_teacher_path is not None
        LOGGER.info("Loading frozen Stage-1 teacher weights: %s", stage2_teacher_path)
        _load_predictor_weights(teacher, stage2_teacher_path, label="Teacher")
        pseudo_view_generator = FrozenTeacherPseudoViewGenerator(
            teacher=teacher,
            renderer=renderer,
            resolution=config.internal_resolution,
            max_disparity=config.stage.pseudo_view_max_disparity,
            pose_strategy=config.stage.pseudo_view_pose_strategy,
            device=resolved_device,
        )
        pipeline = Stage2_Pipeline(
            source=source,
            pseudo_view_generator=pseudo_view_generator,
            total_steps=config.stage.total_steps,
            resolution=config.internal_resolution,
            pseudo_depth_mode=config.stage.pseudo_depth_mode,
            pseudo_depth_alpha_threshold=config.stage.pseudo_depth_alpha_threshold,
            pseudo_view_disparities=config.stage.pseudo_view_disparities,
            pseudo_view_pose_strategy=config.stage.pseudo_view_pose_strategy,
        )
        source_count = len(source)
        if config.stage.stage1_replay_data_root:
            replay_root = pathlib.Path(config.stage.stage1_replay_data_root)
            if not replay_root.is_absolute():
                replay_root = config_path.parent / replay_root
            if not replay_root.exists():
                raise click.ClickException(
                    f"Stage-1 replay data root does not exist: {replay_root}"
                )
            replay_source = Stage1SceneSource(
                replay_root,
                pairs_per_scene=config.stage.stage1_replay_pairs_per_scene,
                seed=0,
            )
            replay_pipeline = Stage1_Pipeline(
                source=replay_source,
                total_steps=config.stage.total_steps,
                resolution=config.internal_resolution,
            )
            pipeline = Stage2ReplayPipeline(
                stage2_pipeline=pipeline,
                stage1_pipeline=replay_pipeline,
                stage1_replay_ratio=config.stage.stage1_replay_ratio,
                total_steps=config.stage.total_steps,
            )
            LOGGER.info(
                "Stage-1 synthetic replay enabled: root=%s scenes=%d ratio=%.3f pairs/scene=%d",
                replay_root,
                len(replay_source.scenes),
                config.stage.stage1_replay_ratio,
                config.stage.stage1_replay_pairs_per_scene,
            )
    else:
        source = Stage1SceneSource(
            data_root, pairs_per_scene=pairs_per_scene, seed=0
        )
        pipeline = Stage1_Pipeline(
            source=source,
            total_steps=config.stage.total_steps,
            resolution=config.internal_resolution,
        )
        source_count = len(source.scenes)

    loop.log_every = log_every
    LOGGER.info(
        "Starting training: stage=%s source_items=%d pairs/scene=%d resolution=%d total_steps=%d",
        config.stage.name,
        source_count,
        pairs_per_scene,
        config.internal_resolution,
        config.stage.total_steps,
    )
    loop.run(pipeline)
    LOGGER.info("Training finished at step %d.", loop.step_counter)
