"""Camera handling for the SHARP training framework.

Provides ViewCameras (source/target intrinsics and extrinsics) and CameraModule
for computing relative transforms, baked projections, and per-view camera
parameters consumed by the GSplatRenderer.

All matrices follow the OpenCV convention (right-handed, +Z forward, +X right,
+Y down). Extrinsics are world-to-camera transforms (4x4), intrinsics are 3x3.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses

import torch


@dataclasses.dataclass
class ViewCameras:
    """Source and target camera parameters for a training sample.

    All tensors are batched with leading dimension B.

    Attributes:
        k_src: Source intrinsics [B, 3, 3].
        e_src: Source extrinsics (world->cam) [B, 4, 4], OpenCV convention.
        k_tgt: Target intrinsics [B, 3, 3].
        e_tgt: Target extrinsics (world->cam) [B, 4, 4], OpenCV convention.
    """

    k_src: torch.Tensor | None = None  # [B, 3, 3]
    e_src: torch.Tensor | None = None  # [B, 4, 4]
    k_tgt: torch.Tensor | None = None  # [B, 3, 3]
    e_tgt: torch.Tensor | None = None  # [B, 4, 4]


class CameraValidationError(ValueError):
    """Raised when camera parameters fail validation."""

    pass


class CameraModule:
    """Computes camera transforms for dual-view training rendering.

    The renderer (GSplatRenderer) consumes separate extrinsics and intrinsics.
    Because composer Gaussians live in the source camera frame:
      - Input view renders with (E=I, K=Ksrc).
      - Novel view renders with (E=Etgt·Esrc⁻¹, K=Ktgt).

    The baked projection P = Ktgt·Etgt·Esrc⁻¹·Ksrc⁻¹ is composed explicitly
    for the ViewMasker back-projection; the decomposed form is mathematically
    equivalent for rendering.
    """

    # Condition number threshold for singularity detection.
    _CONDITION_THRESHOLD: float = 1e7

    def relative_extrinsics(self, cams: ViewCameras) -> torch.Tensor:
        """Compute the relative extrinsics E_rel = Etgt @ inv(Esrc).

        Args:
            cams: ViewCameras with valid e_src and e_tgt.

        Returns:
            Relative extrinsics [B, 4, 4].
        """
        # E_rel = Etgt @ Esrc^{-1}
        e_src_inv = torch.linalg.inv(cams.e_src)
        return cams.e_tgt @ e_src_inv

    def baked_projection(self, cams: ViewCameras) -> torch.Tensor:
        """Compute the baked projection P = Ktgt · Etgt · Esrc⁻¹ · Ksrc⁻¹.

        This maps source-camera-space points (after Ksrc⁻¹ un-projects from
        pixel coords) through the relative transform and re-projects with Ktgt.

        We embed the 3x3 intrinsics into 4x4 matrices for consistent
        multiplication with the 4x4 extrinsics.

        Args:
            cams: ViewCameras with all four parameters set.

        Returns:
            Baked projection matrix [B, 4, 4].
        """
        B = cams.k_src.shape[0]
        device = cams.k_src.device
        dtype = cams.k_src.dtype

        # Embed 3x3 intrinsics into 4x4
        k_src_4x4 = torch.eye(4, device=device, dtype=dtype).unsqueeze(0).expand(B, -1, -1).clone()
        k_src_4x4[:, :3, :3] = cams.k_src

        k_tgt_4x4 = torch.eye(4, device=device, dtype=dtype).unsqueeze(0).expand(B, -1, -1).clone()
        k_tgt_4x4[:, :3, :3] = cams.k_tgt

        e_src_inv = torch.linalg.inv(cams.e_src)
        k_src_inv = torch.linalg.inv(k_src_4x4)

        # P = Ktgt · Etgt · Esrc⁻¹ · Ksrc⁻¹
        P = k_tgt_4x4 @ cams.e_tgt @ e_src_inv @ k_src_inv
        return P

    def input_view(self, cams: ViewCameras) -> tuple[torch.Tensor, torch.Tensor]:
        """Return camera parameters for the input-view render.

        The input view uses identity extrinsics (Gaussians are already in the
        source frame) and source intrinsics.

        Args:
            cams: ViewCameras with valid k_src.

        Returns:
            Tuple of (extrinsics [B, 4, 4], intrinsics [B, 3, 3]) where
            extrinsics is the identity matrix.
        """
        B = cams.k_src.shape[0]
        device = cams.k_src.device
        dtype = cams.k_src.dtype

        # Identity 4x4 extrinsics
        identity = torch.eye(4, device=device, dtype=dtype).unsqueeze(0).expand(B, -1, -1)
        return identity, cams.k_src

    def novel_view(self, cams: ViewCameras) -> tuple[torch.Tensor, torch.Tensor]:
        """Return camera parameters for the novel-view render.

        The novel view uses relative extrinsics E_rel = Etgt·Esrc⁻¹ and
        target intrinsics Ktgt.

        Args:
            cams: ViewCameras with valid e_src, e_tgt, k_tgt.

        Returns:
            Tuple of (extrinsics [B, 4, 4], intrinsics [B, 3, 3]).
        """
        e_rel = self.relative_extrinsics(cams)
        return e_rel, cams.k_tgt

    def validate(self, cams: ViewCameras) -> None:
        """Validate camera parameters before rendering.

        Checks for missing parameters and non-invertible (singular) matrices.
        Raises CameraValidationError if validation fails.

        Args:
            cams: ViewCameras to validate.

        Raises:
            CameraValidationError: If any parameter is missing or singular.
        """
        # Check for missing parameters (Req 3.5)
        missing = []
        if cams.k_src is None:
            missing.append("k_src")
        if cams.e_src is None:
            missing.append("e_src")
        if cams.k_tgt is None:
            missing.append("k_tgt")
        if cams.e_tgt is None:
            missing.append("e_tgt")

        if missing:
            raise CameraValidationError(
                f"Missing camera parameters: {', '.join(missing)}. "
                f"Cannot compose projection without all four parameters."
            )

        # Check singularity of Esrc via slogdet (Req 3.6)
        self._check_singularity(cams.e_src, "e_src")

        # Check singularity of Ksrc via slogdet on the 3x3 intrinsics (Req 3.6)
        self._check_singularity_3x3(cams.k_src, "k_src")

    def _check_singularity(self, matrix: torch.Tensor, name: str) -> None:
        """Check a 4x4 matrix for singularity using slogdet and condition number.

        Args:
            matrix: [B, 4, 4] tensor.
            name: Name for error reporting.

        Raises:
            CameraValidationError: If the matrix is singular or ill-conditioned.
        """
        # slogdet check: sign == 0 means singular
        sign, logabsdet = torch.linalg.slogdet(matrix)
        if (sign == 0).any():
            raise CameraValidationError(
                f"Camera parameter '{name}' is singular (determinant is zero). "
                f"Cannot invert for projection computation."
            )

        # Condition number check for near-singular matrices
        cond = torch.linalg.cond(matrix)
        if (cond > self._CONDITION_THRESHOLD).any():
            raise CameraValidationError(
                f"Camera parameter '{name}' is ill-conditioned "
                f"(condition number > {self._CONDITION_THRESHOLD:.0e}). "
                f"Matrix may be numerically non-invertible."
            )

    def _check_singularity_3x3(self, matrix: torch.Tensor, name: str) -> None:
        """Check a 3x3 matrix for singularity using slogdet and condition number.

        Args:
            matrix: [B, 3, 3] tensor.
            name: Name for error reporting.

        Raises:
            CameraValidationError: If the matrix is singular or ill-conditioned.
        """
        sign, logabsdet = torch.linalg.slogdet(matrix)
        if (sign == 0).any():
            raise CameraValidationError(
                f"Camera parameter '{name}' is singular (determinant is zero). "
                f"Cannot invert for projection computation."
            )

        cond = torch.linalg.cond(matrix)
        if (cond > self._CONDITION_THRESHOLD).any():
            raise CameraValidationError(
                f"Camera parameter '{name}' is ill-conditioned "
                f"(condition number > {self._CONDITION_THRESHOLD:.0e}). "
                f"Matrix may be numerically non-invertible."
            )
