"""Training loop for the SHARP training framework.

Orchestrates pipeline → forward → dual render → aggregate → backward →
optimizer/scheduler step → checkpoint. Places all sample tensors, model params,
and loss tensors on a single selected device. Rejects device mismatch at
backward. Rejects samples with non-finite renderer output without updating
params.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import logging
import pathlib
from typing import Iterator, Protocol

import torch
import torch.nn as nn

from sharp.training.aggregator import LossAggregator, create_aggregator
from sharp.training.camera import CameraModule
from sharp.training.checkpoint import CheckpointManager
from sharp.training.config import TrainingConfig
from sharp.training.forward import TrainingForward
from sharp.training.freeze import FreezeController
from sharp.training.masking import ViewMasker
from sharp.training.optim import OptimizerScheduler
from sharp.training.step import StepResult, TrainingSample, training_step

logger = logging.getLogger(__name__)


class Pipeline(Protocol):
    """Protocol for data pipelines that yield training samples."""

    def __iter__(self) -> Iterator[TrainingSample]:
        ...

    def __len__(self) -> int:
        ...


def _move_sample_to_device(
    sample: TrainingSample, device: torch.device
) -> TrainingSample:
    """Move all tensor fields of a TrainingSample to the given device.

    Non-tensor fields (cameras) are left unchanged. None fields are skipped.

    Args:
        sample: The training sample to move.
        device: Target device.

    Returns:
        A new TrainingSample with tensors on the target device.
    """
    from sharp.training.camera import ViewCameras

    def _to_device(t: torch.Tensor | None) -> torch.Tensor | None:
        if t is None:
            return None
        return t.to(device)

    # Move camera tensors too
    cameras = sample.cameras
    moved_cameras = ViewCameras(
        k_src=_to_device(cameras.k_src),
        e_src=_to_device(cameras.e_src),
        k_tgt=_to_device(cameras.k_tgt),
        e_tgt=_to_device(cameras.e_tgt),
    )

    return TrainingSample(
        input_image=sample.input_image.to(device),
        novel_image=sample.novel_image.to(device),
        cameras=moved_cameras,
        disparity_factor=sample.disparity_factor.to(device),
        input_depth=_to_device(sample.input_depth),
        input_disparity=_to_device(sample.input_disparity),
        novel_foreground_mask=_to_device(sample.novel_foreground_mask),
    )


def _check_device_consistency(
    sample: TrainingSample,
    predictor: nn.Module,
    device: torch.device,
) -> None:
    """Verify all tensors reside on the expected device before backward.

    Raises RuntimeError identifying the mismatch if any tensor is on a
    different device (Req 22.5).

    Args:
        sample: Current training sample (already moved).
        predictor: The model whose parameters are checked.
        device: The expected device.

    Raises:
        RuntimeError: If a tensor is found on the wrong device.
    """
    # Check model parameters
    for name, param in predictor.named_parameters():
        if param.device != device:
            raise RuntimeError(
                f"Device mismatch: model parameter '{name}' resides on "
                f"{param.device} but training device is {device}. "
                f"All tensors must be on the single selected device."
            )

    # Check sample tensors
    sample_tensors: dict[str, torch.Tensor] = {
        "input_image": sample.input_image,
        "novel_image": sample.novel_image,
        "disparity_factor": sample.disparity_factor,
    }
    if sample.cameras.k_src is not None:
        sample_tensors["cameras.k_src"] = sample.cameras.k_src
    if sample.cameras.e_src is not None:
        sample_tensors["cameras.e_src"] = sample.cameras.e_src
    if sample.cameras.k_tgt is not None:
        sample_tensors["cameras.k_tgt"] = sample.cameras.k_tgt
    if sample.cameras.e_tgt is not None:
        sample_tensors["cameras.e_tgt"] = sample.cameras.e_tgt
    if sample.input_depth is not None:
        sample_tensors["input_depth"] = sample.input_depth

    for tensor_name, tensor in sample_tensors.items():
        if tensor.device != device:
            raise RuntimeError(
                f"Device mismatch: sample tensor '{tensor_name}' resides on "
                f"{tensor.device} but training device is {device}. "
                f"All tensors must be on the single selected device."
            )


def _check_render_finite(result: StepResult) -> bool:
    """Check if the training step succeeded (renderer output was finite).

    Args:
        result: The StepResult from training_step.

    Returns:
        True if the step succeeded (all outputs finite), False otherwise.
    """
    return result.success


class TrainingLoop:
    """Orchestrates the full SHARP training loop.

    Manages:
    - Device placement of model and data
    - FreezeController to set up trainable parameters
    - OptimizerScheduler for Adam + warmup/cosine LR
    - CheckpointManager for periodic saving
    - LossAggregator for combining loss terms
    - The per-step flow: forward → render → loss → backward → optimizer

    Attributes:
        config: Training configuration.
        predictor: The model (moved to device at init).
        renderer: The GSplat renderer.
        device: Target torch device.
        training_forward: Gradient-enabled forward wrapper.
        freeze_controller: Parameter freeze/unfreeze manager.
        optim_scheduler: Optimizer and LR scheduler.
        checkpoint_manager: Periodic checkpoint saver.
        aggregator: Loss term combiner.
        camera_module: Camera parameter handler.
        view_masker: View-frustum mask computation.
        step_counter: Current training step (0-indexed).
    """

    def __init__(
        self,
        config: TrainingConfig,
        predictor: nn.Module,
        renderer: object,
        device: torch.device,
        *,
        output_dir: pathlib.Path | str = "output",
        resume_step: int = 0,
    ) -> None:
        """Initialize the training loop.

        Sets up all components:
        1. Moves model to device
        2. Applies freeze policy
        3. Creates optimizer/scheduler over trainable params
        4. Sets up checkpoint manager
        5. Creates loss aggregator with stage configuration

        Args:
            config: Full training configuration.
            predictor: The RGBGaussianPredictor model.
            renderer: The GSplatRenderer for dual-view rendering.
            device: Target device (cpu, mps, or cuda).
            output_dir: Directory for checkpoint files.
            resume_step: Step to resume from (0 for fresh start).

        Raises:
            RuntimeError: If device is unsupported or renderer requires CUDA
                but device is not CUDA.
        """
        self.config = config
        self.device = device
        self.renderer = renderer
        self.output_dir = pathlib.Path(output_dir)

        # --- Validate device (Req 22.2, 22.3) ---
        supported_devices = {"cpu", "mps", "cuda"}
        if device.type not in supported_devices:
            raise RuntimeError(
                f"Unsupported device type '{device.type}'. "
                f"Supported device types: {sorted(supported_devices)}"
            )

        if config.requires_renderer and device.type != "cuda":
            raise RuntimeError(
                "Differentiable rendering requires a CUDA device, "
                f"but selected device is '{device.type}'. "
                "Set requires_renderer=False in config or select a CUDA device."
            )

        # --- Step 1: Move model to device (Req 22.4) ---
        self.predictor = predictor.to(device)

        # --- Step 2: Apply freeze policy (Req 17) ---
        self.freeze_controller = FreezeController()
        self.freeze_controller.apply(self.predictor, config.freeze)

        # --- Step 3: Create training forward ---
        self.training_forward = TrainingForward(self.predictor)

        # --- Step 4: Create optimizer/scheduler (Req 18) ---
        trainable_params = list(
            self.freeze_controller.trainable_parameters(self.predictor)
        )
        self.optim_scheduler = OptimizerScheduler(
            parameters=iter(trainable_params),
            config=config.optim,
            total_steps=config.stage.total_steps,
        )

        # Resume scheduler if needed
        if resume_step > 0:
            self.optim_scheduler.resume(resume_step)

        # --- Step 5: Checkpoint manager (Req 19) ---
        self.checkpoint_manager = CheckpointManager(
            output_dir=self.output_dir,
            checkpoint_interval=config.checkpoint_interval,
        )

        # --- Step 6: Loss aggregator (Req 16) ---
        self.aggregator: LossAggregator = create_aggregator(
            weights=config.losses,
            stage=config.stage,
            device=device,
        )

        # --- Camera module and view masker ---
        self.camera_module = CameraModule()
        self.view_masker = ViewMasker()

        # --- Step counter ---
        self.step_counter = resume_step

        # --- Image dimensions from config ---
        self._image_height = config.internal_resolution
        self._image_width = config.internal_resolution

        # --- Per-step logging cadence (0 disables) ---
        self.log_every = 1

    def run(self, pipeline: Pipeline) -> None:
        """Run the full training loop over the given data pipeline.

        For each sample from the pipeline:
        1. Move sample tensors to device
        2. Verify device consistency
        3. Call training_step (forward → render → mask → loss → backward)
        4. If step failed (non-finite render): skip optimizer, log warning
        5. If step succeeded: optimizer.step(), scheduler.step(), zero_grad()
        6. If checkpoint interval hit: save checkpoint

        Args:
            pipeline: An iterable yielding TrainingSample objects.
        """
        logger.info(
            "Starting training loop on device=%s, from step=%d, "
            "total_steps=%d",
            self.device,
            self.step_counter,
            self.config.stage.total_steps,
        )

        # Zero gradients before the first step
        self.optim_scheduler.zero_grad()

        for sample in pipeline:
            if self.step_counter >= self.config.stage.total_steps:
                logger.info(
                    "Reached total_steps=%d. Stopping.",
                    self.config.stage.total_steps,
                )
                break

            # --- Move sample to device (Req 22.4) ---
            sample = _move_sample_to_device(sample, self.device)

            # --- Device consistency check (Req 22.5) ---
            _check_device_consistency(sample, self.predictor, self.device)

            # --- Execute training step ---
            result: StepResult = training_step(
                sample=sample,
                training_forward=self.training_forward,
                renderer=self.renderer,
                camera_module=self.camera_module,
                view_masker=self.view_masker,
                aggregator=self.aggregator,
                image_height=self._image_height,
                image_width=self._image_width,
            )

            # --- Handle non-finite renderer output (Req 4.3) ---
            if not _check_render_finite(result):
                logger.warning(
                    "Step %d: non-finite renderer output, skipping param "
                    "update. Error: %s",
                    self.step_counter,
                    result.error,
                )
                # Zero out any partial gradients from this failed step
                self.optim_scheduler.zero_grad()
                self.step_counter += 1
                continue

            # --- Optimizer step (Req 18.1) ---
            self.optim_scheduler.step()
            self.optim_scheduler.zero_grad()

            self.step_counter += 1

            # --- Per-step logging (loss visibility for smoke/overfit) ---
            if self.log_every > 0 and (self.step_counter % self.log_every == 0):
                agg = result.aggregate
                total = float(agg.total.detach()) if agg is not None else float("nan")
                terms = ""
                if agg is not None:
                    terms = " ".join(
                        f"{r.name}={float(r.value.detach()):.4f}"
                        for r in agg.records
                        if r.active
                    )
                skipped = (
                    f" skipped={agg.skipped}" if (agg is not None and agg.skipped) else ""
                )
                logger.info(
                    "step %d/%d lr=%.2e loss=%.5f | %s%s",
                    self.step_counter,
                    self.config.stage.total_steps,
                    self.optim_scheduler.get_lr(),
                    total,
                    terms,
                    skipped,
                )

            # --- Checkpoint (Req 19.1) ---
            if self.checkpoint_manager.should_save(self.step_counter):
                ckpt_path = self.checkpoint_manager.save(
                    predictor=self.predictor,
                    optimizer=self.optim_scheduler.optimizer,
                    scheduler_state=self.step_counter,
                    step=self.step_counter,
                )
                logger.info(
                    "Step %d: checkpoint saved to %s",
                    self.step_counter,
                    ckpt_path,
                )

        # Final checkpoint at end of training if not already saved
        if (
            self.step_counter > 0
            and not self.checkpoint_manager.should_save(self.step_counter)
        ):
            ckpt_path = self.checkpoint_manager.save(
                predictor=self.predictor,
                optimizer=self.optim_scheduler.optimizer,
                scheduler_state=self.step_counter,
                step=self.step_counter,
            )
            logger.info(
                "Training complete at step %d. Final checkpoint: %s",
                self.step_counter,
                ckpt_path,
            )

    def run_single_step(self, sample: TrainingSample) -> StepResult:
        """Execute a single training step (useful for testing).

        Moves the sample to device, runs the step, and handles the
        optimizer update. Does NOT manage the step counter or checkpointing.

        Args:
            sample: A single training sample.

        Returns:
            The StepResult from the training step.
        """
        # Move sample to device
        sample = _move_sample_to_device(sample, self.device)

        # Device consistency check
        _check_device_consistency(sample, self.predictor, self.device)

        # Execute training step
        result = training_step(
            sample=sample,
            training_forward=self.training_forward,
            renderer=self.renderer,
            camera_module=self.camera_module,
            view_masker=self.view_masker,
            aggregator=self.aggregator,
            image_height=self._image_height,
            image_width=self._image_width,
        )

        if not result.success:
            # Non-finite output: zero grads, do not update
            self.optim_scheduler.zero_grad()
            return result

        # Successful step: optimizer update
        self.optim_scheduler.step()
        self.optim_scheduler.zero_grad()

        return result
