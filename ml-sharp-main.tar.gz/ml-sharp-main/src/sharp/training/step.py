"""Minimal training step for the SHARP training framework.

Assembles the full forward-backward chain:
TrainingForward → CameraModule → dual forward_train render → ViewMasker →
{ColorLoss, AlphaLoss} → LossAggregator → total.backward()

The function does NOT perform the optimizer step — that is handled by the
training loop.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import TYPE_CHECKING

import torch

from sharp.training.camera import CameraModule, ViewCameras
from sharp.training.forward import TrainingForward
from sharp.training.masking import ViewMasker
from sharp.training.types import AggregateResult, LossContext, RenderTrainOutputs

# The canonical TrainingSample schema lives in pipeline.py. We re-export it here
# so existing imports (`from sharp.training.step import TrainingSample`) keep
# working while there is a single source of truth for the data contract
# (including input_disparity, which the depth loss consumes).
from sharp.training.pipeline import TrainingSample

if TYPE_CHECKING:
    from sharp.training.aggregator import LossAggregator
    from sharp.utils.gsplat import GSplatRenderer

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class StepResult:
    """Result of a single training step.

    Attributes:
        aggregate: The AggregateResult from the loss aggregator (contains
            total loss, per-term records, and skipped term names).
        success: Whether the step completed successfully. False when the
            renderer produced non-finite outputs.
        error: Error message when success is False.
    """

    aggregate: AggregateResult | None
    success: bool = True
    error: str = ""


def training_step(
    sample: TrainingSample,
    training_forward: TrainingForward,
    renderer: GSplatRenderer,
    camera_module: CameraModule,
    view_masker: ViewMasker,
    aggregator: LossAggregator,
    image_height: int,
    image_width: int,
) -> StepResult:
    """Execute one training step: forward, render, loss, backward.

    This function orchestrates the full training data flow for a single sample:
    1. Run TrainingForward to produce Gaussians and intermediates.
    2. Get input-view and novel-view camera params from CameraModule.
    3. Render both views via renderer.forward_train.
    4. Compute the view mask M from novel-view depth via ViewMasker.
    5. Build a LossContext with all pieces.
    6. Call aggregator.aggregate(ctx) to get AggregateResult.
    7. Call total.backward() on the aggregated loss.
    8. Return the AggregateResult.

    The optimizer step is NOT performed here — that is handled by the caller.

    If the renderer raises a RuntimeError (non-finite output), this function
    catches it and returns a failed StepResult without calling backward (so
    model parameters are not updated).

    Args:
        sample: The training sample with images, cameras, and optional depth.
        training_forward: The training-mode forward module.
        renderer: The GSplat renderer with forward_train.
        camera_module: Camera parameter handler.
        view_masker: View-frustum mask computation.
        aggregator: Loss aggregator combining all active loss terms.
        image_height: Render target height.
        image_width: Render target width.

    Returns:
        StepResult with AggregateResult on success, or error info on failure.
    """
    def _batch_image(t: torch.Tensor | None) -> torch.Tensor | None:
        return t if t is None or t.dim() == 4 else t.unsqueeze(0)

    def _batch_map(t: torch.Tensor | None) -> torch.Tensor | None:
        if t is None or t.dim() == 4:
            return t
        if t.dim() == 3:
            return t.unsqueeze(0)
        return t.unsqueeze(0).unsqueeze(0)

    input_image = _batch_image(sample.input_image)
    novel_image = _batch_image(sample.novel_image)
    disparity_factor = sample.disparity_factor
    if disparity_factor.dim() == 0:
        disparity_factor = disparity_factor.reshape(1)
    input_depth = _batch_map(sample.input_depth)
    input_disparity = _batch_map(sample.input_disparity)

    # --- Step 1: Training forward (Req 2.1, 2.2, 2.4) ---
    training_outputs = training_forward(
        image=input_image,
        disparity_factor=disparity_factor,
        depth=input_depth,
    )

    gaussians = training_outputs.gaussians

    # --- Step 2: Camera parameters (Req 3.1–3.4) ---
    input_extrinsics, input_intrinsics = camera_module.input_view(sample.cameras)
    novel_extrinsics, novel_intrinsics = camera_module.novel_view(sample.cameras)

    # --- Step 3: Dual-view rendering (Req 4.1, 4.2) ---
    # Render input view (E=I, K=Ksrc)
    try:
        input_render: RenderTrainOutputs = renderer.forward_train(
            gaussians=gaussians,
            extrinsics=input_extrinsics,
            intrinsics=input_intrinsics,
            image_width=image_width,
            image_height=image_height,
        )
    except RuntimeError as e:
        logger.warning("Input-view render failed: %s", e)
        return StepResult(
            aggregate=None,
            success=False,
            error=f"Input-view render failed: {e}",
        )

    # Render novel view (E=E_rel, K=Ktgt)
    try:
        novel_render: RenderTrainOutputs = renderer.forward_train(
            gaussians=gaussians,
            extrinsics=novel_extrinsics,
            intrinsics=novel_intrinsics,
            image_width=image_width,
            image_height=image_height,
        )
    except RuntimeError as e:
        logger.warning("Novel-view render failed: %s", e)
        return StepResult(
            aggregate=None,
            success=False,
            error=f"Novel-view render failed: {e}",
        )

    # --- Step 4: View mask M (Req 5.1–5.4) ---
    mask = view_masker.compute(novel_render.depth, sample.cameras)

    # --- Step 5: Build LossContext (Req 4.4, 16.1) ---
    ctx = LossContext(
        input_render=input_render,
        novel_render=novel_render,
        input_gt_image=input_image,
        novel_gt_image=novel_image,
        input_gt_depth=input_depth,
        input_gt_disparity=input_disparity,
        mask=mask,
        gaussians=gaussians,
        aligned_depth=training_outputs.aligned_depth,
        disparity_pred=training_outputs.disparity_pred,
        scale_map=training_outputs.scale_map,
        base_xy_ndc=training_outputs.base_xy_ndc,
        monodepth_disparity=training_outputs.monodepth_disparity,
        cameras=sample.cameras,
    )

    # --- Step 6: Aggregate losses (Req 16.1, 16.2) ---
    result = aggregator.aggregate(ctx)

    # --- Step 7: Backward (Req 2.5) ---
    if result.total.requires_grad:
        result.total.backward()
    else:
        # The total is 0.0 with no active terms — nothing to backprop.
        logger.warning(
            "Aggregated loss has no grad_fn (no active terms contributed). "
            "Skipping backward."
        )

    return StepResult(aggregate=result, success=True)
