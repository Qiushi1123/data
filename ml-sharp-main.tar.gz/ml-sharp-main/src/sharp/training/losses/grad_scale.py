"""Gradient-of-scale-map loss module for the SHARP training framework.

Computes anisotropic total variation of the Scale_Map S at exactly 6 scales
(original + 5 progressively downsampled by factor 2). The loss is the sum of
the TV values at each scale.

Returns zero contribution (with indication) when S is empty or non-finite.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F

from sharp.training.types import LossContext, LossRecord


def _anisotropic_tv(tensor: torch.Tensor) -> torch.Tensor:
    """Compute mean anisotropic TV on a 4-D tensor [B, C, H, W].

    TV = mean of (|horizontal neighbor diffs| + |vertical neighbor diffs|).
    Returns a scalar tensor. If spatial dims are too small, returns 0.0.
    """
    _, _, H, W = tensor.shape

    total_elements = 0
    tv_sum = torch.tensor(0.0, device=tensor.device, dtype=tensor.dtype)

    if W >= 2:
        h_diff = torch.abs(tensor[:, :, :, 1:] - tensor[:, :, :, :-1])
        tv_sum = tv_sum + h_diff.sum()
        total_elements += h_diff.numel()

    if H >= 2:
        v_diff = torch.abs(tensor[:, :, 1:, :] - tensor[:, :, :-1, :])
        tv_sum = tv_sum + v_diff.sum()
        total_elements += v_diff.numel()

    if total_elements > 0:
        return tv_sum / total_elements
    return torch.tensor(0.0, device=tensor.device, dtype=tensor.dtype)


class GradScaleLoss:
    """Multi-scale total-variation regularizer on the Scale_Map S.

    Computes the sum of anisotropic TV at exactly 6 scales: the original
    resolution plus 5 progressively downsampled versions (each halved via
    average pooling).

    Produces a finite non-negative scalar. Returns 0.0 (inactive) when S is
    None, empty, or entirely non-finite.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_∇scale).
        num_scales: Number of scales to compute TV at (fixed at 6).
    """

    name: str = "grad_scale"
    weight: float = 5.0
    num_scales: int = 6

    def __init__(self, weight: float = 5.0) -> None:
        self.name = "grad_scale"
        self.weight = weight
        self.num_scales = 6

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute multi-scale TV loss on the Scale_Map.

        Args:
            ctx: LossContext providing scale_map (S from DepthAlignment).

        Returns:
            LossRecord with the scalar grad-scale loss.
        """
        diagnostics: dict = {}

        # --- Check if scale_map is available (Req 15.3) ---
        if ctx.scale_map is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "scale_map is None"},
            )

        scale_map = ctx.scale_map

        # --- Validate non-empty ---
        if scale_map.numel() == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=scale_map.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "scale_map is empty"},
            )

        # --- Check all-non-finite (Req 15.3) ---
        if not torch.isfinite(scale_map).any():
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=scale_map.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "scale_map entirely non-finite"},
            )

        # --- Ensure 4-D shape [B, C, H, W] ---
        s = scale_map
        if s.ndim == 2:
            # [H, W] -> [1, 1, H, W]
            s = s.unsqueeze(0).unsqueeze(0)
        elif s.ndim == 3:
            # [B, H, W] -> [B, 1, H, W]
            s = s.unsqueeze(1)
        # else: assume already [B, C, H, W]

        # Replace non-finite values with 0 to avoid contaminating TV computation
        finite_mask = torch.isfinite(s)
        s = torch.where(finite_mask, s, torch.zeros_like(s))

        # --- Compute TV at 6 scales (Req 15.1) ---
        total_tv = torch.tensor(0.0, device=s.device, dtype=s.dtype)
        current = s
        scales_computed = 0

        for scale_idx in range(self.num_scales):
            _, _, H, W = current.shape

            # Need at least 2 pixels in one dimension for TV
            if H < 2 and W < 2:
                diagnostics[f"scale_{scale_idx}"] = "skipped_too_small"
                break

            tv_at_scale = _anisotropic_tv(current)
            total_tv = total_tv + tv_at_scale
            scales_computed += 1
            diagnostics[f"scale_{scale_idx}_shape"] = (H, W)

            # Downsample by factor 2 for next scale (avg_pool2d)
            if scale_idx < self.num_scales - 1:
                # Only downsample if both dims are >= 2
                if H >= 2 and W >= 2:
                    current = F.avg_pool2d(current, kernel_size=2, stride=2)
                elif H >= 2:
                    current = F.avg_pool2d(
                        current, kernel_size=(2, 1), stride=(2, 1)
                    )
                elif W >= 2:
                    current = F.avg_pool2d(
                        current, kernel_size=(1, 2), stride=(1, 2)
                    )
                else:
                    # Can't downsample further
                    break

        diagnostics["scales_computed"] = scales_computed

        # --- Finiteness check ---
        is_finite = bool(torch.isfinite(total_tv).item())

        return LossRecord(
            name=self.name,
            value=total_tv,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
