"""Splat regularizer loss module for the SHARP training framework.

Penalizes screen-space projected variances (eigenvalues of the 2×2 covariance
matrix) that fall outside the acceptable band [σ_min, σ_max]. The penalty is
averaged over visible splats (depth > 1e-2) across both eigenvalue axes.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F

from sharp.training.types import LossContext, LossRecord


class SplatLoss:
    """Per-eigenvalue variance band regularizer for projected 2D Gaussians.

    For each visible splat (depth > 1e-2), extracts the two eigenvalues of
    the 2×2 covariance matrix (covars2d) and applies the penalty:

        penalty(v) = relu(σ_min - v) + relu(v - σ_max)

    The loss is the arithmetic mean of per-eigenvalue penalties over all
    visible splats × 2 axes. Returns 0.0 when no splat is visible.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_splat).
        sigma_min: Lower bound on acceptable eigenvalue (default 1e-1).
        sigma_max: Upper bound on acceptable eigenvalue (default 1e2).
        depth_threshold: Minimum depth for a splat to be considered visible.
    """

    name: str = "splat"
    weight: float = 1.0

    def __init__(
        self,
        weight: float = 1.0,
        sigma_min: float = 1e-1,
        sigma_max: float = 1e2,
        depth_threshold: float = 1e-2,
    ) -> None:
        self.name = "splat"
        self.weight = weight
        self.sigma_min = sigma_min
        self.sigma_max = sigma_max
        self.depth_threshold = depth_threshold

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the splat regularizer loss.

        Reads covars2d and depths from input_render.meta (falling back to
        novel_render.meta if input_render is unavailable).

        Args:
            ctx: LossContext providing render outputs with meta containing
                 'covars2d' and 'depths'.

        Returns:
            LossRecord with the scalar splat loss.
        """
        diagnostics: dict = {}

        # --- Locate the render outputs with covars2d / depths ---
        render = ctx.input_render if ctx.input_render is not None else ctx.novel_render

        if render is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "no_render_available"},
            )

        meta = render.meta
        if meta is None or "covars2d" not in meta or "depths" not in meta:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "covars2d_or_depths_missing"},
            )

        covars2d = meta["covars2d"]  # [B, N, 2, 2] symmetric 2×2 covariance
        depths = meta["depths"]  # [B, N]

        # --- Build visibility mask: depth > threshold ---
        visible_mask = depths > self.depth_threshold  # [B, N]

        # --- Req 13.4: Return 0.0 when no splat is visible ---
        visible_count = visible_mask.sum()
        if visible_count == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=covars2d.device, dtype=covars2d.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"visible_splats": 0, "reason": "no_visible_splats"},
            )

        visible_covars = covars2d[visible_mask]
        finite_matrix_mask = torch.isfinite(visible_covars).all(dim=(-2, -1))
        visible_covars = visible_covars[finite_matrix_mask]

        if visible_covars.numel() == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=covars2d.device, dtype=covars2d.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={
                    "visible_splats": int(visible_count.item()),
                    "finite_covars": 0,
                    "reason": "no_finite_covars",
                },
            )

        a = visible_covars[..., 0, 0]
        b = 0.5 * (visible_covars[..., 0, 1] + visible_covars[..., 1, 0])
        d = visible_covars[..., 1, 1]
        half_trace = 0.5 * (a + d)
        radius = torch.sqrt(torch.clamp((0.5 * (a - d)).square() + b.square(), min=0.0))
        eigenvalues = torch.stack((half_trace - radius, half_trace + radius), dim=-1)

        # --- Req 13.1, 13.2: Per-eigenvalue penalty ---
        # penalty(v) = relu(σ_min - v) + relu(v - σ_max)
        penalty = F.relu(self.sigma_min - eigenvalues) + F.relu(eigenvalues - self.sigma_max)
        # penalty shape: [B, N, 2]

        loss_value = penalty.mean()

        # Check finiteness
        is_finite = bool(torch.isfinite(loss_value).item())

        diagnostics["visible_splats"] = int(visible_count.item())
        diagnostics["finite_covars"] = int(finite_matrix_mask.sum().item())
        diagnostics["mean_penalty"] = float(loss_value.detach().item()) if is_finite else float("nan")

        return LossRecord(
            name=self.name,
            value=loss_value,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
