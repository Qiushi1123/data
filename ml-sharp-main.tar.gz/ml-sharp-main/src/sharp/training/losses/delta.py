"""Delta-offset regularizer for the SHARP training framework.

Penalizes Gaussian xy offsets whose magnitude exceeds a threshold δ=400.0.
The penalty is mean(relu(‖offset‖₂ − δ)), which is zero at or below the
threshold and increases monotonically beyond it.

Evaluated on the raw predicted xy delta channels. The offset magnitude is
computed from the difference between the final Gaussian mean positions (xy)
and the base xy NDC projections.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.types import LossContext, LossRecord


class DeltaLoss:
    """Delta-offset regularizer penalizing large xy displacements.

    Computes mean(relu(‖offset‖₂ − δ)) where offset is the per-Gaussian
    xy displacement from base position, and δ is the threshold below which
    no penalty is applied.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (lambda_delta).
    """

    name: str = "delta"
    weight: float = 1.0

    # Threshold beyond which the penalty is applied.
    _delta: float = 400.0

    def __init__(self, weight: float = 1.0, delta: float = 400.0) -> None:
        self.name = "delta"
        self.weight = weight
        self._delta = delta

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the delta-offset regularization loss.

        Args:
            ctx: LossContext providing gaussians (with mean_vectors) and
                 base_xy_ndc.

        Returns:
            LossRecord with the scalar delta-offset loss.
        """
        diagnostics: dict = {}

        # --- Check required inputs ---
        if ctx.gaussians is None or not hasattr(ctx.gaussians, "mean_vectors"):
            return self._inactive("gaussians_mean_vectors_absent")

        if ctx.base_xy_ndc is None:
            return self._inactive("base_xy_ndc_absent")

        # --- Extract xy positions ---
        # gaussians.mean_vectors: [B, N, 3] (x, y, z after flatten_output=True)
        mean_xy = ctx.gaussians.mean_vectors[:, :, :2]  # [B, N, 2]
        base_xy = ctx.base_xy_ndc  # [B, N, 2]

        B, N, _ = mean_xy.shape

        # --- Return 0.0 if no Gaussians ---
        if N == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=mean_xy.device, dtype=mean_xy.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"reason": "no_gaussians"},
            )

        # --- Compute offset magnitude ---
        # offset: [B, N, 2] — displacement from base position
        offset = mean_xy - base_xy

        # L2 norm of the xy offset per Gaussian: [B, N]
        offset_mag = torch.norm(offset, p=2, dim=-1)

        # --- Apply threshold and compute penalty ---
        # penalty = relu(‖offset‖₂ − δ): zero at/below δ, linear above
        penalty = torch.relu(offset_mag - self._delta)  # [B, N]

        # --- Mean over all Gaussians ---
        loss = penalty.mean()

        is_finite = bool(torch.isfinite(loss).item())
        diagnostics["loss_value"] = float(loss.item()) if is_finite else float("nan")
        diagnostics["num_gaussians"] = int(B * N)
        diagnostics["num_exceeding_delta"] = int((offset_mag > self._delta).sum().item())

        return LossRecord(
            name=self.name,
            value=loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )

    def _inactive(self, reason: str) -> LossRecord:
        """Return an inactive loss record with the given reason."""
        return LossRecord(
            name=self.name,
            value=torch.tensor(0.0),
            weight=self.weight,
            active=False,
            finite=True,
            diagnostics={"reason": reason},
        )
