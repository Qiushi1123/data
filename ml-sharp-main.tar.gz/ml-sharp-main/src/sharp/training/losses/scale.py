"""Scale loss module for the SHARP training framework.

Computes mean |S - 1| over finite entries of the scale_map S produced by
DepthAlignment. Returns 0.0 (inactive) when the scale_map is None (GT depth
not provided) or contains no finite entries.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.types import LossContext, LossRecord


class ScaleLoss:
    """Scale loss: mean absolute deviation of S from 1.

    Penalizes the depth-alignment Scale_Map for deviating from unity,
    encouraging the alignment to produce minimal rescaling. Only finite
    entries contribute to the mean; non-finite entries (NaN, Inf) are
    excluded.

    Returns 0.0 (inactive) when:
      - scale_map is None (S unavailable — GT depth not provided)
      - No finite entry exists in the scale_map

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_scale).
    """

    name: str = "scale"
    weight: float = 0.1

    def __init__(self, weight: float = 0.1) -> None:
        self.name = "scale"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the scale loss given the training context.

        Args:
            ctx: LossContext providing scale_map (the retained S from
                DepthAlignment).

        Returns:
            LossRecord with the scalar scale loss.
        """
        # --- Req 14.4: Return 0.0 with "S unavailable" when scale_map is None ---
        if ctx.scale_map is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "S unavailable"},
            )

        scale_map = ctx.scale_map

        # --- Req 14.5: Exclude non-finite entries from the mean ---
        finite_mask = torch.isfinite(scale_map)
        finite_count = finite_mask.sum()

        if finite_count == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=scale_map.device, dtype=scale_map.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"finite_pixels": 0, "reason": "no_finite_entries"},
            )

        # --- Req 14.1, 14.3: mean |S - 1| over finite entries ---
        # Compute from the retained S (not recomputed)
        abs_deviation = torch.abs(scale_map - 1.0)
        loss = abs_deviation[finite_mask].mean()

        is_finite = bool(torch.isfinite(loss).item())

        return LossRecord(
            name=self.name,
            value=loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics={"finite_pixels": int(finite_count.item())},
        )
