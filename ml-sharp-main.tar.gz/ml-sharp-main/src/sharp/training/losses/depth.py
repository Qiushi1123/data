"""Depth loss module for the SHARP training framework.

Computes L1 loss between predicted disparity (layer 0 only) and ground-truth
disparity, evaluated only at pixels where the GT disparity is finite and > 0.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.types import LossContext, LossRecord


class DepthLoss:
    """L1 depth loss on layer 0 of the predicted disparity.

    Computes mean absolute difference between predicted disparity (layer 0)
    and ground-truth disparity, restricted to pixels where the GT disparity
    is finite AND > 0. Layer 1 is completely ignored.

    Returns 0.0 (inactive) when:
      - GT disparity is not provided (None)
      - No valid pixel exists in the GT disparity

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_depth).
    """

    name: str = "depth"
    weight: float = 0.2

    def __init__(self, weight: float = 0.2) -> None:
        self.name = "depth"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the depth loss given the training context.

        Args:
            ctx: LossContext providing disparity_pred and input_gt_disparity.

        Returns:
            LossRecord with the scalar depth loss.
        """
        diagnostics: dict = {}

        # --- Req 9.6: If GT disparity not provided, contribute 0.0 ---
        if ctx.input_gt_disparity is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "gt_disparity_absent"},
            )

        # --- Check disparity_pred is available ---
        if ctx.disparity_pred is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"reason": "disparity_pred_absent"},
            )

        # --- Req 9.2: Only layer 0, ignore layer 1 ---
        # disparity_pred: [B, 2, H, W] -> extract layer 0: [B, 1, H, W]
        pred_layer0 = ctx.disparity_pred[:, 0:1]  # [B, 1, H, W]

        # --- Normalize GT disparity shape ---
        # GT disparity may be [B, H, W] or [B, 1, H, W]
        gt_disp = ctx.input_gt_disparity
        if gt_disp.ndim == 3:
            gt_disp = gt_disp.unsqueeze(1)  # [B, 1, H, W]

        # --- Req 9.3: Build validity mask (finite AND > 0) ---
        valid_mask = torch.isfinite(gt_disp) & (gt_disp > 0.0)  # [B, 1, H, W]

        # --- Req 9.4: If no valid pixel, contribute 0.0 ---
        valid_count = valid_mask.sum()
        if valid_count == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=pred_layer0.device, dtype=pred_layer0.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"valid_pixels": 0, "reason": "no_valid_pixels"},
            )

        # --- Req 9.1: Mean L1 over valid pixels ---
        l1_diff = torch.abs(pred_layer0 - gt_disp)
        # Apply mask: sum only over valid pixels, then divide by count
        masked_l1 = l1_diff[valid_mask].mean()

        # Check finiteness
        is_finite = bool(torch.isfinite(masked_l1).item())

        diagnostics["valid_pixels"] = int(valid_count.item())

        return LossRecord(
            name=self.name,
            value=masked_l1,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
