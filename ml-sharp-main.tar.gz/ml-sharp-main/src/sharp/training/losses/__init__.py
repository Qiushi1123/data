"""Loss modules for the SHARP training framework.

Each module implements the LossModule protocol, accepting a LossContext and
returning a LossRecord.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from sharp.training.losses.alpha import AlphaLoss
from sharp.training.losses.color import ColorLoss
from sharp.training.losses.delta import DeltaLoss
from sharp.training.losses.depth import DepthLoss
from sharp.training.losses.floater import FloaterLoss
from sharp.training.losses.grad_scale import GradScaleLoss
from sharp.training.losses.perceptual import PerceptualLoss
from sharp.training.losses.scale import ScaleLoss
from sharp.training.losses.splat import SplatLoss
from sharp.training.losses.tv import TVLoss

__all__ = [
    "AlphaLoss",
    "ColorLoss",
    "DeltaLoss",
    "DepthLoss",
    "FloaterLoss",
    "GradScaleLoss",
    "PerceptualLoss",
    "ScaleLoss",
    "SplatLoss",
    "TVLoss",
]
