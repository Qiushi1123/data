"""Color loss module for the SHARP training framework.

Computes per-pixel per-channel L1 color loss on both the input view (full
mean) and the novel view (masked mean via view-frustum mask M).

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.masking import masked_mean
from sharp.training.types import LossContext, LossRecord


class ColorLoss:
    """L1 color loss for input and novel views.

    Input-view loss: mean absolute difference over all pixels and channels.
    Novel-view loss: masked_mean of absolute differences where mask M=1.
    The two are summed into a single scalar.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_color).
    """

    name: str = "color"
    weight: float = 1.0

    def __init__(self, weight: float = 1.0) -> None:
        self.name = "color"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the color loss given the training context.

        Args:
            ctx: LossContext providing input/novel renders, GT images, and mask.

        Returns:
            LossRecord with the combined scalar color loss.
        """
        diagnostics: dict = {}

        # --- Validate required fields ---
        if ctx.input_render is None or ctx.input_gt_image is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "input_render or input_gt_image is None"},
            )

        if ctx.novel_render is None or ctx.novel_gt_image is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "novel_render or novel_gt_image is None"},
            )

        if ctx.mask is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "mask is None"},
            )

        input_rendered = ctx.input_render.color  # [B, 3, H, W]
        input_gt = ctx.input_gt_image  # [B, 3, H, W]
        novel_rendered = ctx.novel_render.color  # [B, 3, H, W]
        novel_gt = ctx.novel_gt_image  # [B, 3, H, W]
        mask = ctx.mask  # [B, 1, H, W]

        # --- Shape validation (Req 6.4) ---
        if input_rendered.shape != input_gt.shape:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=input_rendered.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={
                    "error": (
                        f"Input shape mismatch: rendered {input_rendered.shape} "
                        f"vs gt {input_gt.shape}"
                    )
                },
            )

        if novel_rendered.shape != novel_gt.shape:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=novel_rendered.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={
                    "error": (
                        f"Novel shape mismatch: rendered {novel_rendered.shape} "
                        f"vs gt {novel_gt.shape}"
                    )
                },
            )

        # Mask spatial dims must match novel-view spatial dims
        novel_B, novel_C, novel_H, novel_W = novel_rendered.shape
        mask_B, mask_C, mask_H, mask_W = mask.shape
        if mask_H != novel_H or mask_W != novel_W or mask_B != novel_B:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=novel_rendered.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={
                    "error": (
                        f"Mask spatial mismatch: mask {mask.shape} "
                        f"vs novel {novel_rendered.shape}"
                    )
                },
            )

        # --- Input-view color loss (Req 6.1): mean L1 ---
        input_l1 = torch.abs(input_rendered - input_gt)
        input_loss = input_l1.mean()

        # --- Novel-view color loss (Req 6.2, 6.3): masked mean L1 ---
        novel_l1 = torch.abs(novel_rendered - novel_gt)
        # masked_mean handles zero-mask case (returns 0.0)
        novel_loss = masked_mean(novel_l1, mask)

        # --- Combined loss (single scalar, Req 6.6) ---
        total_loss = input_loss + novel_loss

        # Check finiteness
        is_finite = bool(torch.isfinite(total_loss).item())

        diagnostics["input_loss"] = float(input_loss.detach())
        diagnostics["novel_loss"] = float(novel_loss.detach())
        diagnostics["mask_pixels"] = int(mask.sum().item())

        return LossRecord(
            name=self.name,
            value=total_loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
