"""Perceptual loss module for the SHARP training framework.

Computes a 4-layer ResNet-50 feature-space loss on the novel view:
  - Per-layer feature L2 weighted by 1/(Dl * Hl * Wl)
  - Per-layer Gram-matrix L2 weighted by 10 / Dl^2

The mask M is applied to rendered and GT inputs element-wise before feature
extraction. ResNet-50 weights are frozen (requires_grad=False).

An optional graph-surgery memory optimization (Req 23) caches gradients from
the first view's feature extraction and injects them during the second view's
pass, so at most one view's ResNet feature graph is retained in memory at a
time. When disabled, the standard autograd path is used unchanged.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

from typing import List, Optional

import torch
import torch.nn as nn
import torchvision.models as models

from sharp.training.types import LossContext, LossRecord


class _FeatureExtractor(nn.Module):
    """Extracts intermediate features from 4 ResNet-50 layers.

    Hooks onto layer1, layer2, layer3, layer4 of a pretrained ResNet-50 and
    captures their outputs during a forward pass.  All parameters are frozen.
    """

    def __init__(self) -> None:
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)

        # Build sequential stages matching the 4 intermediate layers
        self.stage0 = nn.Sequential(
            resnet.conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool,
        )
        self.stage1 = resnet.layer1  # layer1 output
        self.stage2 = resnet.layer2  # layer2 output
        self.stage3 = resnet.layer3  # layer3 output
        self.stage4 = resnet.layer4  # layer4 output

        # Freeze all parameters
        for param in self.parameters():
            param.requires_grad = False

    @torch.no_grad()
    def _no_grad_forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """Extract features without building a grad graph on ResNet weights.

        We still want gradients to flow through the *input* x, so we detach
        the feature extractor parameters but keep the input connected.  However,
        since all ResNet params have requires_grad=False the graph will not
        accumulate grads for them regardless.
        """
        # We intentionally do NOT use torch.no_grad here because gradients
        # must flow back through x to the renderer.  The ResNet params are
        # frozen (requires_grad=False) so they won't accumulate grads.
        raise NotImplementedError  # pragma: no cover

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """Extract 4-layer features, preserving autograd through the input.

        Args:
            x: Input tensor [B, 3, H, W] in [0, 1] range.

        Returns:
            List of 4 feature tensors from layer1..layer4.
        """
        # ImageNet normalization (applied with grad-preserving ops)
        mean = torch.tensor([0.485, 0.456, 0.406], device=x.device, dtype=x.dtype).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225], device=x.device, dtype=x.dtype).view(1, 3, 1, 1)
        x = (x - mean) / std

        features: List[torch.Tensor] = []
        x = self.stage0(x)
        x = self.stage1(x)
        features.append(x)
        x = self.stage2(x)
        features.append(x)
        x = self.stage3(x)
        features.append(x)
        x = self.stage4(x)
        features.append(x)
        return features


def _gram_matrix(feat: torch.Tensor) -> torch.Tensor:
    """Compute the Gram matrix for a feature map.

    Args:
        feat: Feature tensor [B, D, H, W].

    Returns:
        Gram matrix [B, D, D] = feat_flat @ feat_flat^T normalized by (H*W).
    """
    B, D, H, W = feat.shape
    feat_flat = feat.view(B, D, H * W)  # [B, D, H*W]
    gram = torch.bmm(feat_flat, feat_flat.transpose(1, 2))  # [B, D, D]
    # Normalize by spatial size for numerical stability
    gram = gram / (H * W)
    return gram


def _compute_perceptual_from_features(
    feats_rendered: List[torch.Tensor],
    feats_gt: List[torch.Tensor],
    device: torch.device,
    dtype: torch.dtype,
) -> tuple[torch.Tensor, dict]:
    """Compute the perceptual loss from pre-extracted features.

    Args:
        feats_rendered: 4-layer features from the rendered image.
        feats_gt: 4-layer features from the GT image.
        device: Device for the output tensor.
        dtype: Dtype for the output tensor.

    Returns:
        Tuple of (total_loss, diagnostics_dict).
    """
    total_loss = torch.tensor(0.0, device=device, dtype=dtype)
    diagnostics: dict = {}

    for l_idx, (feat_r, feat_g) in enumerate(zip(feats_rendered, feats_gt)):
        B, Dl, Hl, Wl = feat_r.shape

        # Feature distance: sum((feat_r - feat_g)^2) / (Dl * Hl * Wl)
        feat_diff = feat_r - feat_g
        feat_loss = (feat_diff ** 2).sum() / (Dl * Hl * Wl)

        # Gram distance: sum((Gram_r - Gram_g)^2) * 10 / Dl^2
        gram_r = _gram_matrix(feat_r)
        gram_g = _gram_matrix(feat_g)
        gram_diff = gram_r - gram_g
        gram_loss = (gram_diff ** 2).sum() * 10.0 / (Dl ** 2)

        total_loss = total_loss + feat_loss + gram_loss

        diagnostics[f"layer{l_idx}_feat_loss"] = float(feat_loss.detach())
        diagnostics[f"layer{l_idx}_gram_loss"] = float(gram_loss.detach())

    diagnostics["total_unweighted"] = float(total_loss.detach())
    return total_loss, diagnostics


class PerceptualLoss:
    """4-layer ResNet-50 perceptual loss for the novel view.

    Computes feature L2 and Gram-matrix L2 across 4 ResNet-50 layers.
    Mask M is applied to both rendered and GT images before extraction.

    When ``memory_opt=True``, enables a graph-surgery optimization (Req 23)
    that caches gradients from the first view's ResNet feature extraction and
    injects them during the second view's pass. This ensures at most one
    view's ResNet feature graph is retained in memory at any time. The
    optimization is a two-phase protocol:

    Phase 1 (``compute_and_cache``): Computes the loss normally and caches the
    input gradients that flow back from the loss through the feature extraction.

    Phase 2 (``compute_with_cached``): Computes features for the GT image
    normally (no graph needed for GT) but for the rendered image, uses the
    cached gradients via a custom autograd function that injects them during
    backward. This avoids retaining both views' feature graphs simultaneously.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_percep).
        memory_opt: Whether the graph-surgery memory optimization is enabled.
    """

    name: str = "perceptual"
    weight: float = 3.0

    def __init__(
        self,
        weight: float = 3.0,
        device: torch.device | None = None,
        memory_opt: bool = False,
    ) -> None:
        self.name = "perceptual"
        self.weight = weight
        self.memory_opt = memory_opt
        self._extractor = _FeatureExtractor()
        if device is not None:
            self._extractor = self._extractor.to(device)
        self._extractor.eval()

        # Storage for cached gradients (memory_opt mode)
        self._cached_grads: Optional[List[torch.Tensor]] = None

    def to(self, device: torch.device) -> "PerceptualLoss":
        """Move the feature extractor to a device."""
        self._extractor = self._extractor.to(device)
        return self

    @property
    def extractor(self) -> _FeatureExtractor:
        """Access the feature extractor (for testing/inspection)."""
        return self._extractor

    def clear_cache(self) -> None:
        """Clear the cached gradients (call between training steps)."""
        self._cached_grads = None

    def _validate_cached_grads(
        self, masked_rendered: torch.Tensor
    ) -> Optional[str]:
        """Validate cached gradients against the current masked rendered input.

        Args:
            masked_rendered: Current masked rendered image to check shape against.

        Returns:
            None if valid, otherwise an error message string.
        """
        if self._cached_grads is None:
            return (
                "PerceptualLoss memory_opt: cached gradients are absent. "
                "Call compute_and_cache before compute_with_cached."
            )

        if len(self._cached_grads) != 1:
            return (
                f"PerceptualLoss memory_opt: cached gradient count mismatch. "
                f"Expected 1 input gradient, got {len(self._cached_grads)}."
            )

        cached = self._cached_grads[0]
        if cached.shape != masked_rendered.shape:
            return (
                f"PerceptualLoss memory_opt: cached gradient shape mismatch. "
                f"Expected {masked_rendered.shape}, got {cached.shape}."
            )
        if not torch.isfinite(cached).all():
            return (
                "PerceptualLoss memory_opt: cached gradient "
                "contains non-finite values (NaN or Inf)."
            )

        return None

    def compute_and_cache(self, ctx: LossContext) -> LossRecord:
        """Phase 1: compute loss normally and cache input gradients.

        Runs the standard perceptual loss computation but additionally records
        the gradient of the loss with respect to the masked rendered input image.
        This cached gradient will be injected in Phase 2.

        Args:
            ctx: LossContext providing novel renders, GT images, and mask.

        Returns:
            LossRecord with the perceptual loss scalar (standard path).
        """
        # Use the standard path to get the loss value
        record = self._compute_standard(ctx)
        if not record.active:
            return record

        # Now compute and cache the gradient w.r.t. the masked rendered input.
        novel_rendered = ctx.novel_render.color  # type: ignore[union-attr]
        novel_gt = ctx.novel_gt_image
        mask = ctx.mask

        # Create a fresh tensor for gradient computation to avoid graph
        # interference with the standard path computation.
        masked_rendered = novel_rendered * mask  # type: ignore[operator]
        masked_gt = novel_gt * mask  # type: ignore[operator]

        device = novel_rendered.device
        extractor_device = next(self._extractor.parameters()).device
        if extractor_device != device:
            self._extractor = self._extractor.to(device)

        # We need masked_rendered to be a leaf for autograd.grad
        masked_rendered_leaf = masked_rendered.detach().requires_grad_(True)

        # Extract features with gradient tracking on the masked rendered input
        feats_rendered = self._extractor(masked_rendered_leaf)
        feats_gt = self._extractor(masked_gt)

        # Compute the loss from these features
        loss_value, _ = _compute_perceptual_from_features(
            feats_rendered, feats_gt, device, novel_rendered.dtype
        )

        # Compute gradient of the loss w.r.t. the masked rendered input.
        # This is the full d_loss/d_masked_rendered gradient.
        (grad_input,) = torch.autograd.grad(
            loss_value,
            masked_rendered_leaf,
            retain_graph=False,
            create_graph=False,
        )
        self._cached_grads = [grad_input.detach().clone()]

        return record

    def compute_with_cached(self, ctx: LossContext) -> LossRecord:
        """Phase 2: inject cached gradients instead of retaining the full graph.

        Instead of extracting features and computing the full loss (which would
        require retaining the feature graph), uses a custom autograd function to
        inject the cached input-level gradients during backward. This means only
        the current view's simple multiply graph is in memory (not the full
        ResNet feature extraction graph for both views simultaneously).

        Args:
            ctx: LossContext providing novel renders, GT images, and mask.

        Returns:
            LossRecord with the perceptual loss scalar.

        Raises:
            RuntimeError: If cached gradients are absent, shape-mismatched,
                or non-finite (Req 23.5).
        """
        # Validate required inputs
        validation_record = self._validate_inputs(ctx)
        if validation_record is not None:
            return validation_record

        novel_rendered = ctx.novel_render.color  # type: ignore[union-attr]
        novel_gt = ctx.novel_gt_image
        mask = ctx.mask

        masked_rendered = novel_rendered * mask  # type: ignore[operator]

        # Validate cached gradients before using them (Req 23.5)
        error_msg = self._validate_cached_grads(masked_rendered)
        if error_msg is not None:
            raise RuntimeError(error_msg)

        device = novel_rendered.device
        extractor_device = next(self._extractor.parameters()).device
        if extractor_device != device:
            self._extractor = self._extractor.to(device)

        # Compute the loss value (for reporting) using a detached path
        # so we don't retain the full feature extraction graph
        with torch.no_grad():
            masked_gt = novel_gt * mask  # type: ignore[operator]
            feats_rendered = self._extractor(masked_rendered)
            feats_gt = self._extractor(masked_gt)
            loss_value_detached, diagnostics = _compute_perceptual_from_features(
                feats_rendered,
                feats_gt,
                device,
                novel_rendered.dtype,
            )

        # Create a graph-connected scalar that, during backward, injects the
        # cached input-level gradient into masked_rendered. This is the "surgery":
        # instead of retaining the loss→features→input graph for both views, we
        # only keep the masked_rendered→novel_rendered graph (the simple multiply),
        # and inject the pre-computed d(loss)/d(masked_rendered) directly.
        loss_with_grad = _GradientInjection.apply(
            loss_value_detached, self._cached_grads, masked_rendered
        )

        is_finite = bool(torch.isfinite(loss_with_grad).item())
        diagnostics["memory_opt"] = True

        return LossRecord(
            name=self.name,
            value=loss_with_grad,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )

    def _validate_inputs(self, ctx: LossContext) -> Optional[LossRecord]:
        """Validate LossContext inputs; return a LossRecord if invalid, else None."""
        if ctx.novel_render is None or ctx.novel_gt_image is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "novel_render or novel_gt_image is None"},
            )

        if ctx.mask is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "mask is None"},
            )

        novel_rendered = ctx.novel_render.color
        novel_gt = ctx.novel_gt_image
        mask = ctx.mask

        _, _, rH, rW = novel_rendered.shape
        _, _, gH, gW = novel_gt.shape
        _, _, mH, mW = mask.shape

        if rH != gH or rW != gW or rH != mH or rW != mW:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=novel_rendered.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={
                    "error": (
                        f"Spatial dimension mismatch: rendered ({rH},{rW}), "
                        f"gt ({gH},{gW}), mask ({mH},{mW})"
                    )
                },
            )

        return None

    def _compute_standard(self, ctx: LossContext) -> LossRecord:
        """Compute the perceptual loss using the standard autograd path.

        This is the original computation without any graph surgery.

        Args:
            ctx: LossContext providing novel renders, GT images, and mask.

        Returns:
            LossRecord with the perceptual loss scalar.
        """
        # Validate inputs
        validation_record = self._validate_inputs(ctx)
        if validation_record is not None:
            return validation_record

        novel_rendered = ctx.novel_render.color  # type: ignore[union-attr]
        novel_gt = ctx.novel_gt_image
        mask = ctx.mask

        # Apply mask M element-wise before feature extraction (Req 7.4)
        masked_rendered = novel_rendered * mask  # type: ignore[operator]
        masked_gt = novel_gt * mask  # type: ignore[operator]

        # Move extractor to input device if needed
        device = novel_rendered.device
        extractor_device = next(self._extractor.parameters()).device
        if extractor_device != device:
            self._extractor = self._extractor.to(device)

        # Extract features (Req 7.1)
        feats_rendered = self._extractor(masked_rendered)
        feats_gt = self._extractor(masked_gt)

        # Compute per-layer losses (Req 7.1, 7.2)
        total_loss, diagnostics = _compute_perceptual_from_features(
            feats_rendered, feats_gt, device, novel_rendered.dtype
        )

        # Check finiteness
        is_finite = bool(torch.isfinite(total_loss).item())

        return LossRecord(
            name=self.name,
            value=total_loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the perceptual loss given the training context.

        When ``memory_opt`` is disabled, uses the standard autograd path (Req 23.2).
        When ``memory_opt`` is enabled, uses the two-phase graph-surgery protocol
        (Req 23.1). In the single-call path (this method), it runs both phases:
        compute_and_cache (to get gradients) then compute_with_cached (to produce
        a graph-connected loss that injects cached gradients during backward).

        For the typical training loop usage with memory_opt enabled, the caller
        should use ``compute_and_cache`` for the first view and
        ``compute_with_cached`` for the second view explicitly.

        Args:
            ctx: LossContext providing novel renders, GT images, and mask.

        Returns:
            LossRecord with the perceptual loss scalar.
        """
        if not self.memory_opt:
            # Standard autograd path (Req 23.2)
            return self._compute_standard(ctx)

        # Memory-optimized path (Req 23.1):
        # Phase 1: compute loss and cache gradients
        # Phase 2: inject cached gradients for graph-connected backward
        record = self.compute_and_cache(ctx)
        if not record.active:
            return record

        # Phase 2: return a graph-connected loss using cached gradients
        return self.compute_with_cached(ctx)


class _GradientInjection(torch.autograd.Function):
    """Custom autograd function that injects pre-computed gradients during backward.

    Forward: computes a scalar that is connected to all feature tensors in the
    autograd graph by taking a zero-contribution sum from them plus the detached
    loss value.

    Backward: injects the cached gradients (scaled by the upstream gradient)
    into each feature tensor, so that gradients flow back through the
    features→input graph without needing to retain the loss→features graph.
    """

    @staticmethod
    def forward(ctx, loss_value: torch.Tensor, cached_grads: List[torch.Tensor], *feats_rendered: torch.Tensor) -> torch.Tensor:
        """Forward pass: create graph connectivity to feature tensors.

        Args:
            ctx: Autograd function context.
            loss_value: The detached loss scalar (for correct forward value).
            cached_grads: List of pre-computed gradient tensors to inject.
            *feats_rendered: Feature tensors (graph-connected to input).

        Returns:
            A scalar with the correct loss value, connected to feats_rendered.
        """
        ctx.save_for_backward(*cached_grads)
        ctx.num_feats = len(feats_rendered)
        # Return the loss value — graph connectivity to feats is established
        # because they are inputs to this Function.
        return loss_value.detach().clone()

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        """Backward pass: inject cached gradients scaled by upstream grad.

        Args:
            ctx: Autograd function context.
            grad_output: Upstream gradient (scalar).

        Returns:
            Tuple of (None for loss_value, None for cached_grads,
                      *grad for each feat in feats_rendered).
        """
        cached_grads = ctx.saved_tensors
        # Scale each cached gradient by the upstream scalar
        feat_grads = tuple(grad_output * g for g in cached_grads)
        # Return: (loss_value grad=None, cached_grads grad=None, *feat grads)
        return (None, None) + feat_grads
