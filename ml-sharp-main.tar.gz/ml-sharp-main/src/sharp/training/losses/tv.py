"""Total-variation loss module for the SHARP training framework.

Computes anisotropic total variation (sum of horizontal + vertical absolute
neighbor differences) on the second depth layer (disparity_pred[:, 1]).

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.types import LossContext, LossRecord


class TVLoss:
    """Anisotropic total-variation regularizer on disparity layer 1.

    TV = mean of (|horizontal neighbor diffs| + |vertical neighbor diffs|)
    computed on disparity_pred[:, 1:2].

    Produces a finite non-negative scalar. Returns 0.0 when the map is empty
    or has no valid spatial extent for computing differences.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_tv).
    """

    name: str = "tv"
    weight: float = 1.0

    def __init__(self, weight: float = 1.0) -> None:
        self.name = "tv"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the TV loss on disparity layer 1.

        Args:
            ctx: LossContext providing disparity_pred [B, 2, H, W].

        Returns:
            LossRecord with the scalar TV loss.
        """
        diagnostics: dict = {}

        # --- Validate required fields ---
        if ctx.disparity_pred is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "disparity_pred is None"},
            )

        disparity_pred = ctx.disparity_pred  # [B, 2, H, W]

        # Validate shape: need at least 2 layers
        if disparity_pred.ndim != 4 or disparity_pred.shape[1] < 2:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=disparity_pred.device),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={
                    "error": (
                        f"disparity_pred shape invalid: {disparity_pred.shape}, "
                        f"expected [B, >=2, H, W]"
                    )
                },
            )

        # Extract the second depth layer (index 1) -> [B, 1, H, W]
        layer1 = disparity_pred[:, 1:2, :, :]

        B, C, H, W = layer1.shape

        # --- Empty map check (Req 10.4) ---
        # If spatial dims are too small for any neighbor differences, return 0.0
        if H < 2 and W < 2:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=layer1.device),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"h_diffs": 0, "v_diffs": 0},
            )

        # If the map has zero elements (e.g. B=0), return 0.0
        if layer1.numel() == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=layer1.device),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={"h_diffs": 0, "v_diffs": 0},
            )

        # --- Compute anisotropic TV (Req 10.1) ---
        # Horizontal differences: |map[:,:,:,1:] - map[:,:,:,:-1]|
        total_elements = 0
        tv_sum = torch.tensor(0.0, device=layer1.device, dtype=layer1.dtype)

        if W >= 2:
            h_diff = torch.abs(layer1[:, :, :, 1:] - layer1[:, :, :, :-1])
            tv_sum = tv_sum + h_diff.sum()
            total_elements += h_diff.numel()
            diagnostics["h_diffs"] = h_diff.numel()
        else:
            diagnostics["h_diffs"] = 0

        # Vertical differences: |map[:,:,1:,:] - map[:,:,:-1,:]|
        if H >= 2:
            v_diff = torch.abs(layer1[:, :, 1:, :] - layer1[:, :, :-1, :])
            tv_sum = tv_sum + v_diff.sum()
            total_elements += v_diff.numel()
            diagnostics["v_diffs"] = v_diff.numel()
        else:
            diagnostics["v_diffs"] = 0

        # Normalize by the total number of difference elements
        if total_elements > 0:
            tv_loss = tv_sum / total_elements
        else:
            tv_loss = torch.tensor(0.0, device=layer1.device)

        # --- Finiteness check (Req 10.2) ---
        is_finite = bool(torch.isfinite(tv_loss).item())

        diagnostics["total_elements"] = total_elements

        return LossRecord(
            name=self.name,
            value=tv_loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
