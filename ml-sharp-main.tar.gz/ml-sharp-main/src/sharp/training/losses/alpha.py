"""Alpha loss module for the SHARP training framework.

Computes binary cross-entropy toward target=1 on both input-view (full mean)
and novel-view (masked mean via view-frustum mask M) rendered Gaussian alpha.
Pixels with non-finite or out-of-range alpha values are excluded and counted
in diagnostics.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.masking import masked_mean
from sharp.training.types import LossContext, LossRecord


class AlphaLoss:
    """BCE alpha loss encouraging full opacity on both views.

    For each view the per-pixel loss is BCE(alpha, 1) = -log(alpha).
    Alpha values are clamped to (eps, 1-eps) for numerical stability.
    Pixels where alpha is non-finite or outside [0, 1] are excluded from
    computation and reported in diagnostics.

    Input-view: mean over all valid pixels.
    Novel-view: masked_mean over valid pixels where mask M=1.
    If the mask selects zero valid pixels, novel loss is 0.0.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (λ_alpha).
    """

    name: str = "alpha"
    weight: float = 1.0

    def __init__(self, weight: float = 1.0) -> None:
        self.name = "alpha"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the alpha loss given the training context.

        Args:
            ctx: LossContext providing input/novel renders and mask.

        Returns:
            LossRecord with the combined scalar alpha loss.
        """
        diagnostics: dict = {}
        eps = 1e-7

        # --- Validate required fields ---
        if ctx.input_render is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "input_render is None"},
            )

        if ctx.novel_render is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "novel_render is None"},
            )

        if ctx.mask is None:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0),
                weight=self.weight,
                active=False,
                finite=True,
                diagnostics={"error": "mask is None"},
            )

        input_alpha = ctx.input_render.alpha  # [B, 1, H, W]
        novel_alpha = ctx.novel_render.alpha  # [B, 1, H, W]
        mask = ctx.mask  # [B, 1, H, W]

        # --- Input-view alpha loss (Req 8.1) ---
        # Exclude out-of-range or non-finite pixels (Req 8.5)
        input_valid = torch.isfinite(input_alpha) & (input_alpha >= 0.0) & (input_alpha <= 1.0)
        input_excluded = int((~input_valid).sum().item())

        if input_valid.any():
            # Replace invalid values with a safe placeholder before clamping
            # (clamp does not fix NaN/Inf), then zero out their contribution
            safe_input_alpha = torch.where(input_valid, input_alpha, torch.ones_like(input_alpha))
            # Clamp for numerical stability in log
            input_alpha_clamped = safe_input_alpha.clamp(min=eps, max=1.0 - eps)
            # BCE(alpha, 1) = -log(alpha)
            input_bce = -torch.log(input_alpha_clamped)
            # Zero out invalid pixels before taking mean
            input_bce = input_bce * input_valid.float()
            input_loss = input_bce.sum() / input_valid.float().sum()
        else:
            input_loss = torch.tensor(0.0, device=input_alpha.device, dtype=input_alpha.dtype)

        # --- Novel-view alpha loss (Req 8.2, 8.3) ---
        # Exclude out-of-range or non-finite pixels (Req 8.5)
        novel_valid = torch.isfinite(novel_alpha) & (novel_alpha >= 0.0) & (novel_alpha <= 1.0)
        novel_excluded = int((~novel_valid).sum().item())

        # Combined mask: view-frustum mask AND valid alpha pixels
        effective_mask = mask * novel_valid.float()

        if effective_mask.sum() > 0:
            # Replace invalid values with a safe placeholder before clamping
            safe_novel_alpha = torch.where(novel_valid, novel_alpha, torch.ones_like(novel_alpha))
            # Clamp for numerical stability in log
            novel_alpha_clamped = safe_novel_alpha.clamp(min=eps, max=1.0 - eps)
            # BCE(alpha, 1) = -log(alpha)
            novel_bce = -torch.log(novel_alpha_clamped)
            # masked_mean over the effective mask (Req 8.2, 8.3)
            novel_loss = masked_mean(novel_bce, effective_mask)
        else:
            # Zero novel loss when the mask selects no pixels (Req 8.3)
            novel_loss = torch.tensor(0.0, device=novel_alpha.device, dtype=novel_alpha.dtype)

        # --- Combined loss ---
        total_loss = input_loss + novel_loss

        # Check finiteness
        is_finite = bool(torch.isfinite(total_loss).item())

        diagnostics["input_loss"] = float(input_loss.detach())
        diagnostics["novel_loss"] = float(novel_loss.detach())
        diagnostics["mask_pixels"] = int(mask.sum().item())
        diagnostics["effective_mask_pixels"] = int(effective_mask.sum().item())
        diagnostics["input_excluded_pixels"] = input_excluded
        diagnostics["novel_excluded_pixels"] = novel_excluded

        return LossRecord(
            name=self.name,
            value=total_loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )
