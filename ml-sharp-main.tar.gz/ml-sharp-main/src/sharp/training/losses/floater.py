"""Floater-suppression loss module for the SHARP training framework.

Computes a per-Gaussian penalty based on the spatial gradient magnitude of the
input-view disparity map, sampled at each Gaussian's base NDC projection. The
penalty suppresses "floater" Gaussians that appear in regions of high disparity
gradient (depth discontinuities) where they are likely artifacts.

Formula:
    penalty_i = 1 - exp(-(1/sigma) * max(0, |grad_D_inv(pi(G0_i))| - epsilon))
    loss = mean(alpha_i * penalty_i)  over in-bounds Gaussians

where sigma = epsilon = 1e-2.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F

from sharp.training.types import LossContext, LossRecord


class FloaterLoss:
    """Floater-suppression regularizer via disparity gradient gating.

    Evaluates |nabla D^{-1}| at each Gaussian's image-plane projection,
    applies the exponential gating function, weights by opacity, and
    averages over in-bounds Gaussians only.

    Attributes:
        name: Identifier for the loss term.
        weight: Default weighting factor (lambda_grad).
    """

    name: str = "grad"
    weight: float = 0.5

    # Gating parameters
    _sigma: float = 1e-2
    _epsilon: float = 1e-2

    def __init__(self, weight: float = 0.5) -> None:
        self.name = "grad"
        self.weight = weight

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the floater-suppression loss.

        Args:
            ctx: LossContext providing disparity_pred, base_xy_ndc, and
                 gaussians (with opacities).

        Returns:
            LossRecord with the scalar floater loss.
        """
        diagnostics: dict = {}

        # --- Check required inputs ---
        if ctx.disparity_pred is None:
            return self._inactive("disparity_pred_absent")

        if ctx.base_xy_ndc is None:
            return self._inactive("base_xy_ndc_absent")

        if ctx.gaussians is None or not hasattr(ctx.gaussians, "opacities"):
            return self._inactive("gaussians_opacities_absent")

        # --- Step (a): Extract disparity layer 0 ---
        # disparity_pred: [B, 2, H, W] -> layer 0: [B, 1, H, W]
        disp_layer0 = ctx.disparity_pred[:, 0:1]  # [B, 1, H, W]

        # --- Step (b): Compute spatial gradient magnitude |nabla D^-1| ---
        grad_mag = self._compute_gradient_magnitude(disp_layer0)  # [B, 1, H, W]

        # --- Step (c): Sample gradient magnitude at base_xy_ndc positions ---
        # base_xy_ndc: [B, N, 2] in [-1, 1] NDC
        # grid_sample expects grid of shape [B, H_out, W_out, 2]
        # We treat our N points as a 1D "row" of sample locations: [B, 1, N, 2]
        base_xy = ctx.base_xy_ndc  # [B, N, 2]
        B, N, _ = base_xy.shape

        # Reshape for grid_sample: [B, 1, N, 2]
        grid = base_xy.unsqueeze(1)  # [B, 1, N, 2]

        # grid_sample: input [B, 1, H, W], grid [B, 1, N, 2] -> [B, 1, 1, N]
        sampled_grad = F.grid_sample(
            grad_mag,
            grid,
            mode="bilinear",
            padding_mode="zeros",
            align_corners=True,
        )
        # sampled_grad: [B, 1, 1, N] -> [B, N]
        sampled_grad = sampled_grad.squeeze(1).squeeze(1)  # [B, N]

        # --- Step (d): Compute per-Gaussian penalty ---
        # penalty_i = 1 - exp(-(1/sigma) * max(0, g_i - epsilon))
        g_minus_eps = torch.clamp(sampled_grad - self._epsilon, min=0.0)
        penalty = 1.0 - torch.exp(-(1.0 / self._sigma) * g_minus_eps)  # [B, N]

        # --- Step (e): Build in-bounds mask: |x| <= 1 and |y| <= 1 ---
        in_bounds = (base_xy[..., 0].abs() <= 1.0) & (base_xy[..., 1].abs() <= 1.0)  # [B, N]

        # --- Step (f): Weight by opacity ---
        opacities = ctx.gaussians.opacities  # [B, N]
        weighted_penalty = opacities * penalty  # [B, N]

        # --- Step (g): Mean over in-bounds Gaussians only ---
        in_bounds_count = in_bounds.sum()
        diagnostics["in_bounds_count"] = int(in_bounds_count.item())
        diagnostics["total_gaussians"] = int(B * N)

        # --- Step (h): Return 0.0 if no in-bounds Gaussians ---
        if in_bounds_count == 0:
            return LossRecord(
                name=self.name,
                value=torch.tensor(0.0, device=base_xy.device, dtype=base_xy.dtype),
                weight=self.weight,
                active=True,
                finite=True,
                diagnostics={**diagnostics, "reason": "no_in_bounds_gaussians"},
            )

        # Mean over in-bounds Gaussians
        loss = weighted_penalty[in_bounds].mean()

        is_finite = bool(torch.isfinite(loss).item())
        diagnostics["loss_value"] = float(loss.item()) if is_finite else float("nan")

        return LossRecord(
            name=self.name,
            value=loss,
            weight=self.weight,
            active=True,
            finite=is_finite,
            diagnostics=diagnostics,
        )

    def _compute_gradient_magnitude(self, disp: torch.Tensor) -> torch.Tensor:
        """Compute spatial gradient magnitude using finite differences (Sobel-like).

        Uses a 3x3 Sobel operator to compute horizontal and vertical gradients,
        then returns the magnitude sqrt(gx^2 + gy^2).

        Args:
            disp: Disparity map of shape [B, 1, H, W].

        Returns:
            Gradient magnitude [B, 1, H, W].
        """
        # Sobel kernels for horizontal and vertical gradients
        # These detect edges/gradients in the disparity field
        sobel_x = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            device=disp.device,
            dtype=disp.dtype,
        ).reshape(1, 1, 3, 3)

        sobel_y = torch.tensor(
            [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]],
            device=disp.device,
            dtype=disp.dtype,
        ).reshape(1, 1, 3, 3)

        # Apply Sobel filters with replicate padding to preserve spatial dims
        # Use replicate padding to avoid boundary artifacts on constant inputs
        disp_padded = F.pad(disp, (1, 1, 1, 1), mode="replicate")
        grad_x = F.conv2d(disp_padded, sobel_x)
        grad_y = F.conv2d(disp_padded, sobel_y)

        # Gradient magnitude
        grad_mag = torch.sqrt(grad_x**2 + grad_y**2 + 1e-8)  # small eps for stability

        return grad_mag

    def _inactive(self, reason: str) -> LossRecord:
        """Return an inactive loss record with the given reason."""
        return LossRecord(
            name=self.name,
            value=torch.tensor(0.0),
            weight=self.weight,
            active=False,
            finite=True,
            diagnostics={"reason": reason},
        )
