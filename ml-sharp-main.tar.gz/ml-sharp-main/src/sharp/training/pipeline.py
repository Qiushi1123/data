"""Training data pipelines for the SHARP training framework.

Provides:
  - TrainingSample: the full schema contract between data sources and the loop.
  - SampleSource: adapter protocol for dataset-specific implementations.
  - Stage1_Pipeline: yields fully-supervised samples (both views, GT depth),
    resized to 1536², with validation and disparity_factor computation.
  - Stage2_Pipeline: SSFT pipeline that consumes a frozen-teacher pseudo-view
    generator and constructs a role-swapped sample for self-supervised
    finetuning.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import Iterator, Protocol, runtime_checkable

import torch
import torch.nn.functional as F

from sharp.training.aggregator import STAGE2_ACTIVE_LOSSES
from sharp.training.camera import ViewCameras
from sharp.training.ssft import PseudoView

logger = logging.getLogger(__name__)

# Default internal resolution matching the predictor (predict_image uses 1536).
_DEFAULT_RESOLUTION: int = 1536

# Default step budget for Stage 1 training (Req 20.4).
_DEFAULT_STAGE1_STEPS: int = 100000

# Default step budget for Stage 2 SSFT (Req 21.4).
_DEFAULT_STAGE2_STEPS: int = 60000

class MissingDepthError(ValueError):
    """Raised when a Stage 1 sample is missing input-view ground-truth depth."""

    def __init__(self, sample_id: str = "unknown") -> None:
        super().__init__(
            f"Stage 1 sample '{sample_id}' is missing input-view ground-truth depth. "
            f"All Stage 1 samples must provide GT depth for the input view."
        )
        self.sample_id = sample_id


class MissingImageError(ValueError):
    """Raised when a sample is missing a required image."""

    def __init__(self, sample_id: str = "unknown", image_name: str = "image") -> None:
        super().__init__(
            f"Sample '{sample_id}' is missing required '{image_name}'. "
            f"Cannot proceed without both input and novel view images."
        )
        self.sample_id = sample_id
        self.image_name = image_name


class MissingCameraError(ValueError):
    """Raised when a sample is missing required camera parameters."""

    def __init__(self, sample_id: str = "unknown", missing_params: str = "") -> None:
        super().__init__(
            f"Sample '{sample_id}' is missing camera parameters: {missing_params}. "
            f"All four camera matrices (k_src, e_src, k_tgt, e_tgt) are required."
        )
        self.sample_id = sample_id
        self.missing_params = missing_params


class ImageResizeError(ValueError):
    """Raised when an image cannot be resized to the target resolution."""

    def __init__(
        self, sample_id: str = "unknown", image_name: str = "image", reason: str = ""
    ) -> None:
        super().__init__(
            f"Sample '{sample_id}': image '{image_name}' cannot be resized to "
            f"{_DEFAULT_RESOLUTION}x{_DEFAULT_RESOLUTION}. {reason}"
        )
        self.sample_id = sample_id
        self.image_name = image_name


@dataclasses.dataclass
class TrainingSample:
    """Full training sample schema for the SHARP training loop.

    This is the authoritative contract between data sources and the training
    loop. The minimal version in step.py is kept for backward compatibility
    with the step function; this version includes all fields the full pipeline
    can supply.

    Attributes:
        input_image: Input-view image [3, 1536, 1536] sRGB in [0, 1].
        novel_image: Novel-view image [3, 1536, 1536] sRGB in [0, 1].
        cameras: Source and target camera parameters (ViewCameras).
        disparity_factor: Scalar per sample (f_px / width) as a tensor.
        input_depth: Metric depth for input view (Stage 1 only) [1, H, W] or None.
        input_disparity: Disparity for input view [1, H, W] or None.
        novel_foreground_mask: Optional foreground mask for novel view [1, H, W].
    """

    input_image: torch.Tensor  # [3, 1536, 1536]
    novel_image: torch.Tensor  # [3, 1536, 1536]
    cameras: ViewCameras
    disparity_factor: torch.Tensor  # scalar tensor
    input_depth: torch.Tensor | None = None  # [1, H, W] metric depth
    input_disparity: torch.Tensor | None = None  # [1, H, W]
    novel_foreground_mask: torch.Tensor | None = None  # [1, H, W]


@dataclasses.dataclass
class RawSample:
    """Raw data item from a SampleSource before pipeline processing.

    Attributes:
        sample_id: Identifier for logging/error messages.
        input_image: Input-view image tensor [C, H, W] at any resolution.
        novel_image: Novel-view image tensor [C, H, W] at any resolution.
        cameras: Camera parameters (ViewCameras). Fields may be None.
        input_depth: Optional metric depth [1, H, W].
        input_disparity: Optional disparity [1, H, W].
        focal_length_px: Focal length in pixels for disparity_factor computation.
        image_width: Width of the original image (for disparity_factor).
        novel_foreground_mask: Optional foreground mask [1, H, W].
    """

    sample_id: str
    input_image: torch.Tensor | None = None
    novel_image: torch.Tensor | None = None
    cameras: ViewCameras | None = None
    input_depth: torch.Tensor | None = None
    input_disparity: torch.Tensor | None = None
    focal_length_px: float | None = None
    image_width: int | None = None
    novel_foreground_mask: torch.Tensor | None = None


@runtime_checkable
class SampleSource(Protocol):
    """Adapter protocol for dataset-specific data sources.

    Implementations translate dataset-native formats (e.g., Hypersim HDF5,
    SHARP-synthetic tar archives, on-disk image pairs) into RawSample objects
    that the pipeline validates, resizes, and converts to TrainingSample.

    This thin adapter seam allows concrete dataset implementations to be added
    without modifying the training loop or pipeline logic.
    """

    def __iter__(self) -> Iterator[RawSample]:
        """Yield raw samples from the underlying dataset."""
        ...

    def __len__(self) -> int:
        """Return the total number of available samples (may be approximate)."""
        ...


@runtime_checkable
class PseudoViewGenerator(Protocol):
    """Callable seam for Stage 2 frozen-teacher pseudo-view generation."""

    def __call__(
        self,
        real_image: torch.Tensor,
        disparity_factor: torch.Tensor,
        max_disparity: float | None = None,
    ) -> PseudoView:
        """Return a detached pseudo source view for a real target image."""
        ...


def _resize_image(
    image: torch.Tensor,
    target_size: int,
    sample_id: str,
    image_name: str,
) -> torch.Tensor:
    """Resize an image tensor to target_size × target_size.

    Args:
        image: Image tensor [C, H, W] with C >= 1.
        target_size: Target spatial resolution (both height and width).
        sample_id: For error messages.
        image_name: For error messages.

    Returns:
        Resized image [C, target_size, target_size].

    Raises:
        ImageResizeError: If the image cannot be resized.
    """
    if image.dim() != 3:
        raise ImageResizeError(
            sample_id,
            image_name,
            f"Expected 3D tensor [C, H, W], got shape {list(image.shape)}.",
        )

    C, H, W = image.shape
    if C == 0 or H == 0 or W == 0:
        raise ImageResizeError(
            sample_id,
            image_name,
            f"Image has zero-size dimension: shape {list(image.shape)}.",
        )

    if H == target_size and W == target_size:
        return image

    # Add batch dimension for F.interpolate: [1, C, H, W] -> [1, C, T, T]
    resized = F.interpolate(
        image.unsqueeze(0),
        size=(target_size, target_size),
        mode="bilinear",
        align_corners=False,
    ).squeeze(0)

    return resized


def _resize_depth(depth: torch.Tensor, target_size: int) -> torch.Tensor:
    """Resize a [1, H, W] (or [H, W]) map to [1, target, target] via nearest.

    Nearest interpolation preserves the 0-invalid boundary (no blending of valid
    depth with the background sentinel).
    """
    if depth.dim() == 2:
        depth = depth.unsqueeze(0)
    _, H, W = depth.shape
    if H == target_size and W == target_size:
        return depth
    resized = F.interpolate(
        depth.unsqueeze(0), size=(target_size, target_size), mode="nearest"
    ).squeeze(0)
    return resized


def _scale_cameras(
    cameras: ViewCameras, orig_w: int, orig_h: int, target: int
) -> ViewCameras:
    """Return a copy of `cameras` with intrinsics scaled to `target` resolution.

    Extrinsics are unchanged; only fx, fy, cx, cy are scaled by the resize
    factors so that projection matches rendering at `target x target`.
    """
    if orig_w == target and orig_h == target:
        return cameras
    xs = target / orig_w
    ys = target / orig_h

    def _scale_k(k: torch.Tensor | None) -> torch.Tensor | None:
        if k is None:
            return None
        k = k.clone()
        k[..., 0, 0] *= xs  # fx
        k[..., 0, 2] *= xs  # cx
        k[..., 1, 1] *= ys  # fy
        k[..., 1, 2] *= ys  # cy
        return k

    return ViewCameras(
        k_src=_scale_k(cameras.k_src),
        e_src=cameras.e_src,
        k_tgt=_scale_k(cameras.k_tgt),
        e_tgt=cameras.e_tgt,
    )


def _compute_disparity_factor(
    focal_length_px: float,
    image_width: int,
) -> torch.Tensor:
    """Compute disparity_factor = f_px / width.

    Args:
        focal_length_px: Focal length in pixels.
        image_width: Original image width.

    Returns:
        Scalar tensor with the disparity factor.
    """
    return torch.tensor(focal_length_px / image_width, dtype=torch.float32)


def _pseudo_depth_supervision(
    *,
    pseudo_view: PseudoView,
    disparity_factor: torch.Tensor,
    dtype: torch.dtype,
    alpha_threshold: float = 0.5,
) -> tuple[torch.Tensor | None, torch.Tensor | None]:
    """Convert teacher-rendered pseudo depth into Stage-2 depth supervision.

    The paper does not publish the exact SSFT depth recipe. For the depth-anchored
    implementation we treat the frozen teacher render as weak geometry
    supervision, and mark invalid/transparent teacher pixels as zero so
    ``DepthLoss`` ignores them through its existing ``gt_disparity > 0`` mask.
    """
    if pseudo_view.depth is None:
        return None, None

    depth = pseudo_view.depth.detach().to(dtype=dtype)
    if depth.dim() == 2:
        depth = depth.unsqueeze(0)
    if depth.dim() != 3:
        return None, None

    valid = torch.isfinite(depth) & (depth > 1e-6)

    if pseudo_view.alpha is not None:
        alpha = pseudo_view.alpha.detach().to(device=depth.device, dtype=dtype)
        if alpha.dim() == 2:
            alpha = alpha.unsqueeze(0)
        if alpha.shape == depth.shape:
            valid = valid & torch.isfinite(alpha) & (alpha > alpha_threshold)

    safe_depth = torch.where(valid, depth.clamp_min(1e-6), torch.zeros_like(depth))
    disparity_factor = disparity_factor.to(device=safe_depth.device, dtype=dtype).reshape(())
    disparity = torch.where(
        valid,
        disparity_factor / safe_depth.clamp_min(1e-6),
        torch.zeros_like(safe_depth),
    )
    return safe_depth, disparity


def _validate_cameras_complete(cameras: ViewCameras | None, sample_id: str) -> None:
    """Validate that all four camera parameter matrices are present.

    Args:
        cameras: The ViewCameras to check.
        sample_id: For error messages.

    Raises:
        MissingCameraError: If any parameter is None.
    """
    if cameras is None:
        raise MissingCameraError(sample_id, "all camera parameters (cameras is None)")

    missing = []
    if cameras.k_src is None:
        missing.append("k_src")
    if cameras.e_src is None:
        missing.append("e_src")
    if cameras.k_tgt is None:
        missing.append("k_tgt")
    if cameras.e_tgt is None:
        missing.append("e_tgt")

    if missing:
        raise MissingCameraError(sample_id, ", ".join(missing))


class Stage1_Pipeline:
    """Stage 1 synthetic data pipeline with full supervision.

    Yields TrainingSample objects from a SampleSource, validating completeness,
    resizing images to 1536×1536, computing disparity_factor, and raising
    identifying errors for any missing or invalid data.

    The pipeline is iterable: `for sample in pipeline` yields validated
    TrainingSample instances up to `total_steps`.

    Args:
        source: A SampleSource adapter providing raw samples.
        total_steps: Maximum number of training samples to yield (default 100000).
        resolution: Target spatial resolution (default 1536).
    """

    def __init__(
        self,
        source: SampleSource,
        total_steps: int = _DEFAULT_STAGE1_STEPS,
        resolution: int = _DEFAULT_RESOLUTION,
    ) -> None:
        self._source = source
        self._total_steps = total_steps
        self._resolution = resolution

    @property
    def total_steps(self) -> int:
        """The configured step budget for this pipeline."""
        return self._total_steps

    def __iter__(self) -> Iterator[TrainingSample]:
        """Yield validated, resized TrainingSample objects.

        Iterates over the source in a cyclic fashion until total_steps samples
        have been yielded. If the source is exhausted before reaching
        total_steps, it restarts from the beginning.

        Yields:
            TrainingSample with all fields populated for Stage 1.

        Raises:
            MissingDepthError: If a sample lacks input GT depth.
            MissingImageError: If a sample lacks input or novel image.
            MissingCameraError: If a sample lacks required camera parameters.
            ImageResizeError: If an image cannot be resized.
        """
        steps_yielded = 0

        while steps_yielded < self._total_steps:
            for raw in self._source:
                if steps_yielded >= self._total_steps:
                    return

                sample = self._process_raw_sample(raw)
                yield sample
                steps_yielded += 1

            # If we exhaust the source before total_steps, loop again.
            # (Cyclic iteration over finite datasets.)
            if steps_yielded < self._total_steps:
                logger.debug(
                    "Source exhausted at step %d/%d, restarting.",
                    steps_yielded,
                    self._total_steps,
                )

    def _process_raw_sample(self, raw: RawSample) -> TrainingSample:
        """Validate and transform a RawSample into a TrainingSample.

        Args:
            raw: The raw sample from the source.

        Returns:
            A validated, resized TrainingSample.

        Raises:
            MissingDepthError: If GT depth is missing (Req 20.5).
            MissingImageError: If an image is missing (Req 20.6).
            MissingCameraError: If cameras are incomplete (Req 20.6).
            ImageResizeError: If an image cannot be resized (Req 20.7).
        """
        sid = raw.sample_id

        # --- Validate input image (Req 20.6) ---
        if raw.input_image is None:
            raise MissingImageError(sid, "input_image")

        # --- Validate novel image (Req 20.6) ---
        if raw.novel_image is None:
            raise MissingImageError(sid, "novel_image")

        # --- Validate cameras (Req 20.6) ---
        _validate_cameras_complete(raw.cameras, sid)

        # --- Validate input depth (Req 20.5) ---
        if raw.input_depth is None:
            raise MissingDepthError(sid)

        # Original spatial size, used to scale intrinsics and resize depth/mask
        # consistently with the RGB resize.
        orig_h = int(raw.input_image.shape[-2])
        orig_w = int(raw.input_image.shape[-1])

        # --- Resize images to target resolution (Req 20.2, 20.7) ---
        input_image = _resize_image(
            raw.input_image, self._resolution, sid, "input_image"
        )
        novel_image = _resize_image(
            raw.novel_image, self._resolution, sid, "novel_image"
        )

        # --- Compute disparity_factor (Req 20.3) ---
        # disparity_factor = f_px / width is invariant to uniform resize, so it
        # is computed from the original intrinsics/width.
        if raw.focal_length_px is not None and raw.image_width is not None:
            disparity_factor = _compute_disparity_factor(
                raw.focal_length_px, raw.image_width
            )
        else:
            # Fallback: extract from k_src intrinsics (f_px = K[0,0])
            # and original image width
            assert raw.cameras is not None
            k_src = raw.cameras.k_src
            assert k_src is not None
            # k_src can be [3,3] or [B,3,3]; handle both
            if k_src.dim() == 3:
                f_px = k_src[0, 0, 0].item()
            else:
                f_px = k_src[0, 0].item()

            disparity_factor = _compute_disparity_factor(f_px, orig_w)

        # --- Resize depth (nearest) to keep the 0-invalid boundary crisp ---
        input_depth = _resize_depth(raw.input_depth, self._resolution)  # [1, res, res]

        # --- Derive input disparity for the depth loss (Req 9): disparity =
        # disparity_factor / depth on valid (>0) pixels, 0 elsewhere. ---
        input_disparity = raw.input_disparity
        if input_disparity is None:
            valid = input_depth > 0
            input_disparity = torch.zeros_like(input_depth)
            input_disparity[valid] = disparity_factor.to(input_depth.dtype) / input_depth[valid]
        else:
            input_disparity = _resize_depth(input_disparity, self._resolution)

        # --- Resize novel foreground mask if present (nearest) ---
        novel_fg = raw.novel_foreground_mask
        if novel_fg is not None:
            novel_fg = _resize_depth(novel_fg, self._resolution)

        # --- Scale intrinsics to the resized resolution (Req 3/4 correctness).
        # Rendering happens at `self._resolution`, so K must be scaled from the
        # original image size accordingly. ---
        cameras = _scale_cameras(raw.cameras, orig_w, orig_h, self._resolution)  # type: ignore[arg-type]

        # --- Build TrainingSample (Req 20.1) ---
        return TrainingSample(
            input_image=input_image,
            novel_image=novel_image,
            cameras=cameras,
            disparity_factor=disparity_factor,
            input_depth=input_depth,
            input_disparity=input_disparity,
            novel_foreground_mask=novel_fg,
        )

    def __len__(self) -> int:
        """Return the total number of steps the pipeline will yield."""
        return self._total_steps


class Stage2ReplayPipeline:
    """Interleave Stage-2 SSFT samples with Stage-1 supervised replay samples.

    The wrapper keeps Stage-2 as the dominant stream and inserts synthetic
    Stage-1 samples at a deterministic ratio. This supports SSFT experiments
    with synthetic replay for geometry retention without changing the training
    loop or sample contract.
    """

    def __init__(
        self,
        stage2_pipeline: Stage2_Pipeline,
        stage1_pipeline: Stage1_Pipeline,
        *,
        stage1_replay_ratio: float,
        total_steps: int,
    ) -> None:
        if not 0.0 <= stage1_replay_ratio <= 1.0:
            raise ValueError("stage1_replay_ratio must be in [0, 1]")
        self._stage2_pipeline = stage2_pipeline
        self._stage1_pipeline = stage1_pipeline
        self._stage1_replay_ratio = stage1_replay_ratio
        self._total_steps = total_steps

    @property
    def total_steps(self) -> int:
        """The configured step budget for this pipeline."""
        return self._total_steps

    def __iter__(self) -> Iterator[TrainingSample]:
        """Yield a deterministic mix of SSFT and synthetic replay samples."""
        stage2_iter = iter(self._stage2_pipeline)
        stage1_iter = iter(self._stage1_pipeline)
        replay_accumulator = 0.0

        for _ in range(self._total_steps):
            replay_accumulator += self._stage1_replay_ratio
            if replay_accumulator >= 1.0:
                replay_accumulator -= 1.0
                yield next(stage1_iter)
            else:
                yield next(stage2_iter)

    def __len__(self) -> int:
        """Return the total number of mixed samples to yield."""
        return self._total_steps



class InvalidInputError(ValueError):
    """Raised when Stage 2 receives an unreadable or wrong-resolution input."""

    def __init__(self, sample_id: str = "unknown", reason: str = "") -> None:
        super().__init__(
            f"Stage 2 sample '{sample_id}' is invalid: {reason}. "
            f"Cannot generate pseudo-novel view."
        )
        self.sample_id = sample_id
        self.reason = reason


class Stage2_Pipeline:
    """Stage 2 SSFT (self-supervised finetuning) pipeline.

    Uses a frozen Stage-1 teacher generator to render a detached pseudo-novel
    view from a real single-view image, then constructs a role-swapped
    TrainingSample where:
      - input_image = pseudo-novel rendered image (detached, no gradient)
      - novel_image = original real image (the target for supervision)
      - input_depth = teacher-rendered pseudo depth when available

    The pseudo-view generator owns the ``torch.no_grad()`` and detach boundary,
    so gradients are computed only for the swapped supervised student pass.

    Args:
        source: A SampleSource providing real single-view images as RawSamples.
            Each RawSample must have ``input_image`` (the real image) and
            ``focal_length_px`` / ``image_width`` (or k_src intrinsics) for
            disparity_factor computation. ``novel_image`` and cameras may be
            None (they are constructed by the pipeline).
        pseudo_view_generator: Frozen-teacher callable that returns detached
            pseudo RGB, pseudo camera, original camera, and optional geometry.
        total_steps: Maximum number of training samples to yield (default 60000).
        resolution: Target spatial resolution (default 1536).
    """

    def __init__(
        self,
        source: SampleSource,
        pseudo_view_generator: PseudoViewGenerator,
        total_steps: int = _DEFAULT_STAGE2_STEPS,
        resolution: int = _DEFAULT_RESOLUTION,
        pseudo_depth_mode: str = "rendered_alignment",
        pseudo_depth_alpha_threshold: float = 0.5,
        pseudo_view_disparities: list[float] | None = None,
        pseudo_view_pose_strategy: str = "random_near",
    ) -> None:
        self._source = source
        self._pseudo_view_generator = pseudo_view_generator
        self._total_steps = total_steps
        self._resolution = resolution
        self._pseudo_view_disparities = tuple(pseudo_view_disparities or ())
        if any(disparity <= 0 for disparity in self._pseudo_view_disparities):
            raise ValueError("pseudo_view_disparities must contain positive values")
        if pseudo_view_pose_strategy not in {"random_near", "horizontal_symmetric"}:
            raise ValueError(
                "pseudo_view_pose_strategy must be one of: random_near, horizontal_symmetric"
            )
        if pseudo_view_pose_strategy == "horizontal_symmetric" and not self._pseudo_view_disparities:
            raise ValueError(
                "horizontal_symmetric pseudo-view sampling requires pseudo_view_disparities"
            )
        if pseudo_depth_mode not in {"none", "rendered_loss", "rendered_alignment"}:
            raise ValueError(
                "pseudo_depth_mode must be one of: none, rendered_loss, rendered_alignment"
            )
        self._pseudo_depth_mode = pseudo_depth_mode
        self._pseudo_depth_alpha_threshold = pseudo_depth_alpha_threshold
        self._pseudo_view_pose_strategy = pseudo_view_pose_strategy

    @property
    def total_steps(self) -> int:
        """The configured step budget for this pipeline."""
        return self._total_steps

    @property
    def active_losses(self) -> set[str]:
        """The Stage 2 active loss set for pseudo-depth-capable SSFT.

        Validates: Requirement 21.5
        """
        return set(STAGE2_ACTIVE_LOSSES)

    def __iter__(self) -> Iterator[TrainingSample]:
        """Yield role-swapped TrainingSample objects for Stage 2 SSFT.

        For each real input image from the source:
        1. Validate the image is readable and matches expected resolution.
        2. Ask the frozen-teacher pseudo-view generator for a detached nearby
           pseudo source view.
        3. Construct a TrainingSample with:
           - input_image = detached pseudo-novel rendering
           - novel_image = original real image
           - cameras = swapped near-source cameras
           - input_depth = detached teacher pseudo depth when available

        Iterates cyclically over the source until total_steps is reached.

        Yields:
            TrainingSample suitable for Stage 2 self-supervised finetuning.

        Raises:
            InvalidInputError: If input cannot be processed (Req 21.2).
        """
        steps_yielded = 0

        while steps_yielded < self._total_steps:
            for raw in self._source:
                if steps_yielded >= self._total_steps:
                    return

                disparities = self._iter_pseudo_disparities()
                for pseudo_disparity in disparities:
                    if steps_yielded >= self._total_steps:
                        return
                    sample = self._process_raw_sample(raw, pseudo_disparity)
                    yield sample
                    steps_yielded += 1

            # Cyclic iteration over finite datasets.
            if steps_yielded < self._total_steps:
                logger.debug(
                    "Stage 2 source exhausted at step %d/%d, restarting.",
                    steps_yielded,
                    self._total_steps,
                )

    def _iter_pseudo_disparities(self) -> tuple[float | None, ...]:
        if not self._pseudo_view_disparities:
            return (None,)
        if self._pseudo_view_pose_strategy == "horizontal_symmetric":
            return tuple(
                signed
                for disparity in self._pseudo_view_disparities
                for signed in (-disparity, disparity)
            )
        return self._pseudo_view_disparities

    def _process_raw_sample(
        self,
        raw: RawSample,
        pseudo_view_max_disparity: float | None = None,
    ) -> TrainingSample:
        """Validate and transform a RawSample for Stage 2 SSFT.

        Args:
            raw: Raw sample with at least a real input image.

        Returns:
            A role-swapped TrainingSample for self-supervised training.

        Raises:
            InvalidInputError: If input is not a readable single-view RGB image
                or resolution doesn't match (Req 21.2).
        """
        sid = raw.sample_id

        # --- Validate input image (Req 21.2) ---
        if raw.input_image is None:
            raise InvalidInputError(sid, "input_image is None (not readable)")

        if raw.input_image.dim() != 3:
            raise InvalidInputError(
                sid,
                f"Expected 3D tensor [C, H, W], got shape {list(raw.input_image.shape)}",
            )

        C, H, W = raw.input_image.shape
        if C not in (3, 4):
            raise InvalidInputError(
                sid,
                f"Expected 3 or 4 channels (RGB/RGBA), got {C} channels",
            )

        # Take only RGB channels if RGBA.
        input_image = raw.input_image[:3]

        # Validate/resize to target resolution (Req 21.1 — render at input resolution).
        if H != self._resolution or W != self._resolution:
            # Reject if resolution is fundamentally wrong (e.g., 0-sized).
            if H == 0 or W == 0:
                raise InvalidInputError(
                    sid,
                    f"Image has zero-size dimension: shape {list(raw.input_image.shape)}",
                )
            # Resize to model's configured resolution.
            input_image = F.interpolate(
                input_image.unsqueeze(0),
                size=(self._resolution, self._resolution),
                mode="bilinear",
                align_corners=False,
            ).squeeze(0)

        # --- Compute disparity_factor ---
        if raw.focal_length_px is not None and raw.image_width is not None:
            disparity_factor = _compute_disparity_factor(
                raw.focal_length_px, raw.image_width
            )
        else:
            # Fallback: extract from k_src intrinsics.
            if raw.cameras is not None and raw.cameras.k_src is not None:
                k_src = raw.cameras.k_src
                if k_src.dim() == 3:
                    f_px = k_src[0, 0, 0].item()
                else:
                    f_px = k_src[0, 0].item()
                original_width = W  # original input width
                disparity_factor = _compute_disparity_factor(f_px, original_width)
            else:
                # Use a reasonable default: assume f_px ≈ width (~ 90° FOV).
                disparity_factor = torch.tensor(1.0, dtype=torch.float32)

        pseudo_view = self._pseudo_view_generator(
            input_image,
            disparity_factor,
            max_disparity=pseudo_view_max_disparity,
        )
        pseudo_novel_image = pseudo_view.image.detach().clamp(0.0, 1.0)

        # --- Build cameras for the role-swapped sample ---
        # In the swapped sample:
        #   - input_image = pseudo-novel (rendered from e_tgt pose)
        #   - novel_image = real image (at identity/e_src pose)
        # So the "source" camera for the swapped sample is e_tgt (where
        # the pseudo-novel was rendered from), and the "target" camera is
        # e_src (identity, where the real image lives).
        k_src_swapped = pseudo_view.intrinsics[0]
        e_src_swapped = pseudo_view.pseudo_extrinsics[0]
        k_tgt_swapped = pseudo_view.intrinsics[0]
        e_tgt_swapped = pseudo_view.original_extrinsics[0]

        cameras = ViewCameras(
            k_src=k_src_swapped.unsqueeze(0),  # [1, 3, 3]
            e_src=e_src_swapped.unsqueeze(0),  # [1, 4, 4]
            k_tgt=k_tgt_swapped.unsqueeze(0),  # [1, 3, 3]
            e_tgt=e_tgt_swapped.unsqueeze(0),  # [1, 4, 4]
        )

        # --- Compute disparity_factor for the swapped input ---
        # The pseudo-novel view is rendered at the same intrinsics, so the
        # disparity factor is the same as the original.
        swapped_disparity_factor = disparity_factor

        input_depth, input_disparity = _pseudo_depth_supervision(
            pseudo_view=pseudo_view,
            disparity_factor=swapped_disparity_factor,
            dtype=pseudo_novel_image.dtype,
            alpha_threshold=self._pseudo_depth_alpha_threshold,
        )

        if self._pseudo_depth_mode == "none":
            input_depth = None
            input_disparity = None
        elif self._pseudo_depth_mode == "rendered_loss":
            # Keep teacher-rendered disparity available to DepthLoss, but do not
            # pass the rendered metric depth into DepthAlignment. This separates
            # weak geometry supervision from the training-only scale-map path.
            input_depth = None

        # --- Build role-swapped TrainingSample (Req 21.3) ---
        return TrainingSample(
            input_image=pseudo_novel_image,  # pseudo-novel = input
            novel_image=input_image,  # real image = novel target
            cameras=cameras,
            disparity_factor=swapped_disparity_factor,
            input_depth=input_depth,
            input_disparity=input_disparity,
            novel_foreground_mask=None,
        )

    def __len__(self) -> int:
        """Return the total number of steps the pipeline will yield."""
        return self._total_steps
