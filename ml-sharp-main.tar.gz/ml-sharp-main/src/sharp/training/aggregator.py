"""Loss aggregator for the SHARP training framework.

Combines weighted loss terms into a single scalar for backward. Handles
non-finite terms gracefully, records per-term diagnostics, and produces a
warning when no term is active.

Provides a factory function ``create_aggregator`` that instantiates all ten
loss modules with weights from ``LossWeights`` and selects active terms from
``StageConfig.active_losses``.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING

import torch

from sharp.training.types import AggregateResult, LossContext, LossRecord

if TYPE_CHECKING:
    from sharp.training.config import LossWeights, StageConfig
    from sharp.training.types import LossModule

logger = logging.getLogger(__name__)


class LossAggregator:
    """Aggregates active, finite loss terms into a single rank-0 scalar.

    Sums ``λ_k · L_k`` over active, finite terms into one graph-connected
    scalar (Req 16.1–16.2). Records unweighted and weighted values per term
    (Req 16.3). Non-finite active terms are excluded and reported (Req 16.4);
    inactive terms are excluded silently (Req 16.5); if nothing is active,
    returns ``0.0`` with a warning (Req 16.6).

    Attributes:
        modules: List of loss modules to evaluate.
        active_names: Set of loss term names that are active for the current
            stage.
    """

    def __init__(
        self, modules: list[LossModule], active_names: set[str]
    ) -> None:
        self.modules = modules
        self.active_names = active_names

    def aggregate(self, ctx: LossContext) -> AggregateResult:
        """Compute the total weighted loss over active, finite terms.

        Args:
            ctx: LossContext providing all inputs needed by loss modules.

        Returns:
            AggregateResult containing:
              - total: rank-0 tensor (weighted sum, graph-connected)
              - records: per-term LossRecord list (active terms only)
              - skipped: names of non-finite active terms excluded from total
        """
        records: list[LossRecord] = []
        skipped: list[str] = []
        weighted_terms: list[torch.Tensor] = []

        for module in self.modules:
            # Req 16.5: inactive terms excluded silently
            if module.name not in self.active_names:
                continue

            # Evaluate the loss module
            record = module(ctx)
            records.append(record)

            # Loss modules may be configured as stage-active but return an
            # inactive record when their required supervision is unavailable
            # for the current sample (e.g. Stage-2 real images without depth).
            # Keep the record for diagnostics, but exclude it from the total.
            if not record.active:
                continue

            # Req 16.4: non-finite active terms excluded, reported by name
            if not torch.isfinite(record.value):
                skipped.append(record.name)
                logger.warning(
                    "Non-finite loss term '%s' excluded from total.",
                    record.name,
                )
                continue

            # Accumulate weighted term (preserves autograd graph)
            weighted_term = record.weight * record.value
            weighted_terms.append(weighted_term)

        # Req 16.6: if nothing is active/contributed, return 0.0 with warning
        if not weighted_terms:
            warnings.warn(
                "No active loss terms contributed to the total loss.",
                stacklevel=2,
            )
            skipped.append("__no_active_terms__")
            total = torch.tensor(0.0)
            return AggregateResult(total=total, records=records, skipped=skipped)

        # Req 16.1–16.2: sum into one rank-0 graph-connected scalar
        total = torch.stack(weighted_terms).sum()

        return AggregateResult(total=total, records=records, skipped=skipped)



# ---------------------------------------------------------------------------
# Stage 2 default active losses: paper-like SSFT with frozen-teacher pseudo
# geometry. The pseudo depth is not real GT, so experiment configs should keep
# the depth/scale weights weaker than Stage 1 when using this set.
# ---------------------------------------------------------------------------
STAGE2_ACTIVE_LOSSES: set[str] = {
    "color",
    "perceptual",
    "alpha",
    "depth",
    "tv",
    "grad",
    "delta",
    "splat",
    "scale",
    "grad_scale",
}

# Stage 1 includes all losses (GT depth and novel-view GT are available).
STAGE1_ACTIVE_LOSSES: set[str] = {
    "color",
    "perceptual",
    "alpha",
    "depth",
    "tv",
    "grad",
    "delta",
    "splat",
    "scale",
    "grad_scale",
}


def create_aggregator(
    weights: LossWeights,
    stage: StageConfig,
    *,
    device: torch.device | None = None,
) -> LossAggregator:
    """Build a LossAggregator with all ten loss modules and stage selection.

    Instantiates each loss module with its weight from the ``LossWeights``
    config and determines the active set from ``StageConfig.active_losses``.

    Args:
        weights: Per-term loss weights from the training configuration.
        stage: Stage configuration providing the ``active_losses`` set.
        device: Optional device for modules that carry parameters (e.g.
            PerceptualLoss with its ResNet-50 feature extractor).

    Returns:
        A configured ``LossAggregator`` ready for use in the training loop.

    Validates: Requirements 16.1, 16.5, 21.5
    """
    from sharp.training.losses import (
        AlphaLoss,
        ColorLoss,
        DeltaLoss,
        DepthLoss,
        FloaterLoss,
        GradScaleLoss,
        PerceptualLoss,
        ScaleLoss,
        SplatLoss,
        TVLoss,
    )

    # Instantiate all ten loss modules with weights from config
    modules: list[LossModule] = [
        ColorLoss(weight=weights.color),
        PerceptualLoss(weight=weights.perceptual, device=device),
        AlphaLoss(weight=weights.alpha),
        DepthLoss(weight=weights.depth),
        TVLoss(weight=weights.tv),
        FloaterLoss(weight=weights.grad),
        DeltaLoss(weight=weights.delta),
        SplatLoss(weight=weights.splat),
        ScaleLoss(weight=weights.scale),
        GradScaleLoss(weight=weights.grad_scale),
    ]

    # Determine active losses from stage config (Req 16.5, 21.5)
    active_names: set[str] = set(stage.active_losses)

    return LossAggregator(modules=modules, active_names=active_names)
