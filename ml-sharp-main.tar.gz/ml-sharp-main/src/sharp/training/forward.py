"""Training-mode forward pass for the SHARP predictor.

Mirrors `RGBGaussianPredictor.forward` exactly but keeps autograd enabled
(no `torch.no_grad`) and surfaces intermediates that the training losses require:
the Scale_Map `S`, aligned two-layer depth, disparity prediction, base-Gaussian
NDC projections, and raw monodepth disparity.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses

import torch
from torch import nn

from sharp.models.predictor import RGBGaussianPredictor
from sharp.utils.gaussians import Gaussians3D


@dataclasses.dataclass
class TrainingOutputs:
    """Bundle of intermediates produced by the training forward pass.

    Attributes:
        gaussians: Composed 3D Gaussians (graph-connected, requires_grad=True).
        aligned_depth: [B, 2, H, W] metric depth after alignment.
        disparity_pred: [B, 2, H, W] = disparity_factor / aligned_depth.
        scale_map: S from DepthAlignment; None when GT depth is not provided.
        base_xy_ndc: [B, N, 2] base Gaussian projections pi(G0) in [-1, 1] NDC.
        monodepth_disparity: Raw pre-alignment 2-layer disparity from monodepth.
    """

    gaussians: Gaussians3D
    aligned_depth: torch.Tensor
    disparity_pred: torch.Tensor
    scale_map: torch.Tensor | None
    base_xy_ndc: torch.Tensor
    monodepth_disparity: torch.Tensor


class TrainingForward(nn.Module):
    """Training-mode forward wrapper around RGBGaussianPredictor.

    Re-runs the predictor's submodule sequence with autograd ON, returning
    a `TrainingOutputs` bundle that exposes intermediates discarded by the
    inference `forward`.

    Gradient checkpointing is honored via the existing `checkpoint_wrapper`
    pattern when the submodules have `grad_checkpointing=True`.
    """

    def __init__(self, predictor: RGBGaussianPredictor) -> None:
        """Initialize TrainingForward.

        Args:
            predictor: The existing RGBGaussianPredictor whose submodules are
                re-used (shared parameters, no duplication).
        """
        super().__init__()
        # Store a reference — parameters are shared, not duplicated.
        self.predictor = predictor

    def forward(
        self,
        image: torch.Tensor,
        disparity_factor: torch.Tensor,
        depth: torch.Tensor | None = None,
    ) -> TrainingOutputs:
        """Run the predictor pipeline with autograd enabled.

        This mirrors ``RGBGaussianPredictor.forward`` step-by-step but:
        1. Keeps the ``depth_alignment_map`` (Scale_Map S) instead of discarding it.
        2. Captures ``base_xy_ndc`` from the initializer output.
        3. Returns all intermediates needed by training losses.
        4. Never wraps any step in ``torch.no_grad()``.

        Args:
            image: Input image tensor [B, 3, H, W].
            disparity_factor: Factor to convert depth to disparities [B].
            depth: Optional ground-truth depth for alignment [B, 1, H, W].

        Returns:
            TrainingOutputs with all required intermediates.
        """
        predictor = self.predictor

        # Step 1: Monodepth estimation.
        monodepth_output = predictor.monodepth_model(image)
        monodepth_disparity = monodepth_output.disparity  # [B, 2, H, W]

        disparity_factor_expanded = disparity_factor[:, None, None, None]
        monodepth = disparity_factor_expanded / monodepth_disparity.clamp(min=1e-4, max=1e4)

        # Step 2: Depth alignment — keep the Scale_Map S.
        aligned_depth, depth_alignment_map = predictor.depth_alignment(
            monodepth,
            depth,
            monodepth_output.decoder_features,
        )

        # Determine scale_map: None when no GT depth was provided (S is just ones).
        if depth is not None:
            scale_map = depth_alignment_map
        else:
            scale_map = None

        # Step 3: Initializer — produces base Gaussian values and features.
        init_output = predictor.init_model(image, aligned_depth)

        # Step 4: Feature model (gaussian decoder).
        image_features = predictor.feature_model(
            init_output.feature_input, encodings=monodepth_output.output_features
        )

        # Step 5: Prediction head.
        delta_values = predictor.prediction_head(image_features)

        # Step 6: Gaussian composer.
        gaussians = predictor.gaussian_composer(
            delta=delta_values,
            base_values=init_output.gaussian_base_values,
            global_scale=init_output.global_scale,
        )

        # --- Capture intermediates ---

        # Disparity prediction: disparity_factor / aligned_depth
        disparity_pred = disparity_factor_expanded / aligned_depth.clamp(min=1e-4)

        # Base XY NDC: from the initializer's gaussian_base_values.
        # mean_x_ndc and mean_y_ndc are [B, 1, num_layers, H_base, W_base].
        # Flatten to [B, N, 2] where N = num_layers * H_base * W_base.
        base_values = init_output.gaussian_base_values
        mean_x = base_values.mean_x_ndc  # [B, 1, num_layers, H, W]
        mean_y = base_values.mean_y_ndc  # [B, 1, num_layers, H, W]

        # Flatten spatial dimensions: [B, 1, L, H, W] -> [B, L*H*W]
        batch_size = mean_x.shape[0]
        mean_x_flat = mean_x.reshape(batch_size, -1)  # [B, N]
        mean_y_flat = mean_y.reshape(batch_size, -1)  # [B, N]

        # Stack into [B, N, 2]
        base_xy_ndc = torch.stack([mean_x_flat, mean_y_flat], dim=-1)

        return TrainingOutputs(
            gaussians=gaussians,
            aligned_depth=aligned_depth,
            disparity_pred=disparity_pred,
            scale_map=scale_map,
            base_xy_ndc=base_xy_ndc,
            monodepth_disparity=monodepth_disparity,
        )
