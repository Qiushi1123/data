"""Checkpoint manager for SHARP training.

Saves and restores training state (model weights, optimizer state, scheduler
state, step counter) with atomic writes to prevent corruption on failure.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import os
import pathlib
import tempfile
from typing import Any

import torch
import torch.nn as nn


class CheckpointManager:
    """Manages periodic checkpoint saving and resuming for training.

    Saves ``{model_state_dict, optimizer_state_dict, scheduler_state, step}``
    as a single file every ``checkpoint_interval`` steps. Uses atomic writes
    (temp file + rename) so a failed save preserves the last good checkpoint.

    Resume validates presence of all four components and a non-negative integer
    step counter; rejects invalid checkpoints with a ``ValueError`` retaining
    the caller's pre-load state.
    """

    def __init__(self, output_dir: pathlib.Path, checkpoint_interval: int) -> None:
        """Initialize the checkpoint manager.

        Args:
            output_dir: Directory where checkpoint files are written.
            checkpoint_interval: Save a checkpoint every this many steps.
        """
        if checkpoint_interval < 1:
            raise ValueError(
                f"checkpoint_interval must be >= 1, got {checkpoint_interval}"
            )
        self.output_dir = pathlib.Path(output_dir)
        self.checkpoint_interval = checkpoint_interval

    def should_save(self, step: int) -> bool:
        """Return True if a checkpoint should be saved at this step.

        A checkpoint is saved at every positive-integer multiple of
        ``checkpoint_interval``.

        Args:
            step: Current training step (0-indexed).

        Returns:
            True if ``step > 0`` and ``step % checkpoint_interval == 0``.
        """
        return step > 0 and step % self.checkpoint_interval == 0

    def save(
        self,
        predictor: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler_state: int,
        step: int,
    ) -> pathlib.Path:
        """Atomically save a checkpoint.

        Writes to a temporary file first, then renames to the final path.
        This ensures the last good checkpoint is preserved on save failure
        (Req 19.5).

        The model_state_dict is ``predictor.state_dict()`` so the existing
        predict CLI's ``load_state_dict`` loads it without key/shape mismatch
        (Req 19.3).

        Args:
            predictor: The model (RGBGaussianPredictor or compatible nn.Module).
            optimizer: The optimizer whose state_dict is saved.
            scheduler_state: The scheduler state (step counter for LambdaLR).
            step: Current training step counter.

        Returns:
            Path to the saved checkpoint file.

        Raises:
            OSError: If the save fails (the previous checkpoint is preserved).
        """
        self.output_dir.mkdir(parents=True, exist_ok=True)

        checkpoint_data = {
            "model_state_dict": predictor.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state": scheduler_state,
            "step": step,
        }

        filename = f"checkpoint_{step:08d}.pt"
        final_path = self.output_dir / filename

        # Atomic write: save to temp file in the same directory, then rename.
        # os.replace is atomic on POSIX systems when source and dest are on
        # the same filesystem.
        fd = None
        tmp_path = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.output_dir), suffix=".tmp"
            )
            os.close(fd)
            fd = None
            torch.save(checkpoint_data, tmp_path)
            os.replace(tmp_path, final_path)
        except Exception:
            # Clean up temp file if it exists
            if tmp_path is not None and os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
            raise

        return final_path

    def load(self, path: str | pathlib.Path) -> dict[str, Any]:
        """Load and validate a checkpoint file.

        Validates that all four required components are present and that the
        step counter is a non-negative integer. Raises ``ValueError`` on
        invalid checkpoints so the caller can retain pre-load state (Req 19.6).

        Args:
            path: Path to the checkpoint file.

        Returns:
            Dictionary with keys: model_state_dict, optimizer_state_dict,
            scheduler_state, step.

        Raises:
            FileNotFoundError: If the checkpoint path does not exist (Req 19.4).
            ValueError: If the checkpoint is missing components or has an
                invalid step counter (Req 18.6, 19.6).
        """
        path = pathlib.Path(path)
        if not path.exists():
            raise FileNotFoundError(
                f"Checkpoint path does not exist: {path}"
            )

        try:
            checkpoint = torch.load(path, map_location="cpu", weights_only=False)
        except Exception as e:
            raise ValueError(
                f"Cannot read checkpoint at {path}: {e}"
            ) from e

        if not isinstance(checkpoint, dict):
            raise ValueError(
                f"Checkpoint must be a dictionary, got {type(checkpoint).__name__}"
            )

        # Validate presence of all four required components
        required_keys = {
            "model_state_dict",
            "optimizer_state_dict",
            "scheduler_state",
            "step",
        }
        missing = required_keys - set(checkpoint.keys())
        if missing:
            raise ValueError(
                f"Checkpoint is missing required components: {sorted(missing)}"
            )

        # Validate step is a non-negative integer
        step = checkpoint["step"]
        if not isinstance(step, int) or step < 0:
            raise ValueError(
                f"Checkpoint step must be a non-negative integer, "
                f"got {step!r} (type={type(step).__name__})"
            )

        return checkpoint

    def restore(
        self,
        predictor: nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any,
        checkpoint_path: str | pathlib.Path,
    ) -> int:
        """Restore training state from a checkpoint.

        Loads the checkpoint, validates it, and restores model weights,
        optimizer state, and scheduler state. Returns the saved step so the
        caller can resume at step + 1 (Req 19.2).

        Args:
            predictor: The model to restore weights into.
            optimizer: The optimizer to restore state into.
            scheduler: The scheduler (or object with a way to set step).
                If it has a ``load_state_dict`` method it will be used;
                otherwise the scheduler_state is returned for manual handling.
            checkpoint_path: Path to the checkpoint file.

        Returns:
            The saved step counter (training resumes at step + 1).

        Raises:
            FileNotFoundError: If the checkpoint does not exist.
            ValueError: If the checkpoint is invalid (pre-load state retained).
        """
        checkpoint = self.load(checkpoint_path)

        # Restore model weights
        predictor.load_state_dict(checkpoint["model_state_dict"])

        # Restore optimizer state
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        # Restore scheduler state
        if hasattr(scheduler, "load_state_dict") and callable(
            getattr(scheduler, "load_state_dict")
        ):
            # If scheduler_state is a dict (e.g. from LambdaLR.state_dict())
            if isinstance(checkpoint["scheduler_state"], dict):
                scheduler.load_state_dict(checkpoint["scheduler_state"])
            else:
                # For simple step-based schedulers, set last_epoch
                scheduler.last_epoch = checkpoint["scheduler_state"]
        elif hasattr(scheduler, "last_epoch"):
            scheduler.last_epoch = checkpoint["scheduler_state"]

        return checkpoint["step"]
