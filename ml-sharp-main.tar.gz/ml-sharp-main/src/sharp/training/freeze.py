"""Freeze controller for SHARP training.

Applies the freeze/unfreeze policy to the RGBGaussianPredictor before training,
and exposes the set of trainable parameters for the optimizer.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

from typing import Iterator

import torch.nn as nn

from sharp.models.predictor import RGBGaussianPredictor
from sharp.training.config import FreezePolicy
from sharp.utils.module_surgery import NORM_LAYER_TYPES, freeze_norm_layer


# Mapping from FreezePolicy field names to the submodule accessor paths on
# RGBGaussianPredictor. Each entry is (policy_field, module_path_segments).
# The policy_field tells us whether to *train* (True) or *freeze* (False) that
# component's non-norm parameters.
_TRAINABLE_COMPONENT_MAP: dict[str, list[str]] = {
    "train_lowres_encoder": [
        "monodepth_model.monodepth_predictor.encoder.image_encoder",
    ],
    "train_dpt_decoder": [
        "monodepth_model.monodepth_predictor.decoder",
        "monodepth_model.monodepth_predictor.head",
    ],
    "train_alignment": [
        "depth_alignment",
    ],
    "train_gaussian_decoder": [
        "feature_model",
        "prediction_head",
        "init_model",
    ],
    "train_composer": [
        "gaussian_composer",
    ],
}

# The patch encoder path (always frozen when policy says so).
_PATCH_ENCODER_PATH = "monodepth_model.monodepth_predictor.encoder.patch_encoder"

# Upsample layers associated with patch encoder (frozen alongside it).
_PATCH_ENCODER_UPSAMPLES = [
    "monodepth_model.monodepth_predictor.encoder.upsample_latent0",
    "monodepth_model.monodepth_predictor.encoder.upsample_latent1",
    "monodepth_model.monodepth_predictor.encoder.upsample0",
    "monodepth_model.monodepth_predictor.encoder.upsample1",
    "monodepth_model.monodepth_predictor.encoder.upsample2",
]

# Lowres-related upsample layers (trained alongside lowres encoder).
_LOWRES_ENCODER_UPSAMPLES = [
    "monodepth_model.monodepth_predictor.encoder.upsample_lowres",
    "monodepth_model.monodepth_predictor.encoder.fuse_lowres",
]


def _resolve_submodule(model: nn.Module, path: str) -> nn.Module:
    """Resolve a dot-separated path to a submodule.

    Raises:
        ValueError: If the path cannot be resolved.
    """
    parts = path.split(".")
    current = model
    for part in parts:
        if not hasattr(current, part):
            raise ValueError(
                f"Cannot resolve component path '{path}': "
                f"attribute '{part}' not found on {type(current).__name__}. "
                f"Check that the model structure matches the freeze policy."
            )
        current = getattr(current, part)
    return current


def _is_norm_layer(module: nn.Module) -> bool:
    """Check if a module is a normalization layer."""
    return isinstance(module, NORM_LAYER_TYPES)


def _set_requires_grad_non_norm(module: nn.Module, requires_grad: bool) -> None:
    """Set requires_grad on all non-norm parameters within a module.

    Norm layer parameters always keep requires_grad=False (handled separately
    by freeze_norm_layer).
    """
    for submodule in module.modules():
        if _is_norm_layer(submodule):
            # Skip norm layers entirely — they are always frozen.
            continue
        for param in submodule.parameters(recurse=False):
            param.requires_grad = requires_grad


class FreezeController:
    """Controls which parameters are frozen/trainable in the predictor.

    Applies a FreezePolicy to set requires_grad on the appropriate parameters
    and exposes an iterator over trainable parameters for the optimizer.
    """

    def apply(self, predictor: RGBGaussianPredictor, policy: FreezePolicy) -> None:
        """Apply the freeze/unfreeze policy to the predictor.

        Steps:
            1. Validate that all component paths resolve (Req 17.8).
            2. Freeze the entire model first (conservative default).
            3. Unfreeze non-norm params on components marked for training.
            4. Freeze all norm layers globally (Req 17.2).
            5. Freeze the patch encoder (Req 17.1).

        Args:
            predictor: The RGBGaussianPredictor to configure.
            policy: The freeze policy specifying which components to train.

        Raises:
            ValueError: If any component name cannot be resolved against the model
                (halts before any parameter modification per Req 17.8).
        """
        # ------------------------------------------------------------------
        # Step 1: Validate ALL paths resolve before modifying anything.
        # ------------------------------------------------------------------
        all_paths: list[str] = []

        # Patch encoder paths
        if policy.freeze_patch_encoder:
            all_paths.append(_PATCH_ENCODER_PATH)
            all_paths.extend(_PATCH_ENCODER_UPSAMPLES)

        # Trainable component paths
        for field_name, paths in _TRAINABLE_COMPONENT_MAP.items():
            all_paths.extend(paths)

        # Lowres upsamples
        all_paths.extend(_LOWRES_ENCODER_UPSAMPLES)

        # Resolve all paths; raise on first failure.
        for path in all_paths:
            _resolve_submodule(predictor, path)

        # ------------------------------------------------------------------
        # Step 2: Freeze the entire model as a conservative baseline.
        # ------------------------------------------------------------------
        predictor.requires_grad_(False)

        # ------------------------------------------------------------------
        # Step 3: Unfreeze non-norm params on components the policy says to
        # train.
        # ------------------------------------------------------------------
        for field_name, paths in _TRAINABLE_COMPONENT_MAP.items():
            should_train = getattr(policy, field_name)
            if should_train:
                for path in paths:
                    module = _resolve_submodule(predictor, path)
                    _set_requires_grad_non_norm(module, requires_grad=True)

        # Handle lowres-related upsamples: trained when lowres encoder is trained.
        if policy.train_lowres_encoder:
            for path in _LOWRES_ENCODER_UPSAMPLES:
                module = _resolve_submodule(predictor, path)
                _set_requires_grad_non_norm(module, requires_grad=True)

        # Handle patch encoder upsamples: they depend on patch encoder status.
        # If patch encoder is frozen, its upsamples stay frozen (already False).
        # If patch encoder is NOT frozen (unusual), unfreeze the upsamples too.
        if not policy.freeze_patch_encoder:
            patch_encoder = _resolve_submodule(predictor, _PATCH_ENCODER_PATH)
            _set_requires_grad_non_norm(patch_encoder, requires_grad=True)
            for path in _PATCH_ENCODER_UPSAMPLES:
                module = _resolve_submodule(predictor, path)
                _set_requires_grad_non_norm(module, requires_grad=True)

        # ------------------------------------------------------------------
        # Step 4: Freeze ALL norm layers globally (Req 17.2).
        # This overrides any unfreezing done above for norm layers.
        # ------------------------------------------------------------------
        if policy.freeze_all_norm_layers:
            freeze_norm_layer(predictor)

        # ------------------------------------------------------------------
        # Step 5: Ensure patch encoder is frozen (Req 17.1).
        # Even if something above accidentally set it, enforce here.
        # ------------------------------------------------------------------
        if policy.freeze_patch_encoder:
            patch_encoder = _resolve_submodule(predictor, _PATCH_ENCODER_PATH)
            patch_encoder.requires_grad_(False)
            for path in _PATCH_ENCODER_UPSAMPLES:
                module = _resolve_submodule(predictor, path)
                module.requires_grad_(False)

    def trainable_parameters(self, predictor: RGBGaussianPredictor) -> Iterator[nn.Parameter]:
        """Return an iterator over parameters with requires_grad=True.

        This should be called after apply() to get the parameter set for the
        optimizer (Req 17.6).

        Args:
            predictor: The predictor whose trainable parameters to yield.

        Yields:
            Parameters with requires_grad=True.
        """
        for param in predictor.parameters():
            if param.requires_grad:
                yield param
