"""View-frustum masking for the SHARP training framework.

Implements ViewMasker (back-projects target pixels into the source view to
determine visibility) and the shared masked_mean helper used by all masked
novel-view losses.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch

from sharp.training.camera import ViewCameras


class ViewMasker:
    """Computes the view-frustum mask M for novel-view losses.

    Back-projects each target (novel-view) pixel into the source camera
    coordinate system via Esrc·Etgt⁻¹, projects with Ksrc, converts to
    normalized image coordinates, and sets M=1 iff:
      - both normalized x,y ∈ [-1.05, 1.05]
      - source-view depth > 0

    The mask M has shape [B, 1, H, W] matching the novel-view spatial dims.
    """

    def compute(
        self,
        novel_depth: torch.Tensor,  # [B, 1, H, W] rendered novel-view depth
        cams: ViewCameras,
    ) -> torch.Tensor:
        """Compute the view-frustum mask.

        Args:
            novel_depth: Rendered depth from the novel view [B, 1, H, W].
            cams: Camera parameters for source and target views.

        Returns:
            Binary mask M in {0, 1} as float tensor [B, 1, H, W].
        """
        B, _, H, W = novel_depth.shape
        device = novel_depth.device
        dtype = novel_depth.dtype

        # 1. Build pixel grid for the novel (target) view: [H, W, 2] in pixel coords
        v_coords, u_coords = torch.meshgrid(
            torch.arange(H, device=device, dtype=dtype),
            torch.arange(W, device=device, dtype=dtype),
            indexing="ij",
        )
        # Homogeneous pixel coords [H*W, 3]: (u, v, 1)
        ones = torch.ones_like(u_coords)
        pixels_hom = torch.stack([u_coords, v_coords, ones], dim=-1)  # [H, W, 3]
        pixels_hom = pixels_hom.reshape(-1, 3).T  # [3, H*W]

        # 2. Unproject target pixels to 3D in target camera space
        #    p_tgt = depth * Ktgt^-1 * [u, v, 1]^T
        k_tgt_inv = torch.inverse(cams.k_tgt)  # [B, 3, 3]
        # rays_tgt: [B, 3, H*W]
        rays_tgt = k_tgt_inv @ pixels_hom.unsqueeze(0).expand(B, -1, -1)
        # Scale by depth: novel_depth is [B, 1, H, W] -> [B, 1, H*W]
        depth_flat = novel_depth.reshape(B, 1, H * W)  # [B, 1, H*W]
        points_tgt = rays_tgt * depth_flat  # [B, 3, H*W] in target cam space

        # 3. Transform from target camera space to source camera space
        #    p_src = Esrc · Etgt^-1 · p_tgt (homogeneous)
        #    Since points are already in camera space (not world), we need:
        #    world = Etgt^-1 · p_tgt_hom, then p_src = Esrc · world
        #    Equivalently: T = Esrc · Etgt^-1, p_src = T · p_tgt_hom
        e_tgt_inv = torch.inverse(cams.e_tgt)  # [B, 4, 4]
        T = cams.e_src @ e_tgt_inv  # [B, 4, 4]

        # Make points homogeneous [B, 4, H*W]
        ones_row = torch.ones(B, 1, H * W, device=device, dtype=dtype)
        points_tgt_hom = torch.cat([points_tgt, ones_row], dim=1)  # [B, 4, H*W]

        # Transform to source camera space
        points_src = T @ points_tgt_hom  # [B, 4, H*W]
        points_src_3d = points_src[:, :3, :]  # [B, 3, H*W]

        # 4. Project into source image using Ksrc
        #    pixel_src = Ksrc · p_src_3d
        projected = cams.k_src @ points_src_3d  # [B, 3, H*W]

        # Source-view depth (z component in source camera space)
        src_depth = points_src_3d[:, 2:3, :]  # [B, 1, H*W]

        # Normalize to pixel coordinates: u = x/z, v = y/z
        # Avoid division by zero with a small epsilon for the division,
        # but the depth > 0 check will mask those out anyway
        eps = 1e-8
        safe_z = projected[:, 2:3, :].clamp(min=eps)
        u_src = projected[:, 0:1, :] / safe_z  # [B, 1, H*W]
        v_src = projected[:, 1:2, :] / safe_z  # [B, 1, H*W]

        # 5. Convert to normalized coordinates [-1, 1]
        #    Normalized x = 2 * u / (W_src - 1) - 1
        #    Normalized y = 2 * v / (H_src - 1) - 1
        #    We use the source image dims which match the target dims (same resolution)
        #    since both views are rendered at the same H x W.
        norm_x = 2.0 * u_src / (W - 1) - 1.0  # [B, 1, H*W]
        norm_y = 2.0 * v_src / (H - 1) - 1.0  # [B, 1, H*W]

        # 6. Apply mask conditions:
        #    - normalized x,y ∈ [-1.05, 1.05]
        #    - source depth > 0
        bound = 1.05
        in_bounds_x = (norm_x >= -bound) & (norm_x <= bound)  # [B, 1, H*W]
        in_bounds_y = (norm_y >= -bound) & (norm_y <= bound)  # [B, 1, H*W]
        positive_depth = src_depth > 0.0  # [B, 1, H*W]

        mask = (in_bounds_x & in_bounds_y & positive_depth).float()  # [B, 1, H*W]

        # 7. Reshape to [B, 1, H, W]
        mask = mask.reshape(B, 1, H, W)

        return mask


def masked_mean(
    per_pixel_loss: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """Compute masked mean of a per-pixel loss.

    Divides by M.sum() when positive, returns 0.0 otherwise.
    Used by every masked novel-view loss (color, perceptual, alpha).

    Args:
        per_pixel_loss: Per-pixel loss values, any shape broadcastable with mask.
        mask: Binary mask M in {0, 1}, same spatial dims as per_pixel_loss.

    Returns:
        Scalar tensor: sum(per_pixel_loss * M) / sum(M) if sum(M) > 0,
        else tensor(0.0) on the same device.
    """
    masked = per_pixel_loss * mask
    pixel_count = mask.sum()

    if pixel_count > 0:
        return masked.sum() / pixel_count
    else:
        return torch.tensor(0.0, device=per_pixel_loss.device, dtype=per_pixel_loss.dtype)
