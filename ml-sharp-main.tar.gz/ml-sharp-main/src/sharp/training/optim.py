"""Optimizer and learning-rate scheduler for SHARP training.

Implements Adam with a linear-warmup-then-cosine-decay LR schedule as a
pure function of step, so that resume from checkpoint recomputes the LR
deterministically from the restored step counter.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import math
from typing import Iterator

import torch
from torch.optim import Adam
from torch.optim.lr_scheduler import LambdaLR

from sharp.training.config import OptimConfig


def _make_lr_lambda(
    warmup_steps: int,
    peak_lr: float,
    floor_lr: float,
    total_steps: int,
) -> callable:
    """Create a pure-function LR multiplier for LambdaLR.

    The returned function maps step -> multiplier such that:
        actual_lr = peak_lr * multiplier(step)

    Schedule:
        step < warmup_steps:  linear warmup from 0 to peak_lr
            multiplier = step / warmup_steps
        warmup_steps <= step <= total_steps:  cosine decay from peak_lr to floor_lr
            multiplier = (floor_lr/peak_lr) + 0.5*(1 - floor_lr/peak_lr)
                         * (1 + cos(pi*(step - warmup_steps)/(total_steps - warmup_steps)))
        step > total_steps:  clamped at floor_lr
            multiplier = floor_lr / peak_lr

    Args:
        warmup_steps: Number of warmup steps (default 10000).
        peak_lr: Peak learning rate (default 1.6e-4).
        floor_lr: Floor learning rate (default 1.6e-5).
        total_steps: Total training steps (the "final" step).

    Returns:
        A callable(step: int) -> float giving the LR multiplier.
    """
    # Precompute the floor ratio to avoid repeated division
    floor_ratio = floor_lr / peak_lr

    # Handle edge case where warmup_steps == total_steps (no cosine phase)
    cosine_duration = total_steps - warmup_steps

    def lr_lambda(step: int) -> float:
        if step < warmup_steps:
            # Linear warmup: lr goes from 0 to peak_lr
            return step / warmup_steps
        elif cosine_duration <= 0 or step > total_steps:
            # Beyond final step or no cosine phase: clamp to floor
            return floor_ratio
        else:
            # Cosine decay from peak_lr to floor_lr
            progress = (step - warmup_steps) / cosine_duration
            return floor_ratio + 0.5 * (1.0 - floor_ratio) * (1.0 + math.cos(math.pi * progress))

    return lr_lambda


class OptimizerScheduler:
    """Adam optimizer with linear-warmup + cosine-decay LR schedule.

    The LR schedule is a pure function of the step counter, making it fully
    deterministic and resume-safe: restoring the step counter and calling
    ``resume(step)`` recomputes the exact same LR that uninterrupted training
    would have produced at that step.

    Args:
        parameters: Iterator of trainable parameters (typically from
            ``FreezeController.trainable_parameters``).
        config: Optimizer configuration (warmup steps, peak LR, floor LR).
        total_steps: Total number of training steps for the schedule.
    """

    def __init__(
        self,
        parameters: Iterator[torch.nn.Parameter],
        config: OptimConfig,
        total_steps: int,
    ) -> None:
        self._config = config
        self._total_steps = total_steps

        # Create Adam optimizer over only the supplied (trainable) parameters
        self.optimizer = Adam(
            parameters,
            lr=config.peak_lr,
            betas=(0.9, 0.999),
            eps=1e-8,
        )

        # Create LambdaLR with the pure-function schedule
        lr_lambda = _make_lr_lambda(
            warmup_steps=config.warmup_steps,
            peak_lr=config.peak_lr,
            floor_lr=config.floor_lr,
            total_steps=total_steps,
        )
        self.scheduler = LambdaLR(self.optimizer, lr_lambda=lr_lambda)

    def step(self) -> None:
        """Execute one optimizer step followed by one scheduler step.

        Call this after ``loss.backward()`` each training iteration.
        """
        self.optimizer.step()
        self.scheduler.step()

    def zero_grad(self) -> None:
        """Zero out all parameter gradients."""
        self.optimizer.zero_grad()

    def get_lr(self) -> float:
        """Return the current learning rate.

        Returns:
            The current LR from the first (and only) parameter group.
        """
        return self.optimizer.param_groups[0]["lr"]

    def resume(self, step: int) -> None:
        """Recompute the scheduler state for a restored step counter.

        Because the LR is a pure function of step, we simply set the
        scheduler's ``last_epoch`` to the restored step and recompute the
        LR from the lambda. This produces the exact same LR as
        uninterrupted training at that step, to within floating-point
        precision (matching the 1e-6 relative tolerance requirement).

        After resume, the next call to ``step()`` will advance to
        ``step + 1``.

        Args:
            step: The step counter restored from a checkpoint (non-negative).

        Raises:
            ValueError: If step is negative.
        """
        if step < 0:
            raise ValueError(
                f"Cannot resume from negative step: {step}. "
                "A valid non-negative integer step counter is required."
            )

        # Set last_epoch to the restored step counter
        self.scheduler.last_epoch = step

        # Recompute the LR using base_lrs and the lr_lambda functions
        for param_group, base_lr, lmbda in zip(
            self.optimizer.param_groups,
            self.scheduler.base_lrs,
            self.scheduler.lr_lambdas,
        ):
            param_group["lr"] = base_lr * lmbda(step)

    @property
    def state_dict(self) -> dict:
        """Return combined state for checkpointing.

        Returns:
            Dictionary with 'optimizer' and 'scheduler' state dicts.
        """
        return {
            "optimizer": self.optimizer.state_dict(),
            "scheduler": self.scheduler.state_dict(),
        }

    def load_state_dict(self, state: dict) -> None:
        """Restore optimizer and scheduler state from a checkpoint.

        Args:
            state: Dictionary with 'optimizer' and 'scheduler' keys.

        Raises:
            KeyError: If required keys are missing.
        """
        if "optimizer" not in state:
            raise KeyError("Checkpoint state missing 'optimizer' key")
        if "scheduler" not in state:
            raise KeyError("Checkpoint state missing 'scheduler' key")

        self.optimizer.load_state_dict(state["optimizer"])
        self.scheduler.load_state_dict(state["scheduler"])
