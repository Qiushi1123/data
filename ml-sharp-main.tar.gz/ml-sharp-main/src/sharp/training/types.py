"""Shared types for the SHARP training framework.

Defines the data contracts used across loss modules, the aggregator, and the
training loop. All loss modules consume a LossContext and produce a LossRecord;
the aggregator combines them into an AggregateResult.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Protocol, runtime_checkable

import torch

if TYPE_CHECKING:
    from sharp.training.config import StageConfig


@dataclasses.dataclass
class RenderTrainOutputs:
    """Outputs from a single renderer forward_train pass."""

    color: torch.Tensor  # [B, 3, H, W]
    depth: torch.Tensor  # [B, 1, H, W]
    alpha: torch.Tensor  # [B, 1, H, W]
    meta: dict  # conics, covars2d, depths


@dataclasses.dataclass
class LossContext:
    """Bundles all inputs a loss module might need.

    Each loss module reads only the fields it requires; others may be None
    depending on the stage and data pipeline.
    """

    # Rendered outputs for both views
    input_render: RenderTrainOutputs | None = None
    novel_render: RenderTrainOutputs | None = None

    # Ground-truth images [B, 3, H, W] sRGB in [0, 1]
    input_gt_image: torch.Tensor | None = None
    novel_gt_image: torch.Tensor | None = None

    # Ground-truth depth / disparity for input view
    input_gt_depth: torch.Tensor | None = None
    input_gt_disparity: torch.Tensor | None = None

    # View-frustum mask M [B, 1, H, W] in {0, 1}
    mask: torch.Tensor | None = None

    # TrainingOutputs intermediates
    gaussians: object | None = None  # Gaussians3D
    aligned_depth: torch.Tensor | None = None  # [B, 2, H, W]
    disparity_pred: torch.Tensor | None = None  # [B, 2, H, W]
    scale_map: torch.Tensor | None = None  # S from DepthAlignment
    base_xy_ndc: torch.Tensor | None = None  # [B, N, 2]
    monodepth_disparity: torch.Tensor | None = None  # raw pre-alignment

    # Camera information
    cameras: object | None = None  # ViewCameras

    # Stage configuration
    stage: StageConfig | None = None


@dataclasses.dataclass
class LossRecord:
    """Record of a single loss term evaluation."""

    name: str
    value: torch.Tensor  # rank-0, unweighted
    weight: float
    active: bool
    finite: bool
    diagnostics: dict = dataclasses.field(default_factory=dict)


@dataclasses.dataclass
class AggregateResult:
    """Result from the loss aggregator."""

    total: torch.Tensor  # rank-0 weighted sum
    records: list[LossRecord]
    skipped: list[str]  # names of non-finite or inactive terms excluded


@runtime_checkable
class LossModule(Protocol):
    """Protocol for a training loss module."""

    name: str
    weight: float

    def __call__(self, ctx: LossContext) -> LossRecord:
        """Compute the loss given the training context."""
        ...
