"""Training configuration dataclasses and loaders.

Mirrors the convention in src/sharp/models/params.py: plain dataclasses with
default values, loadable from JSON or YAML files.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import dataclasses
import json
import pathlib
from typing import Any, Literal

from sharp.models.params import PredictorParams


@dataclasses.dataclass
class LossWeights:
    """Per-term loss weights."""

    color: float = 1.0
    perceptual: float = 3.0
    alpha: float = 1.0
    depth: float = 0.2
    tv: float = 1.0
    grad: float = 0.5
    delta: float = 1.0
    splat: float = 1.0
    scale: float = 0.1
    grad_scale: float = 5.0


@dataclasses.dataclass
class OptimConfig:
    """Optimizer and learning-rate schedule parameters."""

    warmup_steps: int = 10000
    peak_lr: float = 1.6e-4
    floor_lr: float = 1.6e-5


@dataclasses.dataclass
class FreezePolicy:
    """Which model components to freeze/train."""

    freeze_patch_encoder: bool = True
    freeze_all_norm_layers: bool = True
    train_lowres_encoder: bool = True
    train_dpt_decoder: bool = True
    train_alignment: bool = True
    train_gaussian_decoder: bool = True
    train_composer: bool = True


@dataclasses.dataclass
class StageConfig:
    """Per-stage training parameters."""

    name: Literal["stage1", "stage2"] = "stage1"
    total_steps: int = 100000
    active_losses: set[str] = dataclasses.field(default_factory=lambda: {
        "color", "perceptual", "alpha", "depth", "tv",
        "grad", "delta", "splat", "scale", "grad_scale",
    })
    pseudo_view_max_disparity: float = 0.05  # stage2 only
    pseudo_view_disparities: list[float] = dataclasses.field(default_factory=list)
    pseudo_view_pose_strategy: Literal[
        "random_near", "horizontal_symmetric"
    ] = "random_near"
    pseudo_depth_mode: Literal["none", "rendered_loss", "rendered_alignment"] = "rendered_alignment"
    pseudo_depth_alpha_threshold: float = 0.5
    stage1_replay_data_root: str | None = None
    stage1_replay_ratio: float = 0.0
    stage1_replay_pairs_per_scene: int = 4


@dataclasses.dataclass
class TrainingConfig:
    """Top-level training configuration."""

    predictor: PredictorParams = dataclasses.field(default_factory=PredictorParams)
    losses: LossWeights = dataclasses.field(default_factory=LossWeights)
    optim: OptimConfig = dataclasses.field(default_factory=OptimConfig)
    freeze: FreezePolicy = dataclasses.field(default_factory=FreezePolicy)
    stage: StageConfig = dataclasses.field(default_factory=StageConfig)
    internal_resolution: int = 1536
    checkpoint_interval: int = 5000
    perceptual_memory_opt: bool = False
    requires_renderer: bool = True


def _apply_dict_to_dataclass(dc: Any, data: dict[str, Any]) -> None:
    """Recursively apply a dictionary of values onto a dataclass instance."""
    for key, value in data.items():
        if key.startswith("_"):
            continue
        if not hasattr(dc, key):
            raise ValueError(f"Unknown config key: {key!r}")
        current = getattr(dc, key)
        if dataclasses.is_dataclass(current) and isinstance(value, dict):
            _apply_dict_to_dataclass(current, value)
        elif isinstance(current, set) and isinstance(value, list):
            setattr(dc, key, set(value))
        else:
            setattr(dc, key, value)


def load_training_config(path: str | pathlib.Path) -> TrainingConfig:
    """Load a TrainingConfig from a JSON or YAML file.

    JSON files are detected by .json extension; all other extensions are
    attempted as YAML (requires PyYAML to be installed).

    Args:
        path: Path to the configuration file.

    Returns:
        A populated TrainingConfig instance.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file cannot be parsed or contains unknown keys.
    """
    path = pathlib.Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    text = path.read_text(encoding="utf-8")

    if path.suffix.lower() == ".json":
        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {path}: {e}") from e
    else:
        try:
            import yaml  # type: ignore[import-untyped]
        except ImportError as e:
            raise ImportError(
                "PyYAML is required to load YAML config files. "
                "Install it with: pip install pyyaml"
            ) from e
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {path}: {e}") from e

    if not isinstance(data, dict):
        raise ValueError(f"Config file must contain a mapping, got {type(data).__name__}")

    config = TrainingConfig()
    _apply_dict_to_dataclass(config, data)
    return config
