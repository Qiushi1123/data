"""Stage 2 self-supervised finetuning helpers."""

from __future__ import annotations

import dataclasses
import math

import torch

from sharp.utils.gaussians import unproject_gaussians


@dataclasses.dataclass
class PseudoView:
    """Detached teacher-rendered pseudo view used as the SSFT source."""

    image: torch.Tensor  # [3, H, W]
    intrinsics: torch.Tensor  # [1, 3, 3]
    pseudo_extrinsics: torch.Tensor  # [1, 4, 4]
    original_extrinsics: torch.Tensor  # [1, 4, 4]
    depth: torch.Tensor | None = None  # [1, H, W]
    alpha: torch.Tensor | None = None  # [1, H, W]


def sample_near_source_pose(
    max_disparity: float,
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Sample a nearby pseudo camera and the original identity camera."""
    original_extrinsics = torch.eye(4, device=device, dtype=dtype).unsqueeze(0)

    max_angle = max_disparity * math.pi
    axis = torch.randn(3, device=device, dtype=dtype)
    axis = axis / (axis.norm() + 1e-8)
    angle = torch.rand(1, device=device, dtype=dtype) * max_angle

    skew = torch.zeros(3, 3, device=device, dtype=dtype)
    skew[0, 1] = -axis[2]
    skew[0, 2] = axis[1]
    skew[1, 0] = axis[2]
    skew[1, 2] = -axis[0]
    skew[2, 0] = -axis[1]
    skew[2, 1] = axis[0]

    rotation = (
        torch.eye(3, device=device, dtype=dtype)
        + torch.sin(angle) * skew
        + (1 - torch.cos(angle)) * (skew @ skew)
    )

    translation = torch.randn(3, device=device, dtype=dtype)
    translation = translation / (translation.norm() + 1e-8)
    translation = translation * (torch.rand(1, device=device, dtype=dtype) * max_disparity)

    pseudo_extrinsics = torch.eye(4, device=device, dtype=dtype)
    pseudo_extrinsics[:3, :3] = rotation
    pseudo_extrinsics[:3, 3] = translation
    return pseudo_extrinsics.unsqueeze(0), original_extrinsics


def make_horizontal_symmetric_pose(
    signed_disparity: float,
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Create a deterministic left/right pseudo camera for SSFT.

    ``signed_disparity`` controls both the horizontal camera translation and a
    yaw rotation with matching sign. Passing ``+d`` and ``-d`` produces mirrored
    poses, which lets training use the same left/right trajectory family as
    controlled inference videos.
    """
    original_extrinsics = torch.eye(4, device=device, dtype=dtype).unsqueeze(0)

    yaw = torch.as_tensor(signed_disparity * math.pi, device=device, dtype=dtype)
    cos_yaw = torch.cos(yaw)
    sin_yaw = torch.sin(yaw)

    rotation = torch.eye(3, device=device, dtype=dtype)
    rotation[0, 0] = cos_yaw
    rotation[0, 2] = sin_yaw
    rotation[2, 0] = -sin_yaw
    rotation[2, 2] = cos_yaw

    pseudo_extrinsics = torch.eye(4, device=device, dtype=dtype)
    pseudo_extrinsics[:3, :3] = rotation
    pseudo_extrinsics[0, 3] = torch.as_tensor(signed_disparity, device=device, dtype=dtype)
    return pseudo_extrinsics.unsqueeze(0), original_extrinsics


def make_centered_intrinsics(
    disparity_factor: torch.Tensor,
    resolution: int,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Build 4x4 and 3x3 centered pinhole intrinsics from f_px / width."""
    f_px = float(disparity_factor.detach().cpu().reshape(()).item()) * resolution
    intrinsics_4x4 = torch.tensor(
        [
            [f_px, 0.0, resolution / 2.0, 0.0],
            [0.0, f_px, resolution / 2.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ],
        device=device,
        dtype=dtype,
    )
    return intrinsics_4x4, intrinsics_4x4[:3, :3].unsqueeze(0)


class FrozenTeacherPseudoViewGenerator:
    """Generates detached pseudo views with a frozen Stage-1 teacher."""

    def __init__(
        self,
        teacher: torch.nn.Module,
        renderer: torch.nn.Module,
        *,
        resolution: int,
        max_disparity: float,
        pose_strategy: str = "random_near",
        device: torch.device | None = None,
    ) -> None:
        if pose_strategy not in {"random_near", "horizontal_symmetric"}:
            raise ValueError(
                "pose_strategy must be one of: random_near, horizontal_symmetric"
            )
        self.teacher = teacher
        self.renderer = renderer
        self.resolution = resolution
        self.max_disparity = max_disparity
        self.pose_strategy = pose_strategy
        self.device = device

        if self.device is not None:
            self.teacher.to(self.device)
        self.teacher.eval()
        self.teacher.requires_grad_(False)

    def __call__(
        self,
        real_image: torch.Tensor,
        disparity_factor: torch.Tensor,
        max_disparity: float | None = None,
    ) -> PseudoView:
        """Render a nearby teacher view and detach every teacher product."""
        device = self._device()
        image = real_image.to(device=device)
        disparity_factor = disparity_factor.to(device=device, dtype=torch.float32)
        dtype = image.dtype

        with torch.no_grad():
            image_batch = image.unsqueeze(0)
            disp_batch = disparity_factor.reshape(1)
            gaussians_ndc = self.teacher(image_batch, disp_batch)

            intrinsics_4x4, intrinsics_3x3 = make_centered_intrinsics(
                disparity_factor,
                self.resolution,
                device=device,
                dtype=dtype,
            )
            original_extrinsics = torch.eye(4, device=device, dtype=dtype)
            gaussians_world = unproject_gaussians(
                gaussians_ndc,
                original_extrinsics,
                intrinsics_4x4,
                (self.resolution, self.resolution),
            )

            requested_disparity = self.max_disparity if max_disparity is None else max_disparity
            if self.pose_strategy == "horizontal_symmetric":
                pseudo_extrinsics, original_extrinsics_batched = make_horizontal_symmetric_pose(
                    requested_disparity,
                    device=device,
                    dtype=dtype,
                )
            else:
                pseudo_extrinsics, original_extrinsics_batched = sample_near_source_pose(
                    requested_disparity,
                    device=device,
                    dtype=dtype,
                )
            rendered = self.renderer(
                gaussians_world,
                pseudo_extrinsics,
                intrinsics_3x3,
                self.resolution,
                self.resolution,
            )

            depth = getattr(rendered, "depth", None)
            alpha = getattr(rendered, "alpha", None)

            return PseudoView(
                image=rendered.color[0].detach().clamp(0.0, 1.0),
                intrinsics=intrinsics_3x3.detach(),
                pseudo_extrinsics=pseudo_extrinsics.detach(),
                original_extrinsics=original_extrinsics_batched.detach(),
                depth=depth[0].detach() if depth is not None else None,
                alpha=alpha[0].detach() if alpha is not None else None,
            )

    def _device(self) -> torch.device:
        if self.device is not None:
            return self.device
        try:
            return next(self.teacher.parameters()).device
        except StopIteration:
            return torch.device("cpu")
