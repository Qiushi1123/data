"""Concrete SampleSource adapter for the Stage 1 synthetic dataset.

Reads the `scene_xxxxx/{cameras.json, rgb, depth, mask}` layout described in
data_spec.md and yields RawSample objects for the training pipeline. Samples are
constructed as same-scene (source, target) view pairs — never across scenes.

Depth is z-depth in meters (OpenEXR float). Background/no-hit pixels use a large
sentinel (the generator writes 1e10, though cameras.json may declare 0.0); this
adapter masks depth outside [near, far] to 0.0 (invalid) and derives the input
disparity used by the depth loss.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import json
import logging
import pathlib
from typing import Iterator

import numpy as np
import torch

from sharp.training.camera import ViewCameras
from sharp.training.pipeline import RawSample

logger = logging.getLogger(__name__)

_BACKGROUND_SENTINEL = 1e6  # depth >= this is treated as invalid/background


def _read_exr_depth(path: pathlib.Path) -> np.ndarray:
    """Read a single-channel float EXR z-depth map as [H, W] float32."""
    import OpenEXR  # local import; optional dependency

    f = OpenEXR.File(str(path))
    ch = f.channels()
    names = list(ch.keys())
    name = next((n for n in names if "depth" in n.lower() or n.lower().endswith(".v")), names[0])
    return np.asarray(ch[name].pixels, dtype=np.float32)


def _read_rgb(path: pathlib.Path) -> np.ndarray:
    from PIL import Image

    arr = np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8)
    return arr


def _read_mask(path: pathlib.Path) -> np.ndarray:
    from PIL import Image

    arr = np.asarray(Image.open(path))
    if arr.ndim == 3:
        arr = arr[..., 0]
    return arr


class Stage1SceneSource:
    """Yields same-scene (source, target) RawSamples from the Stage 1 dataset.

    Args:
        root: Dataset root containing stage1_manifest.json and scene dirs.
        pairs_per_scene: How many (source, target) pairs to emit per scene per
            epoch. Pairs are drawn within a scene only.
        near: Minimum valid depth in meters (below => invalid).
        far: Maximum valid depth in meters (>= => invalid/background).
        seed: RNG seed for reproducible pair sampling.
        scenes: Optional explicit scene subset (e.g. ["scene_00000"]).
    """

    def __init__(
        self,
        root: str | pathlib.Path,
        pairs_per_scene: int = 4,
        near: float = 0.05,
        far: float = _BACKGROUND_SENTINEL,
        seed: int = 0,
        scenes: list[str] | None = None,
    ) -> None:
        self.root = pathlib.Path(root)
        manifest = json.loads((self.root / "stage1_manifest.json").read_text())
        self.scenes = scenes if scenes is not None else list(manifest["scenes"])
        self.pairs_per_scene = pairs_per_scene
        self.near = near
        self.far = far
        self._rng = np.random.default_rng(seed)

    def __len__(self) -> int:
        return len(self.scenes) * self.pairs_per_scene

    def _load_view(self, sdir: pathlib.Path, view: dict):
        rgb = _read_rgb(sdir / view["rgb"]).astype(np.float32) / 255.0  # [H,W,3] in [0,1]
        rgb = np.transpose(rgb, (2, 0, 1))  # [3,H,W]
        depth = _read_exr_depth(sdir / view["depth"])  # [H,W] meters
        invalid = ~np.isfinite(depth) | (depth <= self.near) | (depth >= self.far)
        depth = np.where(invalid, 0.0, depth).astype(np.float32)
        mask = None
        if "mask" in view:
            mp = sdir / view["mask"]
            if mp.exists():
                mask = (_read_mask(mp) > 127).astype(np.float32)
        K = np.array(
            [[view["fx"], 0, view["cx"]], [0, view["fy"], view["cy"]], [0, 0, 1]],
            dtype=np.float32,
        )
        E = np.array(view["extrinsic_w2c"], dtype=np.float32)
        return rgb, depth, mask, K, E, int(view["width"]), int(view["height"])

    def __iter__(self) -> Iterator[RawSample]:
        for scene in self.scenes:
            sdir = self.root / scene
            cam = json.loads((sdir / "cameras.json").read_text())
            views = cam["views"]
            n = len(views)
            for _ in range(self.pairs_per_scene):
                si, ti = self._rng.choice(n, size=2, replace=False)
                vs, vt = views[int(si)], views[int(ti)]

                rgb_s, depth_s, mask_s, Ks, Es, W, H = self._load_view(sdir, vs)
                rgb_t, depth_t, mask_t, Kt, Et, _, _ = self._load_view(sdir, vt)

                cameras = ViewCameras(
                    k_src=torch.from_numpy(Ks)[None],  # [1,3,3]
                    e_src=torch.from_numpy(Es)[None],  # [1,4,4]
                    k_tgt=torch.from_numpy(Kt)[None],
                    e_tgt=torch.from_numpy(Et)[None],
                )

                yield RawSample(
                    sample_id=f"{scene}:{si}->{ti}",
                    input_image=torch.from_numpy(rgb_s),  # [3,H,W]
                    novel_image=torch.from_numpy(rgb_t),
                    cameras=cameras,
                    input_depth=torch.from_numpy(depth_s)[None],  # [1,H,W]
                    focal_length_px=float(vs["fx"]),
                    image_width=W,
                    novel_foreground_mask=(
                        torch.from_numpy(mask_t)[None] if mask_t is not None else None
                    ),
                )
