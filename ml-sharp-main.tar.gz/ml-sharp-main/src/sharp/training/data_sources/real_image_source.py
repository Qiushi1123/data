"""Real single-image data source for Stage 2 SSFT."""

from __future__ import annotations

import pathlib
from typing import Iterator

import numpy as np
import torch

from sharp.training.pipeline import RawSample
from sharp.utils.io import load_rgb


_SUPPORTED_IMAGE_SUFFIXES = {
    ".bmp",
    ".heic",
    ".heif",
    ".jpeg",
    ".jpg",
    ".png",
    ".tif",
    ".tiff",
    ".webp",
}


class RealImageSource:
    """Yields real single-view images as RawSample objects for SSFT.

    ``root`` can be either a single image file or a directory. Directories are
    searched recursively for supported image extensions. No synthetic Stage-1
    manifest, paired novel view, camera pose, or metric depth is required.
    """

    def __init__(
        self,
        root: str | pathlib.Path,
        *,
        focal_length_px: float | None = None,
        shuffle: bool = False,
        seed: int = 0,
    ) -> None:
        self.root = pathlib.Path(root)
        self.focal_length_px = focal_length_px
        self.shuffle = shuffle
        self._rng = np.random.default_rng(seed)
        self.images = self._discover_images(self.root)
        if not self.images:
            raise ValueError(f"No supported real images found under: {self.root}")

    def __len__(self) -> int:
        return len(self.images)

    def __iter__(self) -> Iterator[RawSample]:
        indices = np.arange(len(self.images))
        if self.shuffle:
            self._rng.shuffle(indices)

        for index in indices:
            path = self.images[int(index)]
            image, _, focal_from_exif = load_rgb(path)
            image = image.astype(np.float32) / 255.0
            image_chw = np.transpose(image[:, :, :3], (2, 0, 1))
            focal_length_px = self.focal_length_px or float(focal_from_exif)

            yield RawSample(
                sample_id=self._sample_id(path),
                input_image=torch.from_numpy(image_chw),
                novel_image=None,
                cameras=None,
                input_depth=None,
                input_disparity=None,
                focal_length_px=focal_length_px,
                image_width=int(image.shape[1]),
                novel_foreground_mask=None,
            )

    @classmethod
    def _discover_images(cls, root: pathlib.Path) -> list[pathlib.Path]:
        if root.is_file():
            return [root] if cls._is_supported_image(root) else []
        if not root.exists():
            raise FileNotFoundError(f"Real image root does not exist: {root}")
        if not root.is_dir():
            raise ValueError(f"Real image root is neither file nor directory: {root}")
        return sorted(path for path in root.rglob("*") if cls._is_supported_image(path))

    @staticmethod
    def _is_supported_image(path: pathlib.Path) -> bool:
        return path.is_file() and path.suffix.lower() in _SUPPORTED_IMAGE_SUFFIXES

    def _sample_id(self, path: pathlib.Path) -> str:
        try:
            return str(path.relative_to(self.root if self.root.is_dir() else self.root.parent))
        except ValueError:
            return str(path)
