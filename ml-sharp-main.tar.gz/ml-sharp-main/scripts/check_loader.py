"""Loader + batch sanity check for the Stage 1 dataset (no CUDA)."""

from __future__ import annotations

import pathlib
import sys

import torch

from sharp.training.data_sources import Stage1SceneSource
from sharp.training.pipeline import Stage1_Pipeline


def main(root: str):
    # --- Single-scene loader check (scene_00000) ---
    src0 = Stage1SceneSource(root, pairs_per_scene=4, scenes=["scene_00000"], seed=0)
    pipe0 = Stage1_Pipeline(src0, total_steps=4, resolution=384)
    print("=== single-scene (scene_00000) ===")
    seen_pairs = set()
    for i, s in enumerate(pipe0):
        assert s.input_image.shape == (3, 384, 384), s.input_image.shape
        assert s.novel_image.shape == (3, 384, 384), s.novel_image.shape
        assert s.input_depth is not None and s.input_depth.shape == (1, 384, 384)
        assert s.cameras.k_src is not None and s.cameras.e_tgt is not None
        df = s.disparity_factor
        assert torch.isfinite(df).all() and (df > 0).all()
        rgb_ok = (s.input_image.min() >= 0) and (s.input_image.max() <= 1)
        dvalid = (s.input_depth > 0).float().mean().item()
        print(f"  sample {i}: img[0,1]={rgb_ok} disp_factor={df.item():.4f} "
              f"depth_valid_frac={dvalid:.3f} depth_max={s.input_depth.max().item():.3f}")

    # --- Full 27-scene batch sanity check ---
    print("\n=== full 27-scene sanity ===")
    src = Stage1SceneSource(root, pairs_per_scene=2, seed=1)
    pipe = Stage1_Pipeline(src, total_steps=54, resolution=384)
    n = 0
    scene_ids = set()
    bad = 0
    for s in pipe:
        n += 1
        scene = s  # TrainingSample has no id; source encodes it — count via shapes
        if s.input_image.shape != (3, 384, 384) or s.input_depth.shape != (1, 384, 384):
            bad += 1
        if not torch.isfinite(s.input_depth).all():
            bad += 1
    print(f"  iterated {n} samples, malformed={bad}")

    # --- verify same-scene pairing via the source sample_id ---
    print("\n=== same-scene pairing check (sample_id) ===")
    src2 = Stage1SceneSource(root, pairs_per_scene=3, seed=2)
    ok = True
    count = 0
    for raw in src2:
        sid = raw.sample_id  # "scene_xxxxx:si->ti"
        scene, pair = sid.split(":")
        si, ti = pair.split("->")
        scene_ids.add(scene)
        if si == ti:
            ok = False
            print("  ERROR self-pair:", sid)
        count += 1
    print(f"  raw pairs={count} distinct_scenes={len(scene_ids)} all_cross_view_same_scene={ok}")
    print("\nLOADER CHECK: PASS" if (bad == 0 and ok) else "\nLOADER CHECK: FAIL")


if __name__ == "__main__":
    main(sys.argv[1])
