"""Non-renderer training-chain gradient check (no CUDA).

Real predictor -> FreezeController -> TrainingForward on a real Stage 1 sample
-> {DepthLoss, ScaleLoss, GradScaleLoss} -> aggregate -> backward.

Verifies gradients reach trainable params and frozen params get none. This does
NOT exercise the gsplat renderer (CUDA-only) or the view-synthesis losses; it
validates the depth/scale branch of the chain end-to-end on real data.
"""

from __future__ import annotations

import sys
import time

import torch

from sharp.models import PredictorParams, create_predictor
from sharp.training.config import FreezePolicy
from sharp.training.data_sources import Stage1SceneSource
from sharp.training.forward import TrainingForward
from sharp.training.freeze import FreezeController
from sharp.training.losses.depth import DepthLoss
from sharp.training.losses.grad_scale import GradScaleLoss
from sharp.training.losses.scale import ScaleLoss
from sharp.training.pipeline import Stage1_Pipeline
from sharp.training.types import LossContext


def main(root: str, resolution: int = 384):
    device = torch.device("cpu")
    torch.manual_seed(0)

    # Real predictor + freeze policy
    predictor = create_predictor(PredictorParams()).to(device)
    predictor.train()
    FreezeController().apply(predictor, FreezePolicy())
    n_train = sum(p.numel() for p in predictor.parameters() if p.requires_grad)
    n_frozen = sum(p.numel() for p in predictor.parameters() if not p.requires_grad)
    print(f"trainable={n_train/1e6:.1f}M frozen={n_frozen/1e6:.1f}M")

    tf = TrainingForward(predictor)

    # One real sample. The Depth Pro encoder requires 1536x1536 input, so we
    # upsample the native-res RGB (bilinear) and depth (nearest, to preserve the
    # 0-invalid boundary) to the model's internal resolution.
    import torch.nn.functional as F

    src = Stage1SceneSource(root, pairs_per_scene=1, scenes=["scene_00000"], seed=0)
    pipe = Stage1_Pipeline(src, total_steps=1, resolution=resolution)
    sample = next(iter(pipe))
    MODEL_RES = 1536
    img = sample.input_image[None].to(device)            # [1,3,H,W]
    depth = sample.input_depth[None].to(device)          # [1,1,H,W]
    img = F.interpolate(img, size=(MODEL_RES, MODEL_RES), mode="bilinear", align_corners=True)
    depth = F.interpolate(depth, size=(MODEL_RES, MODEL_RES), mode="nearest")
    disp_factor = sample.disparity_factor[None].to(device)  # [1]

    # GT disparity for the depth loss: disparity = disparity_factor / depth (valid only)
    valid = depth > 0
    gt_disp = torch.zeros_like(depth)
    gt_disp[valid] = disp_factor.view(-1, 1, 1, 1).expand_as(depth)[valid] / depth[valid]

    print("running TrainingForward (real backbone, CPU)...")
    t0 = time.time()
    out = tf(img, disp_factor, depth=depth)
    print(f"  forward ok in {time.time()-t0:.1f}s")
    print(f"  disparity_pred {tuple(out.disparity_pred.shape)} "
          f"scale_map={None if out.scale_map is None else tuple(out.scale_map.shape)} "
          f"gaussians.mean {tuple(out.gaussians.mean_vectors.shape)}")
    print(f"  disparity_pred requires_grad={out.disparity_pred.requires_grad} "
          f"grad_fn={out.disparity_pred.grad_fn is not None}")

    # Build a loss context for the depth/scale branch
    ctx = LossContext(
        disparity_pred=out.disparity_pred,
        input_gt_disparity=gt_disp,
        scale_map=out.scale_map,
    )

    depth_loss = DepthLoss()
    scale_loss = ScaleLoss()
    gscale_loss = GradScaleLoss()

    rd = depth_loss(ctx)
    rs = scale_loss(ctx)
    rg = gscale_loss(ctx)
    print(f"\nlosses: depth active={rd.active} val={rd.value.item():.5f} "
          f"| scale active={rs.active} val={rs.value.item():.5f} "
          f"| grad_scale active={rg.active} val={rg.value.item():.5f}")

    total = rd.weight * rd.value + rs.weight * rs.value + rg.weight * rg.value
    print(f"total (weighted) = {total.item():.5f} requires_grad={total.requires_grad}")

    predictor.zero_grad()
    total.backward()

    # Gradient audit
    got_grad, no_grad, frozen_with_grad = [], [], []
    for name, p in predictor.named_parameters():
        if p.requires_grad:
            if p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum() > 0:
                got_grad.append(name)
            else:
                no_grad.append(name)
        else:
            if p.grad is not None:
                frozen_with_grad.append(name)

    print(f"\ntrainable params WITH finite non-zero grad: {len(got_grad)}")
    print(f"trainable params WITHOUT grad: {len(no_grad)}")
    print(f"frozen params that WRONGLY got grad: {len(frozen_with_grad)}")
    # Which components received gradient (depth branch should reach depth decoder + alignment)
    def has(prefix):
        return any(n.startswith(prefix) for n in got_grad)
    print("  -> depth decoder got grad:",
          has("monodepth_model.monodepth_predictor.decoder"))
    print("  -> depth adjustment got grad:", has("depth_alignment"))
    print("  -> low-res encoder got grad:",
          has("monodepth_model.monodepth_predictor.encoder.image_encoder"))

    ok = len(got_grad) > 0 and len(frozen_with_grad) == 0 and torch.isfinite(total)
    print("\nGRAD CHAIN CHECK:", "PASS" if ok else "FAIL")


if __name__ == "__main__":
    root = sys.argv[1]
    res = int(sys.argv[2]) if len(sys.argv) > 2 else 384
    main(root, res)
