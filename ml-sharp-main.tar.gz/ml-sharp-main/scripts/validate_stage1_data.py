"""Stage 1 synthetic dataset contract validation (no CUDA required).

Validates the dataset produced by the data-synthesis agent against data_spec.md:
counts, shapes, EXR depth ranges/units, camera fields, RGB/depth/mask alignment,
and the OpenCV convention. Also performs a camera-convention reprojection check.

Run: python scripts/validate_stage1_data.py <dataset_root>
"""

from __future__ import annotations

import json
import pathlib
import sys

import numpy as np
import OpenEXR
from PIL import Image

EXPECTED = {
    "units": "meters",
    "convention": "opencv_x_right_y_down_z_forward",
    "extrinsic_type": "world_to_camera",
    "depth_type": "z_depth",
}


def read_exr_depth(path: pathlib.Path) -> np.ndarray:
    """Read a single-channel float EXR depth map to a [H, W] float32 array."""
    f = OpenEXR.File(str(path))
    channels = f.channels()
    # Prefer a channel whose name suggests depth; else take the only channel.
    names = list(channels.keys())
    name = next((n for n in names if "depth" in n.lower() or n.lower().endswith(".v")), names[0])
    arr = channels[name].pixels
    return np.asarray(arr, dtype=np.float32)


def read_png(path: pathlib.Path) -> np.ndarray:
    return np.asarray(Image.open(path))


def main(root: pathlib.Path) -> int:
    errors: list[str] = []
    warnings: list[str] = []

    manifest_path = root / "stage1_manifest.json"
    if not manifest_path.exists():
        print(f"FATAL: manifest not found at {manifest_path}")
        return 1
    manifest = json.loads(manifest_path.read_text())
    scenes = manifest.get("scenes", [])
    print(f"manifest scene_count={manifest.get('scene_count')} listed={len(scenes)}")

    total_rgb = total_depth = total_mask = total_views = 0
    depth_stats = []  # (scene, view, min_pos, max, valid_frac)
    res_set = set()
    intr_set = set()

    for scene_name in scenes:
        sdir = root / scene_name
        cam_path = sdir / "cameras.json"
        if not cam_path.exists():
            errors.append(f"{scene_name}: missing cameras.json")
            continue
        cam = json.loads(cam_path.read_text())

        # Top-level convention fields
        for k, v in EXPECTED.items():
            if cam.get(k) != v:
                errors.append(f"{scene_name}: cameras.{k}={cam.get(k)!r} expected {v!r}")
        div = cam.get("depth_invalid_value", None)
        if div != 0.0:
            warnings.append(f"{scene_name}: depth_invalid_value={div!r} (spec expects 0.0)")

        views = cam.get("views", [])
        for v in views:
            total_views += 1
            idx = v.get("index")
            # 1) camera fields present
            for field in ("fx", "fy", "cx", "cy", "width", "height", "extrinsic_w2c", "rgb", "depth"):
                if field not in v:
                    errors.append(f"{scene_name} view {idx}: missing field '{field}'")
            W, H = v.get("width"), v.get("height")
            res_set.add((W, H))
            intr_set.add((round(v.get("fx", -1), 4), round(v.get("cx", -1), 4)))

            # extrinsic shape + bottom row + rotation orthonormality
            E = np.asarray(v.get("extrinsic_w2c"), dtype=np.float64)
            if E.shape != (4, 4):
                errors.append(f"{scene_name} view {idx}: extrinsic_w2c shape {E.shape} != (4,4)")
            else:
                if not np.allclose(E[3], [0, 0, 0, 1], atol=1e-6):
                    warnings.append(f"{scene_name} view {idx}: extrinsic bottom row {E[3].tolist()}")
                R = E[:3, :3]
                if not np.allclose(R @ R.T, np.eye(3), atol=1e-3):
                    errors.append(f"{scene_name} view {idx}: rotation not orthonormal")
                if not np.isclose(np.linalg.det(R), 1.0, atol=1e-2):
                    warnings.append(f"{scene_name} view {idx}: det(R)={np.linalg.det(R):.4f} (not +1)")

            # 2) files exist and align
            rgb_p = sdir / v["rgb"]
            dep_p = sdir / v["depth"]
            expect_stem = f"view_{idx:02d}"
            if rgb_p.stem != expect_stem:
                errors.append(f"{scene_name} view {idx}: rgb name {rgb_p.name} != {expect_stem}.png")
            if dep_p.stem != expect_stem:
                errors.append(f"{scene_name} view {idx}: depth name {dep_p.name} != {expect_stem}.exr")

            if rgb_p.exists():
                total_rgb += 1
                rgb = read_png(rgb_p)
                if rgb.shape[0] != H or rgb.shape[1] != W:
                    errors.append(f"{scene_name} view {idx}: rgb shape {rgb.shape[:2]} != ({H},{W})")
                if rgb.ndim != 3 or rgb.shape[2] < 3:
                    errors.append(f"{scene_name} view {idx}: rgb not 3-channel: {rgb.shape}")
                if rgb.dtype != np.uint8:
                    warnings.append(f"{scene_name} view {idx}: rgb dtype {rgb.dtype} (expected uint8)")
            else:
                errors.append(f"{scene_name} view {idx}: rgb file missing {rgb_p}")

            if dep_p.exists():
                total_depth += 1
                dep = read_exr_depth(dep_p)
                if dep.shape[0] != H or dep.shape[1] != W:
                    errors.append(f"{scene_name} view {idx}: depth shape {dep.shape} != ({H},{W})")
                finite = np.isfinite(dep)
                valid = finite & (dep > 0)
                if not finite.all():
                    warnings.append(f"{scene_name} view {idx}: depth has non-finite values")
                vfrac = float(valid.mean())
                pos = dep[valid]
                mn = float(pos.min()) if pos.size else float("nan")
                mx = float(pos.max()) if pos.size else float("nan")
                depth_stats.append((scene_name, idx, mn, mx, vfrac))
                if pos.size == 0:
                    errors.append(f"{scene_name} view {idx}: depth has no valid (>0) pixels")
                elif mn < 0.05 or mx > 100.0:
                    warnings.append(
                        f"{scene_name} view {idx}: depth range [{mn:.3f},{mx:.3f}] m out of [0.05,100]"
                    )
            else:
                errors.append(f"{scene_name} view {idx}: depth file missing {dep_p}")

            # mask (optional)
            if "mask" in v:
                mask_p = sdir / v["mask"]
                if mask_p.exists():
                    total_mask += 1
                    m = read_png(mask_p)
                    mh, mw = m.shape[0], m.shape[1]
                    if mh != H or mw != W:
                        errors.append(f"{scene_name} view {idx}: mask shape {(mh,mw)} != ({H},{W})")
                else:
                    warnings.append(f"{scene_name} view {idx}: mask declared but missing {mask_p}")

    print("\n===== COUNTS =====")
    print(f"scenes={len(scenes)} views={total_views} rgb={total_rgb} depth={total_depth} mask={total_mask}")
    print(f"resolutions={sorted(res_set)}")
    print(f"distinct (fx,cx) pairs={len(intr_set)} sample={sorted(intr_set)[:3]}")

    if depth_stats:
        mns = np.array([s[2] for s in depth_stats])
        mxs = np.array([s[3] for s in depth_stats])
        vfr = np.array([s[4] for s in depth_stats])
        print("\n===== DEPTH (valid>0, meters) =====")
        print(f"min-depth: p5={np.percentile(mns,5):.3f} median={np.median(mns):.3f}")
        print(f"max-depth: median={np.median(mxs):.3f} p95={np.percentile(mxs,95):.3f}")
        print(f"valid-fraction: min={vfr.min():.3f} median={np.median(vfr):.3f} max={vfr.max():.3f}")

    print("\n===== RESULT =====")
    print(f"errors={len(errors)} warnings={len(warnings)}")
    for e in errors[:40]:
        print("  ERROR:", e)
    for w in warnings[:20]:
        print("  WARN :", w)
    return 0 if not errors else 2


if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(".")
    sys.exit(main(root))
