#!/usr/bin/env python3
"""Stage-2 SSFT forward diagnostics.

Runs the frozen-teacher pseudo-view path and the student training forward pass
without backward/optimizer updates. It records tensor distributions for depth,
scale maps, Gaussians, and rendered outputs so Stage-2 geometry failures can be
localized before training.
"""

from __future__ import annotations

import argparse
import json
import math
import pathlib
import time
from dataclasses import asdict, dataclass
from typing import Iterable

import torch
import torch.nn.functional as F

from sharp.models import PredictorParams, create_predictor
from sharp.training.camera import CameraModule
from sharp.training.data_sources import RealImageSource
from sharp.training.forward import TrainingForward
from sharp.training.pipeline import RawSample, Stage2_Pipeline
from sharp.training.ssft import FrozenTeacherPseudoViewGenerator
from sharp.utils.gsplat import GSplatRenderer


class _SingleRawSource:
    def __init__(self, raw: RawSample) -> None:
        self.raw = raw

    def __iter__(self):
        yield self.raw

    def __len__(self) -> int:
        return 1


def _load_state_dict(path: pathlib.Path) -> dict:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    if isinstance(obj, dict) and "model_state_dict" in obj:
        return obj["model_state_dict"]
    if isinstance(obj, dict) and "state_dict" in obj:
        return obj["state_dict"]
    if isinstance(obj, dict):
        return obj
    raise TypeError(f"Unsupported checkpoint format in {path}: {type(obj)!r}")


def _load_predictor(path: pathlib.Path, device: torch.device) -> torch.nn.Module:
    predictor = create_predictor(PredictorParams())
    state = _load_state_dict(path)
    missing, unexpected = predictor.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(
            json.dumps(
                {
                    "event": "load_state_dict_non_strict",
                    "path": str(path),
                    "missing_count": len(missing),
                    "unexpected_count": len(unexpected),
                    "missing_preview": missing[:5],
                    "unexpected_preview": unexpected[:5],
                },
                ensure_ascii=False,
            )
        )
    return predictor.to(device).eval()


def _tensor_stats(tensor: torch.Tensor | None, *, max_values: int = 200_000) -> dict:
    if tensor is None:
        return {"present": False}
    with torch.no_grad():
        data = tensor.detach().float().flatten().cpu()
        total = int(data.numel())
        if total == 0:
            return {"present": True, "numel": 0}
        finite = torch.isfinite(data)
        finite_count = int(finite.sum().item())
        base = {
            "present": True,
            "shape": list(tensor.shape),
            "numel": total,
            "finite_ratio": finite_count / total,
            "zero_ratio": float((data == 0).float().mean().item()),
            "negative_ratio": float((data < 0).float().mean().item()),
        }
        if finite_count == 0:
            return base
        values = data[finite]
        if values.numel() > max_values:
            stride = max(1, values.numel() // max_values)
            values = values[::stride][:max_values]
        q = torch.quantile(values, torch.tensor([0.01, 0.5, 0.99]))
        base.update(
            {
                "min": float(values.min().item()),
                "max": float(values.max().item()),
                "mean": float(values.mean().item()),
                "std": float(values.std(unbiased=False).item()),
                "p01": float(q[0].item()),
                "p50": float(q[1].item()),
                "p99": float(q[2].item()),
            }
        )
        return base


def _rgb_l1(rendered: torch.Tensor, target: torch.Tensor) -> float:
    if target.dim() == 3:
        target = target.unsqueeze(0)
    target = target.to(device=rendered.device, dtype=rendered.dtype)
    return float(torch.mean(torch.abs(rendered - target)).detach().cpu().item())


def _iter_selected_raws(data_root: pathlib.Path, train_count: int, holdout_count: int):
    source = RealImageSource(data_root, shuffle=False)
    image_paths = list(source.images)
    selected: list[tuple[str, pathlib.Path]] = []
    for path in image_paths[:train_count]:
        selected.append(("train", path))
    if holdout_count > 0:
        for path in image_paths[-holdout_count:]:
            if path not in [p for _, p in selected]:
                selected.append(("holdout", path))
    for split, path in selected:
        raw = next(iter(RealImageSource(path, shuffle=False)))
        yield split, path, raw


def _diagnose_one(
    *,
    raw: RawSample,
    split: str,
    path: pathlib.Path,
    mode: str,
    sample_index: int,
    student: torch.nn.Module,
    generator: FrozenTeacherPseudoViewGenerator,
    renderer: GSplatRenderer,
    resolution: int,
    device: torch.device,
    seed: int,
) -> dict:
    torch.manual_seed(seed + sample_index)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed + sample_index)

    pipeline = Stage2_Pipeline(
        source=_SingleRawSource(raw),
        pseudo_view_generator=generator,
        total_steps=1,
        resolution=resolution,
        pseudo_depth_mode=mode,
    )
    sample = next(iter(pipeline))

    training_forward = TrainingForward(student)
    camera_module = CameraModule()
    input_image = sample.input_image.unsqueeze(0).to(device=device)
    disparity_factor = sample.disparity_factor.reshape(1).to(device=device)
    input_depth = sample.input_depth
    if input_depth is not None:
        input_depth = input_depth.unsqueeze(0).to(device=device)

    with torch.no_grad():
        outputs = training_forward(
            image=input_image,
            disparity_factor=disparity_factor,
            depth=input_depth,
        )
        input_extrinsics, input_intrinsics = camera_module.input_view(sample.cameras)
        novel_extrinsics, novel_intrinsics = camera_module.novel_view(sample.cameras)
        input_render = renderer.forward_train(
            outputs.gaussians,
            input_extrinsics.to(device),
            input_intrinsics.to(device),
            resolution,
            resolution,
        )
        novel_render = renderer.forward_train(
            outputs.gaussians,
            novel_extrinsics.to(device),
            novel_intrinsics.to(device),
            resolution,
            resolution,
        )

    teacher_input_disparity = None
    if sample.input_disparity is not None:
        teacher_input_disparity = sample.input_disparity

    result = {
        "split": split,
        "path": str(path),
        "sample_id": raw.sample_id,
        "mode": mode,
        "seed": seed + sample_index,
        "disparity_factor": float(sample.disparity_factor.detach().cpu().reshape(()).item()),
        "rgb_l1_input": _rgb_l1(input_render.color, sample.input_image),
        "rgb_l1_novel": _rgb_l1(novel_render.color, sample.novel_image),
        "sample_input_depth": _tensor_stats(sample.input_depth),
        "sample_input_disparity": _tensor_stats(teacher_input_disparity),
        "monodepth_disparity": _tensor_stats(outputs.monodepth_disparity),
        "aligned_depth": _tensor_stats(outputs.aligned_depth),
        "disparity_pred": _tensor_stats(outputs.disparity_pred),
        "scale_map": _tensor_stats(outputs.scale_map),
        "gaussian_mean_xyz": _tensor_stats(outputs.gaussians.mean_vectors),
        "gaussian_mean_z": _tensor_stats(outputs.gaussians.mean_vectors[..., 2]),
        "gaussian_singular_values": _tensor_stats(outputs.gaussians.singular_values),
        "gaussian_opacities": _tensor_stats(outputs.gaussians.opacities),
        "input_render_color": _tensor_stats(input_render.color),
        "input_render_depth": _tensor_stats(input_render.depth),
        "input_render_alpha": _tensor_stats(input_render.alpha),
        "input_render_meta_depths": _tensor_stats(input_render.meta.get("depths")),
        "novel_render_color": _tensor_stats(novel_render.color),
        "novel_render_depth": _tensor_stats(novel_render.depth),
        "novel_render_alpha": _tensor_stats(novel_render.alpha),
        "novel_render_meta_depths": _tensor_stats(novel_render.meta.get("depths")),
    }
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=pathlib.Path, required=True)
    parser.add_argument("--teacher-weights", type=pathlib.Path, default=None)
    parser.add_argument("--data-root", type=pathlib.Path, required=True)
    parser.add_argument("--test-image", type=pathlib.Path, default=None)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--resolution", type=int, default=1536)
    parser.add_argument("--max-disparity", type=float, default=0.025)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--train-count", type=int, default=2)
    parser.add_argument("--holdout-count", type=int, default=2)
    parser.add_argument(
        "--modes",
        default="none,rendered_loss,rendered_alignment",
        help="Comma-separated pseudo depth modes.",
    )
    parser.add_argument("--seed", type=int, default=1234)
    args = parser.parse_args()

    device = torch.device(args.device)
    teacher_weights = args.teacher_weights or args.weights
    student = _load_predictor(args.weights, device)
    teacher = _load_predictor(teacher_weights, device)
    teacher.requires_grad_(False)
    renderer = GSplatRenderer().to(device) if hasattr(GSplatRenderer(), "to") else GSplatRenderer()
    generator = FrozenTeacherPseudoViewGenerator(
        teacher=teacher,
        renderer=renderer,
        resolution=args.resolution,
        max_disparity=args.max_disparity,
        device=device,
    )

    modes = [mode.strip() for mode in args.modes.split(",") if mode.strip()]
    cases = list(_iter_selected_raws(args.data_root, args.train_count, args.holdout_count))
    if args.test_image is not None:
        raw = next(iter(RealImageSource(args.test_image, shuffle=False)))
        cases.append(("test", args.test_image, raw))

    records = []
    start = time.time()
    for sample_index, (split, path, raw) in enumerate(cases):
        for mode in modes:
            print(f"diagnose split={split} mode={mode} path={path}", flush=True)
            try:
                record = _diagnose_one(
                    raw=raw,
                    split=split,
                    path=path,
                    mode=mode,
                    sample_index=sample_index,
                    student=student,
                    generator=generator,
                    renderer=renderer,
                    resolution=args.resolution,
                    device=device,
                    seed=args.seed,
                )
            except Exception as exc:  # keep matrix going
                record = {
                    "split": split,
                    "path": str(path),
                    "sample_id": raw.sample_id,
                    "mode": mode,
                    "seed": args.seed + sample_index,
                    "error": repr(exc),
                }
            records.append(record)

    payload = {
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "weights": str(args.weights),
        "teacher_weights": str(teacher_weights),
        "data_root": str(args.data_root),
        "test_image": str(args.test_image) if args.test_image else None,
        "resolution": args.resolution,
        "max_disparity": args.max_disparity,
        "modes": modes,
        "duration_sec": time.time() - start,
        "records": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
