"""Camera-convention reprojection consistency check (no CUDA).

For a source/target view pair in the same scene, back-project source z-depth to
3D, transform to the target camera via the relative pose E_rel = E_tgt @ inv(E_src),
project with K_tgt, and compare the transferred depth against the target's own
measured depth. High agreement => cameras + depth + OpenCV convention are wired
consistently (and the relative pose used by the training renderer is correct).
"""

from __future__ import annotations

import json
import pathlib
import sys

import numpy as np
import OpenEXR

BIG = 1e6  # background/no-hit sentinel threshold (data uses 1e10)


def read_exr_depth(path: pathlib.Path) -> np.ndarray:
    f = OpenEXR.File(str(path))
    ch = f.channels()
    n = list(ch.keys())[0]
    return np.asarray(ch[n].pixels, dtype=np.float32)


def K_of(v):
    return np.array([[v["fx"], 0, v["cx"]], [0, v["fy"], v["cy"]], [0, 0, 1]], dtype=np.float64)


def reproj_agreement(sdir: pathlib.Path, cam: dict, si: int, ti: int, tol=0.05):
    vs, vt = cam["views"][si], cam["views"][ti]
    Ds = read_exr_depth(sdir / vs["depth"])
    Dt = read_exr_depth(sdir / vt["depth"])
    H, W = Ds.shape
    Ks, Kt = K_of(vs), K_of(vt)
    Es = np.array(vs["extrinsic_w2c"], dtype=np.float64)
    Et = np.array(vt["extrinsic_w2c"], dtype=np.float64)
    E_rel = Et @ np.linalg.inv(Es)
    R, tvec = E_rel[:3, :3], E_rel[:3, 3]

    ys, xs = np.mgrid[0:H, 0:W]
    valid_s = (Ds > 0) & (Ds < BIG) & np.isfinite(Ds)
    u = xs[valid_s].astype(np.float64)
    v = ys[valid_s].astype(np.float64)
    d = Ds[valid_s].astype(np.float64)

    # Back-project (z-depth): X_s = d * Ks^-1 [u,v,1]
    Ks_inv = np.linalg.inv(Ks)
    rays = Ks_inv @ np.stack([u, v, np.ones_like(u)], 0)  # [3,M]
    Xs = rays * d  # [3,M], Xs.z == d
    Xt = R @ Xs + tvec[:, None]
    z = Xt[2]
    front = z > 1e-6
    proj = Kt @ Xt
    up = proj[0] / np.clip(proj[2], 1e-8, None)
    vp = proj[1] / np.clip(proj[2], 1e-8, None)
    ui = np.round(up).astype(int)
    vi = np.round(vp).astype(int)
    inb = front & (ui >= 0) & (ui < W) & (vi >= 0) & (vi < H)

    ui_c = np.clip(ui, 0, W - 1)
    vi_c = np.clip(vi, 0, H - 1)
    dt_sampled = Dt[vi_c, ui_c]
    dt_valid = (dt_sampled > 0) & (dt_sampled < BIG) & np.isfinite(dt_sampled)

    covis = inb & dt_valid
    if covis.sum() == 0:
        return dict(covis=0, agree_frac=float("nan"), med_relerr=float("nan"), inframe=float(inb.mean()))
    rel = np.abs(z[covis] - dt_sampled[covis]) / dt_sampled[covis]
    agree = (rel < tol).mean()
    return dict(
        covis=int(covis.sum()),
        agree_frac=float(agree),
        med_relerr=float(np.median(rel)),
        inframe=float(inb.mean()),
    )


def main(root: pathlib.Path):
    scenes = json.loads((root / "stage1_manifest.json").read_text())["scenes"]
    print(f"{'scene':>12} {'pair':>7} {'covis':>7} {'inframe':>8} {'agree%':>7} {'medRelErr':>9}")
    agg = []
    for scene in scenes:
        sdir = root / scene
        cam = json.loads((sdir / "cameras.json").read_text())
        n = len(cam["views"])
        # adjacent pair (0,1) and a wider pair (0, n//2)
        for (si, ti) in [(0, 1), (0, n // 2)]:
            r = reproj_agreement(sdir, cam, si, ti)
            agg.append(r["agree_frac"])
            print(f"{scene:>12} {f'{si}->{ti}':>7} {r['covis']:>7} {r['inframe']:>8.3f} "
                  f"{100*r['agree_frac']:>6.1f}% {r['med_relerr']:>9.4f}")
    arr = np.array([a for a in agg if a == a])
    print(f"\nOVERALL adjacent+wide pairs: mean agree={100*arr.mean():.1f}%  median={100*np.median(arr):.1f}%")
    print("Interpretation: >~80% agreement => camera/depth/convention are mutually consistent.")


if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1])
    main(root)
