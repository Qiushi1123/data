# Feature: sharp-training-framework, Property 12
"""Property test for total-variation loss (Property 12).

**Validates: Requirements 10.1, 10.2, 15.1**

Property 12: Total-variation loss is non-negative, shift-invariant, and zero on
constants.

For any disparity map, the anisotropic TV loss (sum of horizontal plus vertical
absolute neighbor differences) is a finite non-negative scalar, is invariant to
adding a constant to the whole map, and equals 0.0 for a constant map.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.tv import TVLoss
from sharp.training.types import LossContext


# --- Hypothesis strategies ---


@st.composite
def disparity_map(draw):
    """Generate a random disparity map [B, 2, H, W] with varying values."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))

    num_elements = batch * 2 * height * width
    vals = draw(
        st.lists(
            st.floats(min_value=-100.0, max_value=100.0, allow_nan=False, allow_infinity=False),
            min_size=num_elements,
            max_size=num_elements,
        )
    )
    tensor = torch.tensor(vals, dtype=torch.float32).reshape(batch, 2, height, width)
    return tensor, batch, height, width


@st.composite
def constant_disparity_map(draw):
    """Generate a constant disparity map [B, 2, H, W] where all values are the same."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))
    constant_val = draw(
        st.floats(min_value=-100.0, max_value=100.0, allow_nan=False, allow_infinity=False)
    )

    tensor = torch.full((batch, 2, height, width), constant_val, dtype=torch.float32)
    return tensor, batch, height, width, constant_val


@st.composite
def shift_constant(draw):
    """Generate a constant to add (shift) to a disparity map."""
    return draw(
        st.floats(min_value=-50.0, max_value=50.0, allow_nan=False, allow_infinity=False)
    )


def _make_loss_context(disparity_pred: torch.Tensor) -> LossContext:
    """Build a LossContext with the given disparity_pred tensor."""
    return LossContext(disparity_pred=disparity_pred)


# --- Property tests ---


class TestTVLossProperty12:
    """Property 12: Total-variation loss is non-negative, shift-invariant, and zero on constants."""

    @settings(max_examples=100)
    @given(data=disparity_map())
    def test_tv_loss_is_finite_non_negative(self, data):
        """For any disparity map, TV loss is a finite non-negative scalar."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = TVLoss(weight=1.0)
        record = loss_fn(ctx)

        # Must be active and finite
        assert record.active is True
        assert record.finite is True

        # Value must be non-negative
        assert record.value.item() >= 0.0, (
            f"TV loss must be non-negative, got {record.value.item()}"
        )

        # Value must be finite
        assert torch.isfinite(record.value), (
            f"TV loss must be finite, got {record.value.item()}"
        )

        # Value must be a scalar (rank 0)
        assert record.value.ndim == 0, (
            f"TV loss must be rank-0, got ndim={record.value.ndim}"
        )

    @settings(max_examples=100)
    @given(data=disparity_map(), c=shift_constant())
    def test_tv_loss_is_shift_invariant(self, data, c):
        """Adding a constant to the entire map does not change the TV loss."""
        tensor, B, H, W = data

        # Compute TV loss on original map
        ctx_original = _make_loss_context(tensor)
        loss_fn = TVLoss(weight=1.0)
        record_original = loss_fn(ctx_original)

        # Shift the entire map by a constant
        shifted_tensor = tensor + c
        ctx_shifted = _make_loss_context(shifted_tensor)
        record_shifted = loss_fn(ctx_shifted)

        # The TV loss should be identical (shift-invariant)
        assert torch.allclose(record_original.value, record_shifted.value, atol=1e-5), (
            f"TV loss should be shift-invariant: original={record_original.value.item()}, "
            f"shifted(+{c})={record_shifted.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=constant_disparity_map())
    def test_tv_loss_is_zero_on_constant_map(self, data):
        """A constant disparity map has TV loss of exactly 0.0."""
        tensor, B, H, W, constant_val = data

        ctx = _make_loss_context(tensor)
        loss_fn = TVLoss(weight=1.0)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"TV loss on constant map (val={constant_val}) should be 0.0, "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=disparity_map())
    def test_tv_loss_matches_manual_computation(self, data):
        """TV loss matches the manual anisotropic TV formula on layer 1."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = TVLoss(weight=1.0)
        record = loss_fn(ctx)

        # Manual computation of anisotropic TV on layer 1
        layer1 = tensor[:, 1:2, :, :]

        total_elements = 0
        tv_sum = 0.0

        if W >= 2:
            h_diff = torch.abs(layer1[:, :, :, 1:] - layer1[:, :, :, :-1])
            tv_sum += h_diff.sum().item()
            total_elements += h_diff.numel()

        if H >= 2:
            v_diff = torch.abs(layer1[:, :, 1:, :] - layer1[:, :, :-1, :])
            tv_sum += v_diff.sum().item()
            total_elements += v_diff.numel()

        if total_elements > 0:
            expected = tv_sum / total_elements
        else:
            expected = 0.0

        assert abs(record.value.item() - expected) < 1e-5, (
            f"TV loss={record.value.item()}, expected manual={expected}"
        )

    @settings(max_examples=100)
    @given(data=disparity_map())
    def test_tv_loss_uses_only_layer1(self, data):
        """TV loss depends only on layer 1, not layer 0."""
        tensor, B, H, W = data

        # Compute TV loss with original tensor
        ctx_original = _make_loss_context(tensor)
        loss_fn = TVLoss(weight=1.0)
        record_original = loss_fn(ctx_original)

        # Modify layer 0 arbitrarily, keep layer 1 the same
        modified_tensor = tensor.clone()
        modified_tensor[:, 0, :, :] = torch.randn(B, H, W) * 1000.0

        ctx_modified = _make_loss_context(modified_tensor)
        record_modified = loss_fn(ctx_modified)

        # TV loss should be identical since only layer 1 matters
        assert torch.allclose(record_original.value, record_modified.value, atol=1e-6), (
            f"TV loss should only use layer 1: original={record_original.value.item()}, "
            f"modified_layer0={record_modified.value.item()}"
        )
