# Feature: sharp-training-framework, Property 8
"""Property test for perceptual loss algebra (Property 8).

**Validates: Requirements 7.1, 7.2**

Property 8: Perceptual loss is a non-negative weighted feature+Gram distance,
zero on identical inputs.

For any pair of equal-shape novel-view inputs, the perceptual loss equals the
sum over the 4 layers of (1/(Dl·Hl·Wl))·‖feat_r − feat_g‖² +
(10/Dl²)·‖Gram_r − Gram_g‖², is non-negative, is symmetric in its two image
arguments, and equals 0.0 when the two inputs are identical.

Uses a small deterministic stub feature extractor for the algebra tests
(not the full ResNet-50, too slow for property tests).
"""

from __future__ import annotations

from typing import List

import torch
import torch.nn as nn
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.perceptual import PerceptualLoss, _gram_matrix
from sharp.training.types import LossContext, RenderTrainOutputs


# --- Deterministic stub feature extractor ---


class _StubFeatureExtractor(nn.Module):
    """A tiny deterministic 4-layer feature extractor for property tests.

    Each layer applies a fixed (seeded) 1x1 convolution to downsample channels,
    followed by adaptive average pooling to produce decreasing spatial sizes.
    This mimics the ResNet-50 extractor's 4-layer output structure with
    known channel counts and spatial dimensions, but runs fast on CPU.
    """

    def __init__(self, seed: int = 42) -> None:
        super().__init__()
        # Fixed layer configurations: (in_channels, out_channels, spatial_size)
        # Mimics ResNet-50 layers with smaller dimensions
        self._layer_configs = [
            (3, 4, 8),   # layer1: 4 channels, 8x8
            (4, 8, 4),   # layer2: 8 channels, 4x4
            (8, 6, 2),   # layer3: 6 channels, 2x2
            (6, 3, 1),   # layer4: 3 channels, 1x1
        ]

        gen = torch.Generator()
        gen.manual_seed(seed)

        self.convs = nn.ModuleList()
        self.pools = nn.ModuleList()

        for in_ch, out_ch, spatial in self._layer_configs:
            conv = nn.Conv2d(in_ch, out_ch, kernel_size=1, bias=False)
            # Initialize with deterministic weights
            nn.init.normal_(conv.weight, generator=gen)
            conv.weight.requires_grad_(False)
            self.convs.append(conv)
            self.pools.append(nn.AdaptiveAvgPool2d(spatial))

        # Freeze all parameters
        for param in self.parameters():
            param.requires_grad = False

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        """Extract 4 feature maps from input [B, 3, H, W]."""
        features: List[torch.Tensor] = []
        current = x
        for conv, pool in zip(self.convs, self.pools):
            current = pool(conv(current))
            features.append(current)
        return features


# --- Hypothesis strategies ---


@st.composite
def image_dims(draw):
    """Draw small image dimensions [B, 3, H, W] suitable for the stub extractor."""
    batch = draw(st.integers(min_value=1, max_value=2))
    # Need at least 8x8 to support the stub extractor's pooling
    height = draw(st.integers(min_value=8, max_value=16))
    width = draw(st.integers(min_value=8, max_value=16))
    return batch, 3, height, width


@st.composite
def image_pair(draw):
    """Generate a pair of random image tensors [B, 3, H, W] in [0, 1]."""
    B, C, H, W = draw(image_dims())

    rendered_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )
    gt_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )

    rendered = torch.tensor(rendered_vals, dtype=torch.float32).reshape(B, C, H, W)
    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(B, C, H, W)

    return rendered, gt, B, C, H, W


@st.composite
def identical_image(draw):
    """Generate a single image tensor used as both inputs."""
    B, C, H, W = draw(image_dims())

    vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )

    img = torch.tensor(vals, dtype=torch.float32).reshape(B, C, H, W)
    return img, B, C, H, W


def _make_perceptual_loss_context(
    novel_rendered: torch.Tensor,
    novel_gt: torch.Tensor,
    mask: torch.Tensor,
) -> LossContext:
    """Build a LossContext for the perceptual loss (novel view only)."""
    B, C, H, W = novel_rendered.shape
    novel_render = RenderTrainOutputs(
        color=novel_rendered,
        depth=torch.zeros(B, 1, H, W),
        alpha=torch.ones(B, 1, H, W),
        meta={},
    )
    return LossContext(
        novel_render=novel_render,
        novel_gt_image=novel_gt,
        mask=mask,
    )


def _compute_expected_loss(
    extractor: nn.Module,
    rendered: torch.Tensor,
    gt: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """Compute the expected perceptual loss manually using the property formula.

    Formula per layer l:
        (1/(Dl·Hl·Wl))·‖feat_r − feat_g‖² + (10/Dl²)·‖Gram_r − Gram_g‖²

    Where Gram = feat_flat @ feat_flat^T / (H*W) as in the implementation.
    """
    # Apply mask before feature extraction (same as the implementation)
    masked_rendered = rendered * mask
    masked_gt = gt * mask

    feats_r = extractor(masked_rendered)
    feats_g = extractor(masked_gt)

    total = torch.tensor(0.0, dtype=rendered.dtype)

    for feat_r, feat_g in zip(feats_r, feats_g):
        B, Dl, Hl, Wl = feat_r.shape

        # Feature distance: sum((feat_r - feat_g)^2) / (Dl * Hl * Wl)
        feat_diff = feat_r - feat_g
        feat_loss = (feat_diff ** 2).sum() / (Dl * Hl * Wl)

        # Gram distance: sum((Gram_r - Gram_g)^2) * 10 / Dl^2
        # Gram = feat_flat @ feat_flat^T / (H*W)
        gram_r = _gram_matrix(feat_r)
        gram_g = _gram_matrix(feat_g)
        gram_diff = gram_r - gram_g
        gram_loss = (gram_diff ** 2).sum() * 10.0 / (Dl ** 2)

        total = total + feat_loss + gram_loss

    return total


def _create_stub_perceptual_loss() -> PerceptualLoss:
    """Create a PerceptualLoss with the stub extractor swapped in."""
    loss_fn = PerceptualLoss.__new__(PerceptualLoss)
    loss_fn.name = "perceptual"
    loss_fn.weight = 3.0
    loss_fn.memory_opt = False
    loss_fn._cached_grads = None
    loss_fn._extractor = _StubFeatureExtractor(seed=42)
    loss_fn._extractor.eval()
    return loss_fn


# --- Property tests ---


class TestPerceptualLossProperty8:
    """Property 8: Perceptual loss is a non-negative weighted feature+Gram
    distance, zero on identical inputs."""

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_loss_equals_formula(self, data):
        """The perceptual loss equals the sum over 4 layers of the formula."""
        rendered, gt, B, C, H, W = data

        mask = torch.ones(B, 1, H, W)
        rendered_grad = rendered.clone().requires_grad_(True)

        ctx = _make_perceptual_loss_context(rendered_grad, gt, mask)

        loss_fn = _create_stub_perceptual_loss()
        record = loss_fn(ctx)

        # Compute expected value manually using the same stub extractor
        expected = _compute_expected_loss(loss_fn._extractor, rendered_grad, gt, mask)

        assert torch.allclose(record.value, expected, atol=1e-5), (
            f"Perceptual loss={record.value.item():.8f}, "
            f"expected={expected.item():.8f}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_loss_is_non_negative(self, data):
        """The perceptual loss is always non-negative."""
        rendered, gt, B, C, H, W = data

        mask = torch.ones(B, 1, H, W)
        rendered_grad = rendered.clone().requires_grad_(True)

        ctx = _make_perceptual_loss_context(rendered_grad, gt, mask)

        loss_fn = _create_stub_perceptual_loss()
        record = loss_fn(ctx)

        assert record.value.item() >= 0.0, (
            f"Perceptual loss should be non-negative, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_loss_is_symmetric(self, data):
        """Swapping the rendered and GT images gives the same loss value."""
        rendered, gt, B, C, H, W = data

        mask = torch.ones(B, 1, H, W)

        # Forward: rendered as novel, gt as target
        ctx_forward = _make_perceptual_loss_context(
            rendered.clone().requires_grad_(True), gt.clone(), mask
        )

        # Swapped: gt as novel, rendered as target
        ctx_swapped = _make_perceptual_loss_context(
            gt.clone().requires_grad_(True), rendered.clone(), mask
        )

        loss_fn = _create_stub_perceptual_loss()
        record_forward = loss_fn(ctx_forward)
        record_swapped = loss_fn(ctx_swapped)

        assert torch.allclose(record_forward.value, record_swapped.value, atol=1e-5), (
            f"Not symmetric: forward={record_forward.value.item():.8f}, "
            f"swapped={record_swapped.value.item():.8f}"
        )

    @settings(max_examples=100)
    @given(data=identical_image())
    def test_identical_inputs_give_zero_loss(self, data):
        """When both inputs are identical, the loss is exactly 0.0."""
        img, B, C, H, W = data

        mask = torch.ones(B, 1, H, W)
        rendered = img.clone().requires_grad_(True)
        gt = img.clone()

        ctx = _make_perceptual_loss_context(rendered, gt, mask)

        loss_fn = _create_stub_perceptual_loss()
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 for identical inputs but got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_result_is_finite(self, data):
        """The loss value is always finite."""
        rendered, gt, B, C, H, W = data

        mask = torch.ones(B, 1, H, W)
        rendered_grad = rendered.clone().requires_grad_(True)

        ctx = _make_perceptual_loss_context(rendered_grad, gt, mask)

        loss_fn = _create_stub_perceptual_loss()
        record = loss_fn(ctx)

        assert record.finite is True, "Loss should be marked as finite"
        assert torch.isfinite(record.value), (
            f"Loss value is not finite: {record.value.item()}"
        )
