"""Property tests for CameraModule projection algebra.

# Feature: sharp-training-framework, Property 4

Tests that the baked projection P = Ktgt·Etgt·Esrc⁻¹·Ksrc⁻¹ applied to
source-space points equals the (E_rel = Etgt·Esrc⁻¹, Ktgt) rendering
decomposition on a probe grid to within a tolerance of 1e-4.

Also tests that validate() correctly catches missing or singular parameters.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import math

import hypothesis
import hypothesis.strategies as st
import pytest
import torch
from hypothesis import given, settings

from sharp.training.camera import CameraModule, CameraValidationError, ViewCameras


# ---------------------------------------------------------------------------
# Hypothesis strategies for generating valid, invertible camera matrices
# ---------------------------------------------------------------------------


@st.composite
def rotation_matrices(draw: st.DrawFn) -> torch.Tensor:
    """Generate a valid 3x3 rotation matrix from a random axis-angle vector.

    Uses the Rodrigues formula to ensure the result is a proper rotation
    (orthogonal, det=+1).
    """
    # Random axis-angle: angle in [0.01, pi], random unit axis
    angle = draw(st.floats(min_value=0.01, max_value=math.pi, allow_nan=False, allow_infinity=False))
    # Random direction on the unit sphere via spherical coords
    theta = draw(st.floats(min_value=0.0, max_value=math.pi, allow_nan=False, allow_infinity=False))
    phi = draw(st.floats(min_value=0.0, max_value=2 * math.pi, allow_nan=False, allow_infinity=False))

    axis = torch.tensor(
        [math.sin(theta) * math.cos(phi), math.sin(theta) * math.sin(phi), math.cos(theta)],
        dtype=torch.float64,
    )
    # Normalize (should already be unit, but ensure numerical safety)
    axis = axis / axis.norm()

    # Rodrigues: R = I + sin(a) * K + (1-cos(a)) * K^2
    K = torch.tensor(
        [[0.0, -axis[2], axis[1]], [axis[2], 0.0, -axis[0]], [-axis[1], axis[0], 0.0]],
        dtype=torch.float64,
    )
    R = torch.eye(3, dtype=torch.float64) + math.sin(angle) * K + (1 - math.cos(angle)) * (K @ K)
    return R


@st.composite
def intrinsic_matrices(draw: st.DrawFn) -> torch.Tensor:
    """Generate a valid 3x3 intrinsic matrix with positive focal lengths.

    K = [[fx,  0, cx],
         [ 0, fy, cy],
         [ 0,  0,  1]]
    """
    fx = draw(st.floats(min_value=100.0, max_value=2000.0, allow_nan=False, allow_infinity=False))
    fy = draw(st.floats(min_value=100.0, max_value=2000.0, allow_nan=False, allow_infinity=False))
    cx = draw(st.floats(min_value=200.0, max_value=1000.0, allow_nan=False, allow_infinity=False))
    cy = draw(st.floats(min_value=200.0, max_value=1000.0, allow_nan=False, allow_infinity=False))

    K = torch.tensor([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=torch.float64)
    return K


@st.composite
def extrinsic_matrices(draw: st.DrawFn) -> torch.Tensor:
    """Generate a valid 4x4 extrinsic (world-to-camera) matrix.

    Combines a rotation matrix with a translation vector.
    The result is always invertible (det != 0).
    """
    R = draw(rotation_matrices())
    tx = draw(st.floats(min_value=-5.0, max_value=5.0, allow_nan=False, allow_infinity=False))
    ty = draw(st.floats(min_value=-5.0, max_value=5.0, allow_nan=False, allow_infinity=False))
    tz = draw(st.floats(min_value=-5.0, max_value=5.0, allow_nan=False, allow_infinity=False))

    E = torch.eye(4, dtype=torch.float64)
    E[:3, :3] = R
    E[:3, 3] = torch.tensor([tx, ty, tz], dtype=torch.float64)
    return E


@st.composite
def view_cameras(draw: st.DrawFn) -> ViewCameras:
    """Generate a complete ViewCameras with valid, invertible parameters (batch=1)."""
    k_src = draw(intrinsic_matrices()).unsqueeze(0)  # [1, 3, 3]
    e_src = draw(extrinsic_matrices()).unsqueeze(0)  # [1, 4, 4]
    k_tgt = draw(intrinsic_matrices()).unsqueeze(0)  # [1, 3, 3]
    e_tgt = draw(extrinsic_matrices()).unsqueeze(0)  # [1, 4, 4]

    return ViewCameras(k_src=k_src, e_src=e_src, k_tgt=k_tgt, e_tgt=e_tgt)


# ---------------------------------------------------------------------------
# Property 4: Baked projection equals the render-path decomposition
# ---------------------------------------------------------------------------


class TestBakedProjectionDecompositionEquivalence:
    """Property 4: Baked projection equals the render-path decomposition.

    **Validates: Requirements 3.2**

    For any set of valid, invertible cameras (Ksrc, Esrc, Ktgt, Etgt),
    applying the baked projection P = Ktgt·Etgt·Esrc⁻¹·Ksrc⁻¹ to
    source-space points equals the (E_rel = Etgt·Esrc⁻¹, Ktgt) rendering
    decomposition on a probe grid to within a tolerance of 1e-4.
    """

    @given(cams=view_cameras())
    @settings(max_examples=100)
    def test_baked_projection_matches_decomposition(self, cams: ViewCameras) -> None:
        """The baked P applied to source-pixel points matches E_rel then Ktgt.

        For a grid of 3D probe points in source camera space:
        - Path A: Apply P directly (with homogeneous handling)
        - Path B: Un-project via Ksrc⁻¹, apply E_rel, project via Ktgt
        Both paths should agree to within 1e-4.
        """
        cam_module = CameraModule()

        # Compute baked projection P [1, 4, 4]
        P = cam_module.baked_projection(cams)

        # Compute relative extrinsics E_rel [1, 4, 4]
        E_rel = cam_module.relative_extrinsics(cams)

        # Generate a probe grid of points in source pixel space
        # Use a grid covering the image area with different depths
        H, W = 8, 8
        u = torch.linspace(100.0, 900.0, W, dtype=torch.float64)
        v = torch.linspace(100.0, 900.0, H, dtype=torch.float64)
        grid_v, grid_u = torch.meshgrid(v, u, indexing="ij")  # [H, W]

        # Multiple depth values to test
        depths = torch.tensor([0.5, 1.0, 2.0, 5.0], dtype=torch.float64)

        for depth in depths:
            # Source pixel coords as homogeneous: [u, v, 1] * depth
            # These are points in the source camera space after K:
            # p_pixel = [u*d, v*d, d, 1] (homogeneous 4D for the 4x4 P matrix)
            pts_pixel = torch.stack(
                [
                    grid_u.flatten() * depth,
                    grid_v.flatten() * depth,
                    torch.full((H * W,), depth.item(), dtype=torch.float64),
                    torch.ones(H * W, dtype=torch.float64),
                ],
                dim=-1,
            )  # [N, 4]

            # --- Path A: Apply P directly ---
            # P maps from source-pixel homogeneous to target-pixel homogeneous
            # result_A = P @ pts_pixel^T -> [4, N], then dehomogenize
            P_squeezed = P.squeeze(0)  # [4, 4]
            result_A_hom = (P_squeezed @ pts_pixel.T).T  # [N, 4]
            # Dehomogenize: divide by the 3rd coordinate (z)
            result_A_z = result_A_hom[:, 2:3]  # [N, 1]
            result_A_pixel = result_A_hom[:, :2] / result_A_z  # [N, 2] target pixel coords

            # --- Path B: Un-project via Ksrc⁻¹, apply E_rel, project via Ktgt ---
            # Step 1: Un-project from source pixel to source camera 3D
            K_src = cams.k_src.squeeze(0)  # [3, 3]
            K_src_inv = torch.linalg.inv(K_src)  # [3, 3]

            # Source pixel homogeneous [u, v, 1] -> source camera coords [X, Y, Z]
            pts_pixel_3 = torch.stack(
                [grid_u.flatten(), grid_v.flatten(), torch.ones(H * W, dtype=torch.float64)],
                dim=-1,
            )  # [N, 3]
            pts_cam_src = (K_src_inv @ pts_pixel_3.T).T * depth  # [N, 3]

            # Step 2: Apply E_rel to transform from source cam to target cam
            E_rel_squeezed = E_rel.squeeze(0)  # [4, 4]
            pts_cam_src_hom = torch.cat(
                [pts_cam_src, torch.ones(H * W, 1, dtype=torch.float64)], dim=-1
            )  # [N, 4]
            pts_cam_tgt = (E_rel_squeezed @ pts_cam_src_hom.T).T  # [N, 4]
            pts_cam_tgt_3d = pts_cam_tgt[:, :3]  # [N, 3]

            # Step 3: Project via Ktgt
            K_tgt = cams.k_tgt.squeeze(0)  # [3, 3]
            result_B_hom = (K_tgt @ pts_cam_tgt_3d.T).T  # [N, 3]
            result_B_z = result_B_hom[:, 2:3]  # [N, 1]
            result_B_pixel = result_B_hom[:, :2] / result_B_z  # [N, 2]

            # --- Assert equivalence within tolerance ---
            assert torch.allclose(result_A_pixel, result_B_pixel, atol=1e-4), (
                f"Baked projection P does not match decomposed (E_rel, Ktgt) path "
                f"at depth={depth.item():.1f}. "
                f"Max diff: {(result_A_pixel - result_B_pixel).abs().max().item():.6e}"
            )


# ---------------------------------------------------------------------------
# Tests for validate() catching missing/singular parameters
# ---------------------------------------------------------------------------


class TestCameraValidation:
    """Test that CameraModule.validate() catches missing and singular parameters."""

    def test_validate_missing_k_src(self) -> None:
        """validate() raises on missing k_src."""
        cams = ViewCameras(
            k_src=None,
            e_src=torch.eye(4).unsqueeze(0),
            k_tgt=torch.eye(3).unsqueeze(0),
            e_tgt=torch.eye(4).unsqueeze(0),
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="k_src"):
            cam_module.validate(cams)

    def test_validate_missing_e_src(self) -> None:
        """validate() raises on missing e_src."""
        cams = ViewCameras(
            k_src=torch.eye(3).unsqueeze(0),
            e_src=None,
            k_tgt=torch.eye(3).unsqueeze(0),
            e_tgt=torch.eye(4).unsqueeze(0),
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="e_src"):
            cam_module.validate(cams)

    def test_validate_missing_k_tgt(self) -> None:
        """validate() raises on missing k_tgt."""
        cams = ViewCameras(
            k_src=torch.eye(3).unsqueeze(0),
            e_src=torch.eye(4).unsqueeze(0),
            k_tgt=None,
            e_tgt=torch.eye(4).unsqueeze(0),
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="k_tgt"):
            cam_module.validate(cams)

    def test_validate_missing_e_tgt(self) -> None:
        """validate() raises on missing e_tgt."""
        cams = ViewCameras(
            k_src=torch.eye(3).unsqueeze(0),
            e_src=torch.eye(4).unsqueeze(0),
            k_tgt=torch.eye(3).unsqueeze(0),
            e_tgt=None,
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="e_tgt"):
            cam_module.validate(cams)

    def test_validate_multiple_missing(self) -> None:
        """validate() reports all missing parameters."""
        cams = ViewCameras(k_src=None, e_src=None, k_tgt=None, e_tgt=None)
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="k_src.*e_src.*k_tgt.*e_tgt"):
            cam_module.validate(cams)

    def test_validate_singular_e_src(self) -> None:
        """validate() raises on a singular (zero) e_src."""
        cams = ViewCameras(
            k_src=torch.eye(3).unsqueeze(0),
            e_src=torch.zeros(1, 4, 4),  # singular
            k_tgt=torch.eye(3).unsqueeze(0),
            e_tgt=torch.eye(4).unsqueeze(0),
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="e_src"):
            cam_module.validate(cams)

    def test_validate_singular_k_src(self) -> None:
        """validate() raises on a singular (zero) k_src."""
        cams = ViewCameras(
            k_src=torch.zeros(1, 3, 3),  # singular
            e_src=torch.eye(4).unsqueeze(0),
            k_tgt=torch.eye(3).unsqueeze(0),
            e_tgt=torch.eye(4).unsqueeze(0),
        )
        cam_module = CameraModule()
        with pytest.raises(CameraValidationError, match="k_src"):
            cam_module.validate(cams)

    def test_validate_passes_for_valid_cameras(self) -> None:
        """validate() does not raise for well-conditioned cameras."""
        K = torch.tensor([[[500.0, 0.0, 320.0], [0.0, 500.0, 240.0], [0.0, 0.0, 1.0]]])
        E = torch.eye(4).unsqueeze(0)
        cams = ViewCameras(k_src=K, e_src=E, k_tgt=K, e_tgt=E)
        cam_module = CameraModule()
        # Should not raise
        cam_module.validate(cams)
