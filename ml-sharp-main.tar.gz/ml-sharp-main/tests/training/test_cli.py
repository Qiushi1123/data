"""CLI example tests for `sharp train` (Task 14.2).

Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.7, 1.8, 1.9, 22.2, 22.3

These are example-based (not property-based) tests that exercise the CLI's
startup validation and error paths using click.testing.CliRunner.
"""

from __future__ import annotations

import json
import pathlib
from unittest.mock import patch

import pytest
import torch
from click.testing import CliRunner

from sharp.cli import main_cli
from sharp.cli.train import _resolve_device


@pytest.fixture
def runner() -> CliRunner:
    """Provide a CliRunner with isolated filesystem disabled (we use tmp_path)."""
    return CliRunner()


def _make_min_dataset(tmp_path: pathlib.Path) -> pathlib.Path:
    """Create a minimal dataset root (empty scene list) so the CLI passes the
    --data-root validation without needing real image files."""
    root = tmp_path / "dataset"
    root.mkdir(parents=True, exist_ok=True)
    (root / "stage1_manifest.json").write_text(
        json.dumps({"scene_count": 0, "scenes": []}), encoding="utf-8"
    )
    return root


def _make_real_image_dir(tmp_path: pathlib.Path) -> pathlib.Path:
    """Create a tiny real-image directory for Stage 2 CLI validation."""
    import numpy as np
    from PIL import Image

    root = tmp_path / "real_images"
    root.mkdir(parents=True, exist_ok=True)
    image = (np.ones((8, 8, 3), dtype=np.uint8) * 127)
    Image.fromarray(image).save(root / "real.png")
    return root


@pytest.fixture
def valid_config(tmp_path: pathlib.Path) -> pathlib.Path:
    """Write a minimal valid JSON config with requires_renderer=False.

    This allows tests to run on CPU without needing CUDA.
    """
    config = {
        "requires_renderer": False,
        "checkpoint_interval": 1,
        "stage": {
            "name": "stage1",
            "total_steps": 2,
            "active_losses": ["color", "alpha"],
        },
    }
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")
    return config_path


@pytest.fixture
def renderer_config(tmp_path: pathlib.Path) -> pathlib.Path:
    """Write a config that requires the renderer (requires_renderer=True)."""
    config = {
        "requires_renderer": True,
        "checkpoint_interval": 1,
        "stage": {
            "name": "stage1",
            "total_steps": 2,
            "active_losses": ["color", "alpha"],
        },
    }
    config_path = tmp_path / "renderer_config.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")
    return config_path


class TestHelpListsTrain:
    """Requirement 1.1: `train` appears in the CLI help output."""

    def test_help_lists_train(self, runner: CliRunner):
        """Invoking main CLI --help should list the 'train' command."""
        result = runner.invoke(main_cli, ["--help"])
        assert result.exit_code == 0
        assert "train" in result.output


class TestInvalidConfigFails:
    """Requirement 1.7: Invalid config fails before creating output dir."""

    def test_nonexistent_config_fails(self, runner: CliRunner, tmp_path: pathlib.Path):
        """A config path that does not exist causes a non-zero exit."""
        output_dir = tmp_path / "outputs"
        bad_config = tmp_path / "does_not_exist.json"

        result = runner.invoke(main_cli, [
            "train",
            "--config", str(bad_config),
            "--output-dir", str(output_dir),
        ])

        assert result.exit_code != 0
        assert "invalid" in result.output.lower() or "not found" in result.output.lower() or "error" in result.output.lower()
        # Output dir should NOT have been created
        assert not output_dir.exists()

    def test_malformed_json_config_fails(self, runner: CliRunner, tmp_path: pathlib.Path):
        """A config file with invalid JSON causes a non-zero exit."""
        output_dir = tmp_path / "outputs"
        bad_config = tmp_path / "bad.json"
        bad_config.write_text("{not valid json!!", encoding="utf-8")

        result = runner.invoke(main_cli, [
            "train",
            "--config", str(bad_config),
            "--output-dir", str(output_dir),
        ])

        assert result.exit_code != 0
        assert "invalid" in result.output.lower() or "error" in result.output.lower()
        assert not output_dir.exists()


class TestUnreadableResumeFails:
    """Requirement 1.8: Non-existent resume checkpoint fails with error."""

    def test_unreadable_resume_fails(
        self, runner: CliRunner, valid_config: pathlib.Path, tmp_path: pathlib.Path
    ):
        """A resume path pointing to a non-existent file causes a non-zero exit."""
        output_dir = tmp_path / "outputs"
        bad_resume = tmp_path / "nonexistent_checkpoint.pt"

        result = runner.invoke(main_cli, [
            "train",
            "--config", str(valid_config),
            "--output-dir", str(output_dir),
            "--resume", str(bad_resume),
        ])

        assert result.exit_code != 0
        assert "checkpoint" in result.output.lower() or "resume" in result.output.lower() or "error" in result.output.lower()


class TestUnsupportedDeviceFails:
    """Requirement 1.9 / 22.2: Unsupported device type fails before work."""

    def test_unsupported_device_fails(
        self, runner: CliRunner, valid_config: pathlib.Path, tmp_path: pathlib.Path
    ):
        """An unsupported device string causes a non-zero exit."""
        output_dir = tmp_path / "outputs"

        result = runner.invoke(main_cli, [
            "train",
            "--config", str(valid_config),
            "--output-dir", str(output_dir),
            "--device", "bad_device",
        ])

        assert result.exit_code != 0
        assert "unsupported" in result.output.lower() or "device" in result.output.lower()
        assert not output_dir.exists()


class TestDeviceResolution:
    """Requirement 22.2: Explicit CUDA device strings are accepted."""

    def test_indexed_cuda_device_resolves_without_real_gpu(self):
        """`cuda:0` should parse as an indexed CUDA device when CUDA is mocked."""
        with patch("sharp.cli.train.torch.cuda.is_available", return_value=True), \
             patch("sharp.cli.train.torch.cuda.device_count", return_value=1):
            assert _resolve_device("cuda:0") == torch.device("cuda", 0)


class TestCudaRequiredFailsOnCpu:
    """Requirement 1.6 / 22.3: requires_renderer=True + non-CUDA device → error."""

    def test_cuda_required_fails_on_cpu(
        self, runner: CliRunner, renderer_config: pathlib.Path, tmp_path: pathlib.Path
    ):
        """A config requiring the renderer on a non-CUDA device causes error."""
        output_dir = tmp_path / "outputs"

        result = runner.invoke(main_cli, [
            "train",
            "--config", str(renderer_config),
            "--output-dir", str(output_dir),
            "--device", "cpu",
        ])

        assert result.exit_code != 0
        assert "cuda" in result.output.lower()
        assert not output_dir.exists()


class TestStageSelection:
    """Requirement 1.4: --stage sets the step budget correctly."""

    def test_stage1_sets_step_budget(
        self, runner: CliRunner, tmp_path: pathlib.Path
    ):
        """--stage stage1 sets total_steps to 100000."""
        config = {
            "requires_renderer": False,
            "checkpoint_interval": 5000,
            "stage": {
                "name": "stage2",
                "total_steps": 60000,
                "active_losses": ["color"],
            },
        }
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(config), encoding="utf-8")
        output_dir = tmp_path / "outputs"

        # Patch at the source modules since they are lazily imported inside the function
        with patch("sharp.models.create_predictor") as mock_create, \
             patch("sharp.training.loop.TrainingLoop") as mock_loop_cls:
            import torch.nn as nn
            student_model = nn.Linear(1, 1)
            teacher_model = nn.Linear(1, 1)
            mock_create.side_effect = [student_model, teacher_model]
            teacher_weights = tmp_path / "teacher.pt"
            torch.save(teacher_model.state_dict(), teacher_weights)

            mock_loop = mock_loop_cls.return_value
            mock_loop.optim_scheduler = type(
                "OS", (), {"optimizer": type("O", (), {"load_state_dict": lambda self, x: None})()}
            )()

            result = runner.invoke(main_cli, [
                "train",
                "--config", str(config_path),
                "--output-dir", str(output_dir),
                "--data-root", str(_make_min_dataset(tmp_path)),
                "--stage", "stage1",
                "--device", "cpu",
            ])

            # The CLI should succeed (exit_code 0) and set stage1 with 100000 steps
            assert result.exit_code == 0, f"CLI failed: {result.output}"
            # Check that the config passed to TrainingLoop has stage1/100000
            call_kwargs = mock_loop_cls.call_args
            passed_config = call_kwargs.kwargs.get("config") or call_kwargs[1].get("config")
            if passed_config is None and call_kwargs.args:
                passed_config = call_kwargs.args[0]
            assert passed_config.stage.name == "stage1"
            assert passed_config.stage.total_steps == 100000

    def test_stage2_sets_step_budget(
        self, runner: CliRunner, tmp_path: pathlib.Path
    ):
        """--stage stage2 sets total_steps to 60000."""
        config = {
            "requires_renderer": False,
            "checkpoint_interval": 5000,
            "stage": {
                "name": "stage1",
                "total_steps": 100000,
                "active_losses": ["color"],
            },
        }
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(config), encoding="utf-8")
        output_dir = tmp_path / "outputs"

        with patch("sharp.models.create_predictor") as mock_create, \
             patch("sharp.training.loop.TrainingLoop") as mock_loop_cls:
            import torch.nn as nn
            student_model = nn.Linear(1, 1)
            teacher_model = nn.Linear(1, 1)
            mock_create.side_effect = [student_model, teacher_model]
            teacher_weights = tmp_path / "teacher.pt"
            torch.save(teacher_model.state_dict(), teacher_weights)

            mock_loop = mock_loop_cls.return_value
            mock_loop.optim_scheduler = type(
                "OS", (), {"optimizer": type("O", (), {"load_state_dict": lambda self, x: None})()}
            )()

            result = runner.invoke(main_cli, [
                "train",
                "--config", str(config_path),
                "--output-dir", str(output_dir),
                "--data-root", str(_make_real_image_dir(tmp_path)),
                "--stage", "stage2",
                "--teacher-weights", str(teacher_weights),
                "--device", "cpu",
            ])

            assert result.exit_code == 0, f"CLI failed: {result.output}"
            call_kwargs = mock_loop_cls.call_args
            passed_config = call_kwargs.kwargs.get("config") or call_kwargs[1].get("config")
            if passed_config is None and call_kwargs.args:
                passed_config = call_kwargs.args[0]
            assert passed_config.stage.name == "stage2"
            assert passed_config.stage.total_steps == 60000


class TestValidConfigCreatesOutputDir:
    """Requirement 1.2: A valid config creates the output directory."""

    def test_valid_config_creates_output_dir(
        self, runner: CliRunner, valid_config: pathlib.Path, tmp_path: pathlib.Path
    ):
        """A valid config with requires_renderer=False creates the output dir."""
        output_dir = tmp_path / "new_output_dir"
        assert not output_dir.exists()

        # Patch heavy imports to avoid building the full model
        with patch("sharp.models.create_predictor") as mock_create, \
             patch("sharp.training.loop.TrainingLoop") as mock_loop_cls:
            import torch.nn as nn
            mock_model = nn.Linear(1, 1)
            mock_create.return_value = mock_model

            mock_loop = mock_loop_cls.return_value
            mock_loop.optim_scheduler = type(
                "OS", (), {"optimizer": type("O", (), {"load_state_dict": lambda self, x: None})()}
            )()

            result = runner.invoke(main_cli, [
                "train",
                "--config", str(valid_config),
                "--output-dir", str(output_dir),
                "--data-root", str(_make_min_dataset(tmp_path)),
                "--device", "cpu",
            ])

            assert result.exit_code == 0, f"CLI failed: {result.output}"
            assert output_dir.exists()
            assert output_dir.is_dir()
