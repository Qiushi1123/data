"""Example/spy tests for behavioral requirements.

Validates:
  - Renderer invoked exactly twice per sample (Req 4.1)
  - Perceptual mask applied before feature extraction (Req 7.4)
  - Scale loss uses the retained S (Req 14.3)
  - Stage 1 default step count is 100000 (Req 20.4)
  - Stage 2 default step count is 60000 (Req 21.4)

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call

import pytest
import torch

from sharp.training.camera import CameraModule, ViewCameras
from sharp.training.config import LossWeights, StageConfig
from sharp.training.forward import TrainingForward
from sharp.training.losses.perceptual import PerceptualLoss
from sharp.training.losses.scale import ScaleLoss
from sharp.training.masking import ViewMasker
from sharp.training.pipeline import Stage1_Pipeline, Stage2_Pipeline
from sharp.training.step import TrainingSample, training_step
from sharp.training.types import LossContext, RenderTrainOutputs
from sharp.utils.gaussians import Gaussians3D


# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------

_B = 1
_H = 8
_W = 8
_N = 16  # number of Gaussians


def _make_cameras(device: torch.device = torch.device("cpu")) -> ViewCameras:
    """Create minimal valid cameras."""
    k = torch.eye(3, device=device).unsqueeze(0)  # [1, 3, 3]
    k[0, 0, 0] = 500.0
    k[0, 1, 1] = 500.0
    k[0, 0, 2] = _W / 2.0
    k[0, 1, 2] = _H / 2.0
    e = torch.eye(4, device=device).unsqueeze(0)  # [1, 4, 4]
    return ViewCameras(k_src=k, e_src=e, k_tgt=k.clone(), e_tgt=e.clone())


def _make_render_outputs(
    device: torch.device = torch.device("cpu"),
    requires_grad: bool = True,
) -> RenderTrainOutputs:
    """Create minimal RenderTrainOutputs."""
    color = torch.rand(_B, 3, _H, _W, device=device, requires_grad=requires_grad)
    depth = torch.rand(_B, 1, _H, _W, device=device, requires_grad=requires_grad) + 0.1
    alpha = torch.rand(_B, 1, _H, _W, device=device, requires_grad=requires_grad) * 0.8 + 0.1
    meta = {
        "conics": torch.zeros(_B, _N, 3, device=device),
        "covars2d": torch.eye(2, device=device).unsqueeze(0).unsqueeze(0).expand(_B, _N, 2, 2).clone(),
        "depths": torch.ones(_B, _N, device=device),
    }
    return RenderTrainOutputs(color=color, depth=depth, alpha=alpha, meta=meta)


def _make_mock_renderer():
    """Create a mock renderer that returns valid RenderTrainOutputs and counts calls."""
    renderer = MagicMock()

    def _forward_train(gaussians, extrinsics, intrinsics, image_width, image_height):
        B = gaussians.mean_vectors.shape[0]
        device = gaussians.mean_vectors.device
        # Produce outputs derived from gaussians so autograd works
        avg_color = gaussians.colors.mean(dim=1)
        color = avg_color[:, :, None, None].expand(B, 3, image_height, image_width)
        color = color + gaussians.mean_vectors.mean() * 0.001
        color = color.clamp(0.0, 1.0)
        depth = torch.ones(B, 1, image_height, image_width, device=device) * 0.5
        alpha = torch.ones(B, 1, image_height, image_width, device=device) * 0.8
        alpha.requires_grad_(True)
        meta = {
            "conics": torch.zeros(B, 1, 3, device=device),
            "covars2d": torch.zeros(B, 1, 2, 2, device=device),
            "depths": torch.ones(B, 1, device=device),
        }
        return RenderTrainOutputs(color=color, depth=depth, alpha=alpha, meta=meta)

    renderer.forward_train = MagicMock(side_effect=_forward_train)
    return renderer


def _make_sample(device: torch.device = torch.device("cpu")) -> TrainingSample:
    """Create a minimal TrainingSample."""
    return TrainingSample(
        input_image=torch.rand(_B, 3, _H, _W, device=device),
        novel_image=torch.rand(_B, 3, _H, _W, device=device),
        cameras=_make_cameras(device),
        disparity_factor=torch.tensor([1.0], device=device),
        input_depth=None,
    )


def _make_stub_predictor():
    """Build a tiny stub predictor (nn.Module) that returns TrainingOutputs-like data."""
    from tests.training.test_forward import _build_stub_predictor
    return _build_stub_predictor()


# ---------------------------------------------------------------------------
# Test: Renderer invoked exactly twice per sample (Req 4.1)
# ---------------------------------------------------------------------------


class TestRendererInvokedTwice:
    """Verify the renderer's forward_train is called exactly twice per training step."""

    def test_renderer_invoked_twice_per_sample(self) -> None:
        """training_step calls renderer.forward_train exactly 2 times (input + novel view)."""
        from sharp.training.aggregator import LossAggregator, create_aggregator
        from sharp.training.losses.color import ColorLoss
        from sharp.training.losses.alpha import AlphaLoss
        from sharp.training.forward import TrainingForward

        # Build a tiny stub predictor
        predictor = _make_stub_predictor()
        training_forward = TrainingForward(predictor)

        # Mock renderer with call counting
        renderer = _make_mock_renderer()

        # Components
        camera_module = CameraModule()
        view_masker = ViewMasker()
        aggregator = create_aggregator(
            weights=LossWeights(),
            stage=StageConfig(name="stage1", active_losses={"color", "alpha"}),
            device=torch.device("cpu"),
        )

        sample = _make_sample()

        # Run the training step
        result = training_step(
            sample=sample,
            training_forward=training_forward,
            renderer=renderer,
            camera_module=camera_module,
            view_masker=view_masker,
            aggregator=aggregator,
            image_height=_H,
            image_width=_W,
        )

        # Assert: renderer.forward_train was invoked exactly twice
        assert renderer.forward_train.call_count == 2


# ---------------------------------------------------------------------------
# Test: Perceptual mask applied before feature extraction (Req 7.4)
# ---------------------------------------------------------------------------


class TestPerceptualMaskAppliedBeforeExtraction:
    """Verify that mask M is applied to inputs before feature extraction."""

    def test_perceptual_mask_applied_before_extraction(self) -> None:
        """PerceptualLoss applies M to rendered/GT images before passing to the extractor."""
        # Create a PerceptualLoss instance
        percep_loss = PerceptualLoss(weight=3.0, device=torch.device("cpu"))

        # Create test inputs
        B, C, H, W = 1, 3, 64, 64
        rendered_color = torch.rand(B, C, H, W, requires_grad=True)
        gt_color = torch.rand(B, C, H, W)

        # Create a mask that zeros out the bottom half
        mask = torch.zeros(B, 1, H, W)
        mask[:, :, :H // 2, :] = 1.0  # Only top half is visible

        # Build a LossContext
        novel_render = RenderTrainOutputs(
            color=rendered_color,
            depth=torch.ones(B, 1, H, W),
            alpha=torch.ones(B, 1, H, W),
            meta={},
        )

        ctx = LossContext(
            novel_render=novel_render,
            novel_gt_image=gt_color,
            mask=mask,
        )

        # Spy on the feature extractor's forward method
        original_forward = percep_loss.extractor.forward
        call_inputs = []

        def spy_forward(x: torch.Tensor):
            call_inputs.append(x.detach().clone())
            return original_forward(x)

        with patch.object(percep_loss.extractor, "forward", side_effect=spy_forward):
            record = percep_loss(ctx)

        # The extractor was called twice (rendered and GT), both masked
        assert len(call_inputs) == 2

        # Verify: the bottom half (where mask=0) should be zero in both inputs
        for inp in call_inputs:
            bottom_half = inp[:, :, H // 2:, :]
            assert (bottom_half == 0.0).all(), (
                "Bottom half should be zeroed by the mask before extraction"
            )


# ---------------------------------------------------------------------------
# Test: Scale loss uses the retained S (Req 14.3)
# ---------------------------------------------------------------------------


class TestScaleLossUsesRetainedS:
    """Verify that ScaleLoss uses the scale_map from LossContext (the retained S)."""

    def test_scale_loss_uses_retained_S(self) -> None:
        """ScaleLoss computes from ctx.scale_map (the retained S), not recomputed."""
        scale_loss = ScaleLoss(weight=0.1)

        # Provide a known scale_map in LossContext
        known_S = torch.tensor([[[[2.0, 1.0], [1.5, 1.0]]]])  # [1, 1, 2, 2]
        # Expected: mean(|2-1|, |1-1|, |1.5-1|, |1-1|) = mean(1, 0, 0.5, 0) = 0.375
        expected_loss = 0.375

        ctx = LossContext(scale_map=known_S)
        record = scale_loss(ctx)

        assert record.active is True
        assert record.finite is True
        assert abs(record.value.item() - expected_loss) < 1e-6, (
            f"ScaleLoss should use the retained S directly. "
            f"Expected {expected_loss}, got {record.value.item()}"
        )

    def test_scale_loss_returns_zero_when_S_unavailable(self) -> None:
        """ScaleLoss returns 0.0 (inactive) when scale_map is None."""
        scale_loss = ScaleLoss(weight=0.1)
        ctx = LossContext(scale_map=None)
        record = scale_loss(ctx)

        assert record.active is False
        assert record.value.item() == 0.0
        assert record.diagnostics.get("reason") == "S unavailable"


# ---------------------------------------------------------------------------
# Test: Stage default step counts (Req 20.4, 21.4)
# ---------------------------------------------------------------------------


class TestStageDefaultStepCounts:
    """Verify that Stage1_Pipeline defaults to 100000 steps and Stage2_Pipeline to 60000."""

    def test_stage1_default_100k_steps(self) -> None:
        """Stage1_Pipeline with default total_steps == 100000."""
        # Create a minimal SampleSource
        source = MagicMock()
        source.__iter__ = MagicMock(return_value=iter([]))
        source.__len__ = MagicMock(return_value=0)

        pipeline = Stage1_Pipeline(source=source)
        assert pipeline.total_steps == 100000

    def test_stage2_default_60k_steps(self) -> None:
        """Stage2_Pipeline with default total_steps == 60000."""
        # Create minimal mocks for Stage2_Pipeline
        source = MagicMock()
        source.__iter__ = MagicMock(return_value=iter([]))
        source.__len__ = MagicMock(return_value=0)
        pseudo_view_generator = MagicMock()

        pipeline = Stage2_Pipeline(
            source=source,
            pseudo_view_generator=pseudo_view_generator,
        )
        assert pipeline.total_steps == 60000
