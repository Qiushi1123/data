# Feature: sharp-training-framework, Property 21
"""Property test for checkpoint round-trip and resume step (Property 21).

**Validates: Requirements 19.1, 19.2**

Property 21: Checkpoint state round-trips and resumes at saved step plus one.

For any training state (model weights, optimizer state, scheduler state, step),
saving a checkpoint and loading it back produces identical state. Resume returns
the saved step so training continues at step + 1.
"""

from __future__ import annotations

import tempfile

import torch
import torch.nn as nn
from hypothesis import given, settings, HealthCheck
from hypothesis import strategies as st

from sharp.training.checkpoint import CheckpointManager


# --- Simple nn.Module for testing (not the full predictor) ---


class SimpleModel(nn.Module):
    """A minimal model for checkpoint round-trip testing."""

    def __init__(self, in_features: int = 4, hidden: int = 8, out_features: int = 2):
        super().__init__()
        self.linear1 = nn.Linear(in_features, hidden)
        self.linear2 = nn.Linear(hidden, out_features)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear2(torch.relu(self.linear1(x)))


# --- Hypothesis strategies ---


@st.composite
def training_state(draw):
    """Generate a random valid training state (model, optimizer, scheduler, step).

    Returns (in_features, hidden, out_features, step, lr) so the test can
    reconstruct matching model/optimizer/scheduler.
    """
    in_features = draw(st.integers(min_value=2, max_value=8))
    hidden = draw(st.integers(min_value=2, max_value=16))
    out_features = draw(st.integers(min_value=1, max_value=4))
    step = draw(st.integers(min_value=0, max_value=100000))
    lr = draw(
        st.floats(min_value=1e-6, max_value=1e-1, allow_nan=False, allow_infinity=False)
    )
    return in_features, hidden, out_features, step, lr


@st.composite
def checkpoint_interval_and_step(draw):
    """Generate a valid checkpoint interval and a step that is a multiple of it."""
    interval = draw(st.integers(min_value=1, max_value=5000))
    multiplier = draw(st.integers(min_value=1, max_value=20))
    step = interval * multiplier
    return interval, step


# --- Property tests ---


class TestCheckpointRoundTrip:
    """Property 21: Checkpoint state round-trips and resumes at saved step plus one."""

    @settings(max_examples=100, deadline=None)
    @given(data=training_state())
    def test_checkpoint_round_trip_preserves_model_weights(self, data):
        """For any model weights, save+load produces identical state_dict."""
        in_features, hidden, out_features, step, lr = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            # Create and randomize model
            model = SimpleModel(in_features, hidden, out_features)
            with torch.no_grad():
                for param in model.parameters():
                    param.normal_()

            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            scheduler_state = step

            # Save checkpoint
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=1)
            saved_path = mgr.save(model, optimizer, scheduler_state, step)

            # Load checkpoint into a fresh model
            fresh_model = SimpleModel(in_features, hidden, out_features)
            fresh_optimizer = torch.optim.Adam(fresh_model.parameters(), lr=lr)

            mgr.restore(fresh_model, fresh_optimizer, None, saved_path)

            # Model weights must be identical
            for (name, orig_param), (_, fresh_param) in zip(
                model.named_parameters(), fresh_model.named_parameters()
            ):
                assert torch.equal(orig_param, fresh_param), (
                    f"Model parameter '{name}' differs after round-trip"
                )

    @settings(max_examples=100, deadline=None)
    @given(data=training_state())
    def test_checkpoint_round_trip_preserves_optimizer_state(self, data):
        """For any optimizer state, save+load produces identical optimizer state_dict."""
        in_features, hidden, out_features, step, lr = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            model = SimpleModel(in_features, hidden, out_features)
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)

            # Do a forward+backward to populate optimizer state
            x = torch.randn(2, in_features)
            loss = model(x).sum()
            loss.backward()
            optimizer.step()

            scheduler_state = step

            # Save
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=1)
            saved_path = mgr.save(model, optimizer, scheduler_state, step)

            # Load into fresh model/optimizer
            fresh_model = SimpleModel(in_features, hidden, out_features)
            fresh_optimizer = torch.optim.Adam(fresh_model.parameters(), lr=lr)

            mgr.restore(fresh_model, fresh_optimizer, None, saved_path)

            # Optimizer state_dicts must match
            orig_state = optimizer.state_dict()
            fresh_state = fresh_optimizer.state_dict()

            # Check param_groups match
            assert len(orig_state["param_groups"]) == len(fresh_state["param_groups"])
            for orig_pg, fresh_pg in zip(
                orig_state["param_groups"], fresh_state["param_groups"]
            ):
                for key in orig_pg:
                    if key == "params":
                        assert orig_pg[key] == fresh_pg[key]
                    else:
                        assert orig_pg[key] == fresh_pg[key], (
                            f"Optimizer param_group key '{key}' differs"
                        )

            # Check per-parameter state (momentum buffers, etc.)
            assert len(orig_state["state"]) == len(fresh_state["state"])
            for param_id in orig_state["state"]:
                assert param_id in fresh_state["state"], (
                    f"Missing param_id {param_id} in restored optimizer state"
                )
                for key, val in orig_state["state"][param_id].items():
                    fresh_val = fresh_state["state"][param_id][key]
                    if isinstance(val, torch.Tensor):
                        assert torch.equal(val, fresh_val), (
                            f"Optimizer state[{param_id}]['{key}'] tensor differs"
                        )
                    else:
                        assert val == fresh_val, (
                            f"Optimizer state[{param_id}]['{key}'] differs: "
                            f"{val} vs {fresh_val}"
                        )

    @settings(max_examples=100, deadline=None)
    @given(data=training_state())
    def test_checkpoint_round_trip_preserves_scheduler_state(self, data):
        """For any scheduler state, save+load preserves it exactly."""
        in_features, hidden, out_features, step, lr = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            model = SimpleModel(in_features, hidden, out_features)
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            scheduler_state = step

            # Save
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=1)
            saved_path = mgr.save(model, optimizer, scheduler_state, step)

            # Load and verify scheduler_state is preserved in checkpoint data
            checkpoint = mgr.load(saved_path)
            assert checkpoint["scheduler_state"] == scheduler_state, (
                f"Scheduler state not preserved: saved={scheduler_state}, "
                f"loaded={checkpoint['scheduler_state']}"
            )

    @settings(max_examples=100, deadline=None)
    @given(data=training_state())
    def test_resume_returns_saved_step(self, data):
        """Resume returns the saved step so training continues at step + 1."""
        in_features, hidden, out_features, step, lr = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            model = SimpleModel(in_features, hidden, out_features)
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            scheduler_state = step

            # Save
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=1)
            saved_path = mgr.save(model, optimizer, scheduler_state, step)

            # Restore into fresh model
            fresh_model = SimpleModel(in_features, hidden, out_features)
            fresh_optimizer = torch.optim.Adam(fresh_model.parameters(), lr=lr)

            restored_step = mgr.restore(
                fresh_model, fresh_optimizer, None, saved_path
            )

            # Resume returns the saved step; training continues at step + 1
            assert restored_step == step, (
                f"Restored step should be {step}, got {restored_step}"
            )
            # The next training step should be step + 1
            next_step = restored_step + 1
            assert next_step == step + 1, (
                f"Next training step should be {step + 1}, got {next_step}"
            )

    @settings(max_examples=100, deadline=None)
    @given(data=training_state())
    def test_full_state_round_trip_identity(self, data):
        """For any training state, the full round-trip (save then restore)
        produces a model+optimizer that is functionally identical to the original.
        Verified by running a forward pass on both and comparing outputs."""
        in_features, hidden, out_features, step, lr = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            # Original model with randomized weights
            model = SimpleModel(in_features, hidden, out_features)
            with torch.no_grad():
                for param in model.parameters():
                    param.normal_()

            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            # Do a step to populate optimizer state
            x = torch.randn(2, in_features)
            loss = model(x).sum()
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

            scheduler_state = step

            # Save
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=1)
            saved_path = mgr.save(model, optimizer, scheduler_state, step)

            # Restore
            fresh_model = SimpleModel(in_features, hidden, out_features)
            fresh_optimizer = torch.optim.Adam(fresh_model.parameters(), lr=lr)
            restored_step = mgr.restore(
                fresh_model, fresh_optimizer, None, saved_path
            )

            # Both models should produce identical output for any input
            test_input = torch.randn(3, in_features)
            model.eval()
            fresh_model.eval()
            with torch.no_grad():
                orig_output = model(test_input)
                fresh_output = fresh_model(test_input)

            assert torch.equal(orig_output, fresh_output), (
                "Model outputs differ after checkpoint round-trip"
            )
            assert restored_step == step

    @settings(max_examples=100, deadline=None)
    @given(data=checkpoint_interval_and_step())
    def test_should_save_at_interval_multiples(self, data):
        """CheckpointManager.should_save returns True at positive multiples of interval."""
        interval, step = data

        with tempfile.TemporaryDirectory() as tmp_dir:
            mgr = CheckpointManager(output_dir=tmp_dir, checkpoint_interval=interval)
            assert mgr.should_save(step) is True, (
                f"should_save({step}) must be True for interval={interval}"
            )
            # Step 0 should never trigger a save
            assert mgr.should_save(0) is False, (
                "should_save(0) must always be False"
            )
