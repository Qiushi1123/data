# Feature: sharp-training-framework, Property 25
"""Property test for Stage 2 role-swap and detachment (Property 25).

**Validates: Requirements 21.1, 21.3, 21.6**

Property 25: Every Stage 2 sample has:
  - input_image is the detached pseudo-novel view (no grad_fn),
  - novel_image is the original real image,
  - both match the configured resolution,
  - input_depth is detached teacher pseudo depth when available,
  - and the generation process does not leak gradients.

Uses mock predictor and mock renderer that return simple tensors for the
role-swap/detachment tests, keeping max_examples=10 since it involves model
forward calls.
"""

from __future__ import annotations

from typing import Iterator

import torch
import torch.nn as nn
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.camera import ViewCameras
from sharp.training.pipeline import (
    RawSample,
    SampleSource,
    Stage2_Pipeline,
    Stage2ReplayPipeline,
    TrainingSample,
)
from sharp.training.ssft import (
    FrozenTeacherPseudoViewGenerator,
    PseudoView,
    make_horizontal_symmetric_pose,
)
from sharp.utils.gaussians import Gaussians3D


# ---------------------------------------------------------------------------
# Mock predictor: returns simple Gaussians3D (NDC) with requires_grad on
# parameters so we can verify no grad leaks into the Stage 2 output.
# ---------------------------------------------------------------------------


class MockPredictor(nn.Module):
    """A mock predictor for Stage 2 testing.

    Returns a small Gaussians3D with fixed data. Has a trainable parameter
    so we can verify gradient detachment (no grad flows back through the
    pseudo-novel generation step).
    """

    def __init__(self, num_gaussians: int = 16) -> None:
        super().__init__()
        self._num_gaussians = num_gaussians
        # A trainable parameter to verify grad detachment
        self.weight = nn.Parameter(torch.randn(3))

    def forward(
        self,
        image: torch.Tensor,
        disparity_factor: torch.Tensor,
    ) -> Gaussians3D:
        """Return a simple Gaussians3D derived from the input."""
        B = image.shape[0]
        N = self._num_gaussians
        device = image.device
        dtype = image.dtype

        # Mean vectors in NDC range [-1, 1] with depth > 0
        means = torch.randn(B, N, 3, device=device, dtype=dtype) * 0.1
        means[:, :, 2] = means[:, :, 2].abs() + 0.5  # positive depth

        # Add weight contribution to keep autograd graph if no_grad is NOT used
        means = means + self.weight[None, None, :] * 0.0

        return Gaussians3D(
            mean_vectors=means,
            singular_values=torch.ones(B, N, 3, device=device, dtype=dtype) * 0.01,
            quaternions=torch.tensor(
                [1.0, 0.0, 0.0, 0.0], device=device, dtype=dtype
            ).expand(B, N, 4).contiguous(),
            colors=torch.rand(B, N, 3, device=device, dtype=dtype) * 0.5 + 0.25,
            opacities=torch.ones(B, N, device=device, dtype=dtype) * 0.5,
        )


# ---------------------------------------------------------------------------
# Mock renderer: returns simple color/depth/alpha from Gaussians.
# ---------------------------------------------------------------------------


class MockRenderingOutputs:
    """Simple render output mimicking what the renderer returns."""

    def __init__(self, color: torch.Tensor, depth: torch.Tensor, alpha: torch.Tensor) -> None:
        self.color = color
        self.depth = depth
        self.alpha = alpha


class MockRenderer(nn.Module):
    """A mock renderer that returns a simple colored image.

    Does NOT do actual rasterization — just produces a deterministic output
    based on Gaussian colors so we can test the pipeline logic.
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(
        self,
        gaussians: Gaussians3D,
        extrinsics: torch.Tensor,
        intrinsics: torch.Tensor,
        image_width: int,
        image_height: int,
    ) -> MockRenderingOutputs:
        """Render a simple image from the Gaussians."""
        B = gaussians.mean_vectors.shape[0]
        device = gaussians.mean_vectors.device
        dtype = gaussians.mean_vectors.dtype

        # Produce a color image as the mean of Gaussian colors expanded
        avg_color = gaussians.colors.mean(dim=1)  # [B, 3]
        color = avg_color[:, :, None, None].expand(
            B, 3, image_height, image_width
        ).contiguous()
        # Clamp to [0, 1]
        color = color.clamp(0.0, 1.0)
        depth = torch.ones(B, 1, image_height, image_width, device=device, dtype=dtype)
        alpha = torch.ones(B, 1, image_height, image_width, device=device, dtype=dtype)

        return MockRenderingOutputs(color=color, depth=depth, alpha=alpha)


# ---------------------------------------------------------------------------
# Stub SampleSource providing real single-view images for Stage 2.
# ---------------------------------------------------------------------------


class Stage2StubSource:
    """A stub SampleSource that yields single-view images for Stage 2.

    Each RawSample has:
      - input_image: a random RGB image at the given resolution
      - focal_length_px and image_width for disparity_factor computation
      - novel_image = None (not needed, constructed by Stage 2)
      - cameras = None (constructed by Stage 2)
    """

    def __init__(
        self,
        num_samples: int,
        height: int,
        width: int,
        focal_length_px: float,
    ) -> None:
        self._num_samples = num_samples
        self._height = height
        self._width = width
        self._focal_length_px = focal_length_px
        # Pre-generate images so that they are stable across iterations
        self._images = [
            torch.rand(3, height, width) for _ in range(num_samples)
        ]

    def __iter__(self) -> Iterator[RawSample]:
        for i in range(self._num_samples):
            yield RawSample(
                sample_id=f"stage2_stub_{i}",
                input_image=self._images[i],
                novel_image=None,
                cameras=None,
                input_depth=None,
                focal_length_px=self._focal_length_px,
                image_width=self._width,
            )

    def __len__(self) -> int:
        return self._num_samples


# ---------------------------------------------------------------------------
# Hypothesis strategies
# ---------------------------------------------------------------------------


@st.composite
def stage2_params(draw):
    """Generate parameters for a valid Stage 2 pipeline test.

    Returns (resolution, focal_length_px, num_samples).
    The resolution is kept small (32-64) for speed.
    """
    resolution = draw(st.sampled_from([32, 48, 64]))
    focal_length_px = draw(
        st.floats(min_value=50.0, max_value=2000.0, allow_nan=False, allow_infinity=False)
    )
    num_samples = draw(st.integers(min_value=1, max_value=2))
    return resolution, focal_length_px, num_samples


def _make_generator(
    predictor: nn.Module,
    renderer: nn.Module,
    resolution: int,
    max_disparity: float = 0.05,
) -> FrozenTeacherPseudoViewGenerator:
    return FrozenTeacherPseudoViewGenerator(
        teacher=predictor,
        renderer=renderer,
        resolution=resolution,
        max_disparity=max_disparity,
        device=torch.device("cpu"),
    )


def _make_stage2_pipeline(
    source: SampleSource,
    predictor: nn.Module,
    renderer: nn.Module,
    *,
    total_steps: int,
    resolution: int,
    max_disparity: float = 0.05,
    pseudo_depth_mode: str = "rendered_alignment",
) -> Stage2_Pipeline:
    return Stage2_Pipeline(
        source=source,
        pseudo_view_generator=_make_generator(
            predictor,
            renderer,
            resolution,
            max_disparity,
        ),
        total_steps=total_steps,
        resolution=resolution,
        pseudo_depth_mode=pseudo_depth_mode,
    )


class SpyPseudoViewGenerator:
    """Pseudo-view generator that records requested max disparities."""

    def __init__(self, resolution: int) -> None:
        self.resolution = resolution
        self.seen_max_disparities: list[float | None] = []

    def __call__(
        self,
        real_image: torch.Tensor,
        disparity_factor: torch.Tensor,
        max_disparity: float | None = None,
    ) -> PseudoView:
        self.seen_max_disparities.append(max_disparity)
        intrinsics = torch.eye(3).unsqueeze(0)
        original = torch.eye(4).unsqueeze(0)
        pseudo = torch.eye(4).unsqueeze(0)
        pseudo[0, 0, 3] = 0.0 if max_disparity is None else max_disparity
        return PseudoView(
            image=real_image.detach().clone(),
            intrinsics=intrinsics,
            pseudo_extrinsics=pseudo,
            original_extrinsics=original,
            depth=torch.ones(1, self.resolution, self.resolution),
            alpha=torch.ones(1, self.resolution, self.resolution),
        )


# ---------------------------------------------------------------------------
# Property tests
# ---------------------------------------------------------------------------


class TestStage2RoleSwapAndDetachment:
    """Property 25: Stage 2 swaps roles, matches resolution, and detaches generation."""

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_input_image_is_detached_pseudo_novel_view(self, params):
        """The input_image in each Stage 2 sample has no grad_fn (detached).

        Validates: Requirement 21.6 — the pseudo-novel-view generation is
        detached from the training autograd graph.
        """
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )
        assert all(not p.requires_grad for p in predictor.parameters()), (
            "Stage 2 pseudo-view teacher must be frozen"
        )

        for sample in pipeline:
            # input_image must be detached (no grad_fn)
            assert sample.input_image.grad_fn is None, (
                "Stage 2 input_image should be detached (no grad_fn), "
                f"but got grad_fn={sample.input_image.grad_fn}"
            )
            assert not sample.input_image.requires_grad, (
                "Stage 2 input_image should not require grad"
            )

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_novel_image_is_the_original_real_image(self, params):
        """The novel_image in each Stage 2 sample is the original real image.

        Validates: Requirement 21.3 — the pseudo-novel view serves as input,
        and the real input image serves as the novel-view target.
        """
        resolution, focal_length_px, num_samples = params

        # Create source with known images
        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )

        # Collect the original images from the source for comparison
        original_images = list(source._images)

        for i, sample in enumerate(pipeline):
            # novel_image should be the original (possibly resized) real image
            expected_shape = (3, resolution, resolution)
            assert sample.novel_image.shape == expected_shape, (
                f"novel_image shape {sample.novel_image.shape} != {expected_shape}"
            )
            # Since source images are already at target resolution, novel_image
            # should match the original input (they come from the same source)
            original = original_images[i % num_samples]
            # The pipeline may resize, so compare after resize if needed
            if original.shape[1] == resolution and original.shape[2] == resolution:
                assert torch.allclose(sample.novel_image, original[:3], atol=1e-5), (
                    "novel_image should be the original real input image"
                )

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_both_images_match_configured_resolution(self, params):
        """Both input_image and novel_image match the configured resolution.

        Validates: Requirement 21.1 — the pseudo-novel view is rendered at
        the same resolution as the input image (configured resolution).
        """
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )

        for sample in pipeline:
            expected_shape = (3, resolution, resolution)
            assert sample.input_image.shape == expected_shape, (
                f"input_image shape {sample.input_image.shape} != {expected_shape}"
            )
            assert sample.novel_image.shape == expected_shape, (
                f"novel_image shape {sample.novel_image.shape} != {expected_shape}"
            )

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_input_depth_uses_detached_teacher_pseudo_depth(self, params):
        """Stage 2 samples use detached teacher pseudo depth when available.

        Validates: Stage 2 operates without real GT depth but can use frozen
        teacher pseudo-depth as weak geometry supervision.
        """
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )

        for sample in pipeline:
            assert sample.input_depth is not None
            assert sample.input_disparity is not None
            assert sample.input_depth.shape == (1, resolution, resolution)
            assert sample.input_disparity.shape == (1, resolution, resolution)
            assert sample.input_depth.grad_fn is None
            assert sample.input_disparity.grad_fn is None
            assert torch.all(sample.input_depth > 0)
            assert torch.all(sample.input_disparity > 0)

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_rendered_loss_mode_keeps_disparity_without_alignment_depth(self, params):
        """Depth-loss-only mode must not feed pseudo metric depth to alignment."""
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
            pseudo_depth_mode="rendered_loss",
        )

        for sample in pipeline:
            assert sample.input_depth is None
            assert sample.input_disparity is not None
            assert sample.input_disparity.shape == (1, resolution, resolution)
            assert sample.input_disparity.grad_fn is None

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_no_pseudo_depth_mode_omits_depth_and_disparity(self, params):
        """No-depth SSFT mode should leave depth supervision absent."""
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
            pseudo_depth_mode="none",
        )

        for sample in pipeline:
            assert sample.input_depth is None
            assert sample.input_disparity is None

    def test_pseudo_view_disparity_list_expands_each_source_image(self):
        """Configured Stage 2 disparities should be cycled per real image."""
        resolution = 32
        source = Stage2StubSource(
            num_samples=2,
            height=resolution,
            width=resolution,
            focal_length_px=64.0,
        )
        generator = SpyPseudoViewGenerator(resolution)
        pipeline = Stage2_Pipeline(
            source=source,
            pseudo_view_generator=generator,
            total_steps=6,
            resolution=resolution,
            pseudo_depth_mode="none",
            pseudo_view_disparities=[0.025, 0.04, 0.08],
        )

        samples = list(pipeline)

        assert len(samples) == 6
        assert generator.seen_max_disparities == [0.025, 0.04, 0.08, 0.025, 0.04, 0.08]

    def test_horizontal_symmetric_disparities_expand_to_signed_pairs(self):
        """Symmetric Stage 2 trajectory should explicitly request left/right poses."""
        resolution = 32
        source = Stage2StubSource(
            num_samples=1,
            height=resolution,
            width=resolution,
            focal_length_px=64.0,
        )
        generator = SpyPseudoViewGenerator(resolution)
        pipeline = Stage2_Pipeline(
            source=source,
            pseudo_view_generator=generator,
            total_steps=4,
            resolution=resolution,
            pseudo_depth_mode="none",
            pseudo_view_disparities=[0.025, 0.04],
            pseudo_view_pose_strategy="horizontal_symmetric",
        )

        samples = list(pipeline)

        assert len(samples) == 4
        assert generator.seen_max_disparities == [-0.025, 0.025, -0.04, 0.04]
        requested_x = torch.tensor([sample.cameras.e_src[0, 0, 3] for sample in samples])
        assert torch.allclose(requested_x, torch.tensor([-0.025, 0.025, -0.04, 0.04]))

    def test_horizontal_symmetric_pose_is_deterministic_and_mirrored(self):
        """Signed disparities should produce mirrored x translations and yaw."""
        positive, original_positive = make_horizontal_symmetric_pose(
            0.08,
            device=torch.device("cpu"),
        )
        negative, original_negative = make_horizontal_symmetric_pose(
            -0.08,
            device=torch.device("cpu"),
        )

        assert torch.allclose(original_positive, torch.eye(4).unsqueeze(0))
        assert torch.allclose(original_negative, torch.eye(4).unsqueeze(0))
        assert torch.allclose(positive[:, 0, 3], torch.tensor([0.08]))
        assert torch.allclose(negative[:, 0, 3], torch.tensor([-0.08]))
        assert torch.allclose(positive[:, 0, 0], negative[:, 0, 0])
        assert torch.allclose(positive[:, 2, 2], negative[:, 2, 2])
        assert torch.allclose(positive[:, 0, 2], -negative[:, 0, 2])
        assert torch.allclose(positive[:, 2, 0], -negative[:, 2, 0])

    def test_stage1_replay_pipeline_interleaves_by_ratio(self):
        """Synthetic replay should be inserted deterministically into SSFT stream."""

        def make_sample(value: float) -> TrainingSample:
            image = torch.full((3, 4, 4), value)
            cameras = ViewCameras(
                k_src=torch.eye(3).unsqueeze(0),
                e_src=torch.eye(4).unsqueeze(0),
                k_tgt=torch.eye(3).unsqueeze(0),
                e_tgt=torch.eye(4).unsqueeze(0),
            )
            return TrainingSample(
                input_image=image,
                novel_image=image,
                cameras=cameras,
                disparity_factor=torch.tensor(1.0),
            )

        class InfinitePipeline:
            def __init__(self, value: float) -> None:
                self.value = value

            def __iter__(self):
                while True:
                    yield make_sample(self.value)

        pipeline = Stage2ReplayPipeline(
            stage2_pipeline=InfinitePipeline(2.0),
            stage1_pipeline=InfinitePipeline(1.0),
            stage1_replay_ratio=0.25,
            total_steps=8,
        )

        values = [sample.input_image[0, 0, 0].item() for sample in pipeline]

        assert values == [2.0, 2.0, 2.0, 1.0, 2.0, 2.0, 2.0, 1.0]

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_cameras_are_swapped_from_pseudo_to_real(self, params):
        """Stage 2 source camera is pseudo P1 and target camera is original P0."""
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )

        identity = torch.eye(4)
        for sample in pipeline:
            assert torch.allclose(sample.cameras.e_tgt[0].cpu(), identity), (
                "Stage 2 target camera should be original P0 / identity"
            )
            assert not torch.allclose(sample.cameras.e_src[0].cpu(), identity), (
                "Stage 2 source camera should be the sampled pseudo P1 view"
            )

    @settings(max_examples=10)
    @given(params=stage2_params())
    def test_generation_does_not_leak_gradients(self, params):
        """The pseudo-novel generation does not propagate gradients to predictor params.

        Validates: Requirement 21.6 — no gradient flows through the generation
        step; gradients are computed only for the swapped supervised pass.
        """
        resolution, focal_length_px, num_samples = params

        source = Stage2StubSource(num_samples, resolution, resolution, focal_length_px)
        predictor = MockPredictor(num_gaussians=16)
        renderer = MockRenderer()

        # Enable grad tracking on predictor parameters
        for p in predictor.parameters():
            p.requires_grad_(True)
            if p.grad is not None:
                p.grad.zero_()

        pipeline = _make_stage2_pipeline(
            source=source,
            predictor=predictor,
            renderer=renderer,
            total_steps=num_samples,
            resolution=resolution,
        )

        for sample in pipeline:
            # If we try to compute a loss on input_image and backward,
            # no grad should reach the predictor through input_image
            # because it's detached.
            assert sample.input_image.grad_fn is None, (
                "input_image must be fully detached from the computation graph"
            )

            # Additionally verify: predictor params have no accumulated gradients
            # from the generation process itself
            for name, p in predictor.named_parameters():
                assert p.grad is None or (p.grad == 0).all(), (
                    f"Predictor param '{name}' has non-zero grad after Stage 2 "
                    f"generation, indicating gradient leakage"
                )
