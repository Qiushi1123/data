"""Property-based tests for the freeze policy and optimizer parameter set.

# Feature: sharp-training-framework, Property 18

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.models.predictor import DepthAlignment, RGBGaussianPredictor
from sharp.training.config import FreezePolicy
from sharp.training.freeze import (
    FreezeController,
    _LOWRES_ENCODER_UPSAMPLES,
    _PATCH_ENCODER_PATH,
    _PATCH_ENCODER_UPSAMPLES,
    _TRAINABLE_COMPONENT_MAP,
)
from sharp.utils.module_surgery import NORM_LAYER_TYPES


# ---------------------------------------------------------------------------
# Stub submodules that replicate the hierarchy expected by FreezeController.
# The FreezeController resolves specific dot-separated paths on the predictor,
# so our stubs must expose the same attribute structure.
# ---------------------------------------------------------------------------


class StubPatchEncoder(nn.Module):
    """Stub patch encoder (frozen by policy)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 8, kernel_size=1)
        self.norm = nn.BatchNorm2d(8)  # norm layer — should always be frozen


class StubImageEncoder(nn.Module):
    """Stub low-res image encoder (trainable by policy)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 8, kernel_size=1)
        self.norm = nn.LayerNorm(8)  # norm layer


class StubUpsampleBlock(nn.Module):
    """Stub upsample block with a linear layer."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(8, 8, kernel_size=1)


class StubEncoder(nn.Module):
    """Stub for monodepth_predictor.encoder (SlidingPyramidNetwork-like)."""

    def __init__(self) -> None:
        super().__init__()
        self.patch_encoder = StubPatchEncoder()
        self.image_encoder = StubImageEncoder()
        self.upsample_latent0 = StubUpsampleBlock()
        self.upsample_latent1 = StubUpsampleBlock()
        self.upsample0 = StubUpsampleBlock()
        self.upsample1 = StubUpsampleBlock()
        self.upsample2 = StubUpsampleBlock()
        self.upsample_lowres = nn.ConvTranspose2d(8, 8, kernel_size=2, stride=2)
        self.fuse_lowres = nn.Conv2d(16, 8, kernel_size=1)


class StubDecoder(nn.Module):
    """Stub for monodepth_predictor.decoder."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(8, 8, kernel_size=1)
        self.norm = nn.BatchNorm2d(8)  # norm layer


class StubHead(nn.Module):
    """Stub for monodepth_predictor.head."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(8, 2, kernel_size=1)


class StubMonodepthPredictor(nn.Module):
    """Stub for monodepth_predictor (MonodepthDensePredictionTransformer)."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder = StubEncoder()
        self.decoder = StubDecoder()
        self.head = StubHead()


class StubMonodepthModel(nn.Module):
    """Stub for monodepth_model (MonodepthWithEncodingAdaptor)."""

    def __init__(self) -> None:
        super().__init__()
        self.monodepth_predictor = StubMonodepthPredictor()

    def internal_resolution(self) -> int:
        return 8


class StubScaleMapEstimator(nn.Module):
    """Stub depth-alignment scale-map estimator."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(1, 1, kernel_size=1)
        self.norm = nn.InstanceNorm2d(1)  # norm layer

    def forward(self, monodepth_l0, depth, features=None):
        return torch.ones_like(monodepth_l0)


class StubInitModel(nn.Module):
    """Stub init model (gaussian initializer)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 8, kernel_size=1)
        self.norm = nn.GroupNorm(2, 8)  # norm layer


class StubFeatureModel(nn.Module):
    """Stub feature model (gaussian decoder)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(4, 14, kernel_size=1)
        self.norm = nn.BatchNorm2d(14)  # norm layer


class StubPredictionHead(nn.Module):
    """Stub prediction head."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(14, 14, kernel_size=1)
        self.norm = nn.LayerNorm(14)  # norm layer


class StubGaussianComposer(nn.Module):
    """Stub gaussian composer."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(14, 14)
        self.norm = nn.BatchNorm1d(14)  # norm layer
        self.scale_factor = 1
        self.base_scale_on_predicted_mean = False


def _build_stub_predictor_for_freeze() -> RGBGaussianPredictor:
    """Build a stub predictor whose submodule hierarchy matches the freeze paths."""
    monodepth_model = StubMonodepthModel()
    scale_map_estimator = StubScaleMapEstimator()
    init_model = StubInitModel()
    feature_model = StubFeatureModel()
    prediction_head = StubPredictionHead()
    gaussian_composer = StubGaussianComposer()

    predictor = RGBGaussianPredictor(
        init_model=init_model,
        monodepth_model=monodepth_model,
        feature_model=feature_model,
        prediction_head=prediction_head,
        gaussian_composer=gaussian_composer,
        scale_map_estimator=scale_map_estimator,
    )
    return predictor


def _is_norm_layer(module: nn.Module) -> bool:
    """Check if a module is a normalization layer."""
    return isinstance(module, NORM_LAYER_TYPES)


def _resolve_submodule(model: nn.Module, path: str) -> nn.Module:
    """Resolve a dot-separated path to a submodule."""
    parts = path.split(".")
    current = model
    for part in parts:
        current = getattr(current, part)
    return current


def _get_all_parameters_in_module(module: nn.Module) -> set[int]:
    """Get the set of parameter ids in a module (including nested)."""
    return {id(p) for p in module.parameters()}


# ---------------------------------------------------------------------------
# Property test
# ---------------------------------------------------------------------------


@given(
    freeze_patch_encoder=st.just(True),  # Policy always freezes patch encoder
    freeze_all_norm_layers=st.just(True),  # Policy always freezes norm layers
    train_lowres_encoder=st.booleans(),
    train_dpt_decoder=st.booleans(),
    train_alignment=st.booleans(),
    train_gaussian_decoder=st.booleans(),
    train_composer=st.booleans(),
)
@settings(max_examples=100)
def test_freeze_policy_and_optimizer_parameter_set(
    freeze_patch_encoder: bool,
    freeze_all_norm_layers: bool,
    train_lowres_encoder: bool,
    train_dpt_decoder: bool,
    train_alignment: bool,
    train_gaussian_decoder: bool,
    train_composer: bool,
) -> None:
    """Property 18: Freeze policy sets requires_grad per component and the optimizer matches.

    **Validates: Requirements 17.1, 17.2, 17.3, 17.4, 17.5, 17.6**

    For any constructed predictor, after applying the freeze policy:
    - Every monodepth patch-encoder parameter has requires_grad=False (Req 17.1)
    - Every norm-layer parameter has requires_grad=False (Req 17.2)
    - Low-res encoder non-norm parameters have requires_grad=True when policy says train (Req 17.3)
    - DPT decoder non-norm parameters have requires_grad=True when policy says train (Req 17.4)
    - Alignment / gaussian decoder / composer non-norm parameters have requires_grad=True
      when policy says train (Req 17.5)
    - The optimizer's parameter set equals exactly the set of requires_grad=True parameters (Req 17.6)
    """
    predictor = _build_stub_predictor_for_freeze()

    policy = FreezePolicy(
        freeze_patch_encoder=freeze_patch_encoder,
        freeze_all_norm_layers=freeze_all_norm_layers,
        train_lowres_encoder=train_lowres_encoder,
        train_dpt_decoder=train_dpt_decoder,
        train_alignment=train_alignment,
        train_gaussian_decoder=train_gaussian_decoder,
        train_composer=train_composer,
    )

    controller = FreezeController()
    controller.apply(predictor, policy)

    # --- Req 17.1: Patch encoder parameters are ALL frozen ---
    patch_encoder = _resolve_submodule(predictor, _PATCH_ENCODER_PATH)
    for name, param in patch_encoder.named_parameters():
        assert not param.requires_grad, (
            f"Patch encoder parameter '{name}' must have requires_grad=False (Req 17.1)"
        )

    # Also check patch encoder upsample blocks
    for path in _PATCH_ENCODER_UPSAMPLES:
        module = _resolve_submodule(predictor, path)
        for name, param in module.named_parameters():
            assert not param.requires_grad, (
                f"Patch encoder upsample '{path}.{name}' must have "
                f"requires_grad=False (Req 17.1)"
            )

    # --- Req 17.2: ALL norm layer parameters across the entire model are frozen ---
    for module_name, module in predictor.named_modules():
        if _is_norm_layer(module):
            for param_name, param in module.named_parameters(recurse=False):
                assert not param.requires_grad, (
                    f"Norm layer parameter '{module_name}.{param_name}' must have "
                    f"requires_grad=False (Req 17.2)"
                )

    # --- Req 17.3: Low-res encoder non-norm params respect policy ---
    lowres_encoder_path = (
        "monodepth_model.monodepth_predictor.encoder.image_encoder"
    )
    lowres_encoder = _resolve_submodule(predictor, lowres_encoder_path)
    for submodule in lowres_encoder.modules():
        if _is_norm_layer(submodule):
            continue
        for param in submodule.parameters(recurse=False):
            if train_lowres_encoder:
                assert param.requires_grad, (
                    f"Low-res encoder non-norm param must have requires_grad=True "
                    f"when train_lowres_encoder=True (Req 17.3)"
                )
            else:
                assert not param.requires_grad, (
                    f"Low-res encoder non-norm param must have requires_grad=False "
                    f"when train_lowres_encoder=False"
                )

    # Also check lowres-related upsamples
    for path in _LOWRES_ENCODER_UPSAMPLES:
        module = _resolve_submodule(predictor, path)
        for submodule in module.modules():
            if _is_norm_layer(submodule):
                continue
            for param in submodule.parameters(recurse=False):
                if train_lowres_encoder:
                    assert param.requires_grad, (
                        f"Lowres upsample '{path}' non-norm param must have "
                        f"requires_grad=True when train_lowres_encoder=True (Req 17.3)"
                    )
                else:
                    assert not param.requires_grad, (
                        f"Lowres upsample '{path}' non-norm param must have "
                        f"requires_grad=False when train_lowres_encoder=False"
                    )

    # --- Req 17.4: DPT decoder non-norm params respect policy ---
    dpt_decoder_paths = _TRAINABLE_COMPONENT_MAP["train_dpt_decoder"]
    for path in dpt_decoder_paths:
        module = _resolve_submodule(predictor, path)
        for submodule in module.modules():
            if _is_norm_layer(submodule):
                continue
            for param in submodule.parameters(recurse=False):
                if train_dpt_decoder:
                    assert param.requires_grad, (
                        f"DPT decoder '{path}' non-norm param must have "
                        f"requires_grad=True when train_dpt_decoder=True (Req 17.4)"
                    )
                else:
                    assert not param.requires_grad, (
                        f"DPT decoder '{path}' non-norm param must have "
                        f"requires_grad=False when train_dpt_decoder=False"
                    )

    # --- Req 17.5: Alignment / gaussian decoder / composer non-norm params ---
    alignment_paths = _TRAINABLE_COMPONENT_MAP["train_alignment"]
    for path in alignment_paths:
        module = _resolve_submodule(predictor, path)
        for submodule in module.modules():
            if _is_norm_layer(submodule):
                continue
            for param in submodule.parameters(recurse=False):
                if train_alignment:
                    assert param.requires_grad, (
                        f"Alignment '{path}' non-norm param must have "
                        f"requires_grad=True when train_alignment=True (Req 17.5)"
                    )
                else:
                    assert not param.requires_grad, (
                        f"Alignment '{path}' non-norm param must have "
                        f"requires_grad=False when train_alignment=False"
                    )

    gaussian_decoder_paths = _TRAINABLE_COMPONENT_MAP["train_gaussian_decoder"]
    for path in gaussian_decoder_paths:
        module = _resolve_submodule(predictor, path)
        for submodule in module.modules():
            if _is_norm_layer(submodule):
                continue
            for param in submodule.parameters(recurse=False):
                if train_gaussian_decoder:
                    assert param.requires_grad, (
                        f"Gaussian decoder '{path}' non-norm param must have "
                        f"requires_grad=True when train_gaussian_decoder=True (Req 17.5)"
                    )
                else:
                    assert not param.requires_grad, (
                        f"Gaussian decoder '{path}' non-norm param must have "
                        f"requires_grad=False when train_gaussian_decoder=False"
                    )

    composer_paths = _TRAINABLE_COMPONENT_MAP["train_composer"]
    for path in composer_paths:
        module = _resolve_submodule(predictor, path)
        for submodule in module.modules():
            if _is_norm_layer(submodule):
                continue
            for param in submodule.parameters(recurse=False):
                if train_composer:
                    assert param.requires_grad, (
                        f"Composer '{path}' non-norm param must have "
                        f"requires_grad=True when train_composer=True (Req 17.5)"
                    )
                else:
                    assert not param.requires_grad, (
                        f"Composer '{path}' non-norm param must have "
                        f"requires_grad=False when train_composer=False"
                    )

    # --- Req 17.6: Optimizer parameter set matches exactly requires_grad=True ---
    trainable_params = list(controller.trainable_parameters(predictor))
    trainable_param_ids = {id(p) for p in trainable_params}

    # Collect all requires_grad=True parameters from the predictor
    expected_trainable_ids = {
        id(p) for p in predictor.parameters() if p.requires_grad
    }

    assert trainable_param_ids == expected_trainable_ids, (
        f"Optimizer parameter set must exactly match requires_grad=True parameters. "
        f"Extra in optimizer: {trainable_param_ids - expected_trainable_ids}, "
        f"Missing from optimizer: {expected_trainable_ids - trainable_param_ids}"
    )

    # Additionally verify that NO frozen parameter appears in the trainable set
    frozen_param_ids = {
        id(p) for p in predictor.parameters() if not p.requires_grad
    }
    assert trainable_param_ids.isdisjoint(frozen_param_ids), (
        "Optimizer must NOT include any frozen (requires_grad=False) parameters"
    )
