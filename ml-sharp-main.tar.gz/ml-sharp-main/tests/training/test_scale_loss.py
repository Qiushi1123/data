# Feature: sharp-training-framework, Property 16
"""Property test for scale loss (Property 16).

**Validates: Requirements 14.1, 14.5**

Property 16: Scale loss is mean absolute deviation of S from 1 over valid entries.

For any Scale_Map S, the scale loss equals the mean of |S(p) - 1| over finite
entries (excluding non-finite entries), is non-negative, and equals 0.0 when S
is 1 everywhere.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.scale import ScaleLoss
from sharp.training.types import LossContext


# --- Hypothesis strategies ---


@st.composite
def scale_map_with_finite_entries(draw):
    """Generate a random scale map [B, H, W] with all-finite values."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=1, max_value=8))
    width = draw(st.integers(min_value=1, max_value=8))

    num_elements = batch * height * width
    vals = draw(
        st.lists(
            st.floats(min_value=-10.0, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=num_elements,
            max_size=num_elements,
        )
    )
    tensor = torch.tensor(vals, dtype=torch.float32).reshape(batch, height, width)
    return tensor, batch, height, width


@st.composite
def scale_map_with_non_finite_entries(draw):
    """Generate a scale map [B, H, W] with some non-finite entries mixed in."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))

    num_elements = batch * height * width
    vals = draw(
        st.lists(
            st.floats(min_value=-10.0, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=num_elements,
            max_size=num_elements,
        )
    )
    tensor = torch.tensor(vals, dtype=torch.float32).reshape(batch, height, width)

    # Inject some non-finite entries (NaN and Inf)
    num_non_finite = draw(st.integers(min_value=1, max_value=max(1, num_elements // 3)))
    non_finite_indices = draw(
        st.lists(
            st.integers(min_value=0, max_value=num_elements - 1),
            min_size=num_non_finite,
            max_size=num_non_finite,
            unique=True,
        )
    )
    flat = tensor.flatten()
    for idx in non_finite_indices:
        # Alternate between NaN and Inf
        if idx % 2 == 0:
            flat[idx] = float("nan")
        else:
            flat[idx] = float("inf")
    tensor = flat.reshape(batch, height, width)

    return tensor, batch, height, width, non_finite_indices


@st.composite
def all_ones_scale_map(draw):
    """Generate a scale map [B, H, W] where all values are exactly 1.0."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=1, max_value=8))
    width = draw(st.integers(min_value=1, max_value=8))

    tensor = torch.ones(batch, height, width, dtype=torch.float32)
    return tensor, batch, height, width


@st.composite
def all_non_finite_scale_map(draw):
    """Generate a scale map [B, H, W] where all values are non-finite."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=1, max_value=4))
    width = draw(st.integers(min_value=1, max_value=4))

    num_elements = batch * height * width
    vals = []
    for i in range(num_elements):
        if i % 3 == 0:
            vals.append(float("nan"))
        elif i % 3 == 1:
            vals.append(float("inf"))
        else:
            vals.append(float("-inf"))
    tensor = torch.tensor(vals, dtype=torch.float32).reshape(batch, height, width)
    return tensor, batch, height, width


def _make_loss_context(scale_map: torch.Tensor | None) -> LossContext:
    """Build a LossContext with the given scale_map tensor."""
    return LossContext(scale_map=scale_map)


# --- Property tests ---


class TestScaleLossProperty16:
    """Property 16: Scale loss is mean absolute deviation of S from 1 over valid entries."""

    @settings(max_examples=100)
    @given(data=scale_map_with_finite_entries())
    def test_scale_loss_equals_mean_abs_deviation_from_1(self, data):
        """For any all-finite Scale_Map S, scale loss equals mean(|S - 1|)."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        # Manual computation: mean(|S - 1|) over all (finite) entries
        expected = torch.abs(tensor - 1.0).mean().item()

        assert abs(record.value.item() - expected) < 1e-5, (
            f"Scale loss={record.value.item()}, expected mean|S-1|={expected}"
        )

    @settings(max_examples=100)
    @given(data=scale_map_with_finite_entries())
    def test_scale_loss_is_non_negative(self, data):
        """For any Scale_Map S, the scale loss is non-negative."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        assert record.value.item() >= 0.0, (
            f"Scale loss must be non-negative, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=scale_map_with_finite_entries())
    def test_scale_loss_is_finite_scalar(self, data):
        """For any all-finite Scale_Map S, scale loss is a finite rank-0 tensor."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        assert record.value.ndim == 0, (
            f"Scale loss must be rank-0, got ndim={record.value.ndim}"
        )
        assert record.finite is True, "Scale loss must be finite for finite inputs"
        assert torch.isfinite(record.value), (
            f"Scale loss must be finite, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=all_ones_scale_map())
    def test_scale_loss_is_zero_when_s_is_one_everywhere(self, data):
        """Scale loss equals 0.0 when S is 1 everywhere."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Scale loss should be 0.0 when S=1 everywhere, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=scale_map_with_non_finite_entries())
    def test_scale_loss_excludes_non_finite_entries(self, data):
        """Scale loss excludes non-finite entries and computes mean|S-1| over finite only."""
        tensor, B, H, W, non_finite_indices = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        # Manual computation: mean(|S - 1|) only over finite entries
        finite_mask = torch.isfinite(tensor)
        finite_entries = tensor[finite_mask]

        if finite_entries.numel() == 0:
            expected = 0.0
        else:
            expected = torch.abs(finite_entries - 1.0).mean().item()

        assert abs(record.value.item() - expected) < 1e-5, (
            f"Scale loss={record.value.item()}, expected (finite-only)={expected}"
        )

    @settings(max_examples=100)
    @given(data=all_non_finite_scale_map())
    def test_scale_loss_returns_zero_when_no_finite_entries(self, data):
        """Scale loss returns 0.0 when the scale map has no finite entries."""
        tensor, B, H, W = data

        ctx = _make_loss_context(tensor)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Scale loss should be 0.0 with no finite entries, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=scale_map_with_finite_entries())
    def test_scale_loss_none_scale_map_returns_zero(self, data):
        """When scale_map is None, scale loss returns 0.0 and marks inactive."""
        # Ignore the drawn data - we just use this to get varied hypothesis runs
        ctx = _make_loss_context(None)
        loss_fn = ScaleLoss(weight=0.1)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Scale loss should be 0.0 when scale_map is None, got {record.value.item()}"
        )
        assert record.active is False, (
            "Scale loss should be inactive when scale_map is None"
        )
