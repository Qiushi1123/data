# Feature: sharp-training-framework, Property 11
"""Property test for depth loss (Property 11).

**Validates: Requirements 9.1, 9.2, 9.3, 9.4**

Property 11: Depth loss is masked L1 on layer 0 only over valid disparity.

For any predicted and GT two-layer disparity maps, the depth loss equals the
mean L1 difference on layer 0 at pixels whose GT disparity is finite and > 0,
ignores layer 1, equals 0.0 when identical, and contributes 0.0 when no pixel
is valid.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.depth import DepthLoss
from sharp.training.types import LossContext


# --- Hypothesis strategies ---


@st.composite
def disparity_dims(draw):
    """Draw small disparity map dimensions [B, 2, H, W]."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))
    return batch, height, width


@st.composite
def valid_disparity_pair(draw):
    """Generate pred [B, 2, H, W] and GT [B, 1, H, W] with at least some valid GT pixels.

    GT values are finite and > 0 for all pixels (all valid).
    """
    B, H, W = draw(disparity_dims())

    # Predicted disparity: layer 0 and layer 1, arbitrary positive values
    pred_vals = draw(
        st.lists(
            st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=B * 2 * H * W,
            max_size=B * 2 * H * W,
        )
    )
    pred = torch.tensor(pred_vals, dtype=torch.float32).reshape(B, 2, H, W)

    # GT disparity: all finite and > 0 (all valid)
    gt_vals = draw(
        st.lists(
            st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=B * 1 * H * W,
            max_size=B * 1 * H * W,
        )
    )
    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(B, 1, H, W)

    return pred, gt, B, H, W


@st.composite
def mixed_validity_disparity_pair(draw):
    """Generate pred [B, 2, H, W] and GT [B, 1, H, W] with mixed valid/invalid GT pixels.

    Some GT pixels are invalid (zero, negative, inf, nan).
    """
    B, H, W = draw(disparity_dims())

    # Predicted disparity
    pred_vals = draw(
        st.lists(
            st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=B * 2 * H * W,
            max_size=B * 2 * H * W,
        )
    )
    pred = torch.tensor(pred_vals, dtype=torch.float32).reshape(B, 2, H, W)

    # GT disparity: mix of valid (finite > 0) and invalid (0, negative, inf, nan)
    num_pixels = B * H * W
    gt_vals = []
    validity_flags = []
    for _ in range(num_pixels):
        kind = draw(st.sampled_from(["valid", "zero", "negative", "inf", "nan"]))
        if kind == "valid":
            val = draw(st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False))
            gt_vals.append(val)
            validity_flags.append(True)
        elif kind == "zero":
            gt_vals.append(0.0)
            validity_flags.append(False)
        elif kind == "negative":
            val = draw(st.floats(min_value=-10.0, max_value=-0.01, allow_nan=False, allow_infinity=False))
            gt_vals.append(val)
            validity_flags.append(False)
        elif kind == "inf":
            gt_vals.append(float("inf"))
            validity_flags.append(False)
        else:  # nan
            gt_vals.append(float("nan"))
            validity_flags.append(False)

    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(B, 1, H, W)

    return pred, gt, validity_flags, B, H, W


@st.composite
def all_invalid_gt(draw):
    """Generate pred [B, 2, H, W] and GT [B, 1, H, W] with NO valid GT pixels."""
    B, H, W = draw(disparity_dims())

    pred_vals = draw(
        st.lists(
            st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False),
            min_size=B * 2 * H * W,
            max_size=B * 2 * H * W,
        )
    )
    pred = torch.tensor(pred_vals, dtype=torch.float32).reshape(B, 2, H, W)

    # GT: all zeros or NaN or negative (none valid)
    num_pixels = B * H * W
    gt_vals = []
    for _ in range(num_pixels):
        kind = draw(st.sampled_from(["zero", "negative", "nan", "inf"]))
        if kind == "zero":
            gt_vals.append(0.0)
        elif kind == "negative":
            gt_vals.append(-1.0)
        elif kind == "nan":
            gt_vals.append(float("nan"))
        else:
            gt_vals.append(float("inf"))

    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(B, 1, H, W)

    return pred, gt, B, H, W


def _make_depth_loss_context(
    disparity_pred: torch.Tensor,
    input_gt_disparity: torch.Tensor | None,
) -> LossContext:
    """Build a LossContext with only the fields relevant to DepthLoss."""
    return LossContext(
        disparity_pred=disparity_pred,
        input_gt_disparity=input_gt_disparity,
    )


# --- Property tests ---


class TestDepthLossProperty11:
    """Property 11: Depth loss is masked L1 on layer 0 only over valid disparity."""

    @settings(max_examples=100)
    @given(data=valid_disparity_pair())
    def test_loss_equals_mean_l1_on_layer0_over_valid_pixels(self, data):
        """Depth loss equals mean L1 on layer 0 where GT is finite and > 0."""
        pred, gt, B, H, W = data

        ctx = _make_depth_loss_context(disparity_pred=pred, input_gt_disparity=gt)
        loss_fn = DepthLoss(weight=0.2)
        record = loss_fn(ctx)

        # All GT pixels are valid (finite and > 0), so loss = mean |pred[:,0] - gt|
        pred_layer0 = pred[:, 0:1]
        expected = torch.abs(pred_layer0 - gt).mean()

        assert torch.allclose(record.value, expected, atol=1e-6), (
            f"depth loss={record.value.item()}, expected={expected.item()}"
        )

    @settings(max_examples=100)
    @given(data=valid_disparity_pair())
    def test_layer1_is_ignored(self, data):
        """Changing layer 1 does not affect the depth loss."""
        pred, gt, B, H, W = data

        # Compute loss with original layer 1
        ctx1 = _make_depth_loss_context(disparity_pred=pred.clone(), input_gt_disparity=gt)
        loss_fn = DepthLoss(weight=0.2)
        record1 = loss_fn(ctx1)

        # Modify layer 1 to completely different values
        pred_modified = pred.clone()
        pred_modified[:, 1] = pred_modified[:, 1] * 100.0 + 42.0

        ctx2 = _make_depth_loss_context(disparity_pred=pred_modified, input_gt_disparity=gt)
        record2 = loss_fn(ctx2)

        assert torch.allclose(record1.value, record2.value, atol=1e-7), (
            f"Layer 1 change affected loss: {record1.value.item()} vs {record2.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=valid_disparity_pair())
    def test_identical_pred_and_gt_gives_zero(self, data):
        """When predicted layer 0 == GT disparity, loss is 0.0."""
        pred, gt, B, H, W = data

        # Set predicted layer 0 to match GT exactly
        pred_match = pred.clone()
        pred_match[:, 0:1] = gt.clone()

        ctx = _make_depth_loss_context(disparity_pred=pred_match, input_gt_disparity=gt)
        loss_fn = DepthLoss(weight=0.2)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 for identical pred/GT but got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=all_invalid_gt())
    def test_no_valid_pixels_gives_zero(self, data):
        """When no GT pixel is valid (all zero/negative/inf/nan), loss is 0.0."""
        pred, gt, B, H, W = data

        ctx = _make_depth_loss_context(disparity_pred=pred, input_gt_disparity=gt)
        loss_fn = DepthLoss(weight=0.2)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 when no valid pixel, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=mixed_validity_disparity_pair())
    def test_only_valid_pixels_contribute(self, data):
        """Loss is computed only over pixels where GT is finite and > 0."""
        pred, gt, validity_flags, B, H, W = data

        ctx = _make_depth_loss_context(disparity_pred=pred, input_gt_disparity=gt)
        loss_fn = DepthLoss(weight=0.2)
        record = loss_fn(ctx)

        # Manually compute expected: L1 on layer 0 at valid pixels only
        pred_layer0 = pred[:, 0:1]  # [B, 1, H, W]
        valid_mask = torch.isfinite(gt) & (gt > 0.0)
        valid_count = valid_mask.sum().item()

        if valid_count == 0:
            expected = 0.0
        else:
            l1_diff = torch.abs(pred_layer0 - gt)
            expected = l1_diff[valid_mask].mean().item()

        assert abs(record.value.item() - expected) < 1e-5, (
            f"depth loss={record.value.item()}, expected={expected}"
        )

    @settings(max_examples=100)
    @given(data=disparity_dims())
    def test_absent_gt_gives_zero(self, data):
        """When GT disparity is None (absent), loss contributes 0.0."""
        B, H, W = data

        pred_vals = torch.rand(B, 2, H, W)
        ctx = _make_depth_loss_context(disparity_pred=pred_vals, input_gt_disparity=None)
        loss_fn = DepthLoss(weight=0.2)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 when GT absent, got {record.value.item()}"
        )
        assert record.active is False, "Should be inactive when GT is absent"
