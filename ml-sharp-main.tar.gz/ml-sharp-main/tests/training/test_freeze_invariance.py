# Feature: sharp-training-framework, Property 19
"""Property test for frozen-parameter invariance across a training step.

**Validates: Requirements 17.7**

Property 19: Frozen parameters do not change across a step.

For any training step, parameters with requires_grad=False have identical values
before and after the step (no modification from optimizer or backward).
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st
from torch import nn

from sharp.models.initializer import GaussianBaseValues, InitializerOutput
from sharp.models.predictor import RGBGaussianPredictor
from sharp.training.config import FreezePolicy, OptimConfig
from sharp.training.forward import TrainingForward
from sharp.training.freeze import FreezeController
from sharp.training.optim import OptimizerScheduler
from sharp.utils.gaussians import Gaussians3D


# ---------------------------------------------------------------------------
# Stub submodules — reuse the pattern from test_forward.py
# ---------------------------------------------------------------------------

_NUM_LAYERS = 2
_H = 4
_W = 4


class _StubMonodepthOutput:
    """Minimal monodepth output tuple."""

    def __init__(
        self,
        disparity: torch.Tensor,
        encoder_features: list,
        decoder_features: torch.Tensor,
        output_features: list,
        intermediate_features: list,
    ):
        self.disparity = disparity
        self.encoder_features = encoder_features
        self.decoder_features = decoder_features
        self.output_features = output_features
        self.intermediate_features = intermediate_features


class _StubPatchEncoder(nn.Module):
    """Represents the monodepth patch encoder (always frozen)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 4, kernel_size=1)
        self.bn = nn.BatchNorm2d(4)  # norm layer — also frozen

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.bn(self.conv(x))


class _StubImageEncoder(nn.Module):
    """Represents the lowres image encoder (trainable non-norm params)."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(3, 4)
        self.ln = nn.LayerNorm(4)  # norm layer — frozen

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        out = self.linear(x.permute(0, 2, 3, 1))
        out = self.ln(out)
        return out.permute(0, 3, 1, 2)


class _StubEncoder(nn.Module):
    """Combines patch encoder and image encoder, mimicking the real encoder structure."""

    def __init__(self) -> None:
        super().__init__()
        self.patch_encoder = _StubPatchEncoder()
        self.image_encoder = _StubImageEncoder()
        # Upsample layers (frozen alongside patch encoder)
        self.upsample_latent0 = nn.Conv2d(4, 4, 1)
        self.upsample_latent1 = nn.Conv2d(4, 4, 1)
        self.upsample0 = nn.Conv2d(4, 4, 1)
        self.upsample1 = nn.Conv2d(4, 4, 1)
        self.upsample2 = nn.Conv2d(4, 4, 1)
        # Lowres upsamples (trainable)
        self.upsample_lowres = nn.Conv2d(4, 4, 1)
        self.fuse_lowres = nn.Conv2d(4, 4, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.image_encoder(x)


class _StubDecoder(nn.Module):
    """Represents the DPT decoder (trainable non-norm params)."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 4, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)


class _StubHead(nn.Module):
    """Stub depth head."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(4, 2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        return self.linear(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)


class _StubMonodepthPredictor(nn.Module):
    """Mimics MonodepthPredictor with encoder/decoder/head submodules."""

    def __init__(self) -> None:
        super().__init__()
        self.encoder = _StubEncoder()
        self.decoder = _StubDecoder()
        self.head = _StubHead()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.encoder(x)
        dec = self.decoder(x)
        return self.head(dec)


class _StubMonodepthModel(nn.Module):
    """Tiny monodepth model matching the expected path structure."""

    def __init__(self) -> None:
        super().__init__()
        self.monodepth_predictor = _StubMonodepthPredictor()

    def forward(self, image: torch.Tensor):
        B, C, H, W = image.shape
        # Produce 2-layer disparity from the encoder
        feat = self.monodepth_predictor.encoder.image_encoder(image)
        disparity = feat[:, :_NUM_LAYERS].abs() + 0.1

        decoder_features = self.monodepth_predictor.decoder(image)
        output_features = [image[:, :1].expand(B, 4, H, W)]

        return _StubMonodepthOutput(
            disparity=disparity,
            encoder_features=[],
            decoder_features=decoder_features,
            output_features=output_features,
            intermediate_features=[],
        )

    def internal_resolution(self) -> int:
        return _H * 2


class _StubDepthAlignmentEstimator(nn.Module):
    """Stub scale-map estimator (trainable)."""

    def __init__(self) -> None:
        super().__init__()
        self.scale_bias = nn.Parameter(torch.zeros(1))

    def forward(
        self,
        monodepth_layer0: torch.Tensor,
        depth: torch.Tensor,
        decoder_features: torch.Tensor | None = None,
    ) -> torch.Tensor:
        return torch.ones_like(monodepth_layer0) + self.scale_bias * 0.01


class _StubInitModel(nn.Module):
    """Stub initializer (trainable)."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(3, 1, bias=True)

    def forward(self, image: torch.Tensor, depth: torch.Tensor) -> InitializerOutput:
        B, C, H, W = image.shape
        base_signal = self.linear(image.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)
        base_signal = base_signal.unsqueeze(2).expand(B, 1, _NUM_LAYERS, H, W)

        base_values = GaussianBaseValues(
            mean_x_ndc=torch.tanh(base_signal),
            mean_y_ndc=torch.tanh(base_signal * 0.5),
            mean_inverse_z_ndc=base_signal.abs() + 0.1,
            scales=torch.ones(B, 1, _NUM_LAYERS, H, W) * 0.01,
            quaternions=torch.zeros(B, 4, _NUM_LAYERS, H, W).scatter_(
                1, torch.zeros(B, 1, _NUM_LAYERS, H, W, dtype=torch.long), 1.0
            ),
            colors=torch.ones(B, 3, _NUM_LAYERS, H, W) * 0.5,
            opacities=torch.ones(B, 1, _NUM_LAYERS, H, W) * 0.5,
        )

        feature_input = torch.cat([image, depth[:, :1]], dim=1)
        global_scale = torch.ones(B, 1, 1, 1)

        return InitializerOutput(
            gaussian_base_values=base_values,
            feature_input=feature_input,
            global_scale=global_scale,
        )


class _StubFeatureModel(nn.Module):
    """Stub gaussian decoder (trainable)."""

    def __init__(self, in_channels: int = 4) -> None:
        super().__init__()
        self.conv = nn.Conv2d(in_channels, 14, kernel_size=1)

    def forward(
        self, feature_input: torch.Tensor, encodings: list | None = None
    ) -> torch.Tensor:
        return self.conv(feature_input)


class _StubPredictionHead(nn.Module):
    """Stub prediction head (trainable)."""

    def __init__(self) -> None:
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(14))

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return features + self.bias[None, :, None, None]


class _StubGaussianComposer(nn.Module):
    """Stub composer (trainable)."""

    def __init__(self) -> None:
        super().__init__()
        self.scale_factor = 1
        self.base_scale_on_predicted_mean = False
        self.mix_weight = nn.Parameter(torch.ones(1))

    def forward(
        self,
        delta: torch.Tensor,
        base_values: GaussianBaseValues,
        global_scale: torch.Tensor | None = None,
        flatten_output: bool = True,
    ) -> Gaussians3D:
        B = delta.shape[0]
        H_d, W_d = delta.shape[2], delta.shape[3]
        N_delta = H_d * W_d
        N_base = base_values.mean_x_ndc.reshape(B, -1).shape[1]

        delta_flat = delta.reshape(B, 14, N_delta)
        repeats = (N_base + N_delta - 1) // N_delta
        delta_expanded = delta_flat.repeat(1, 1, repeats)[:, :, :N_base]

        mean_x = base_values.mean_x_ndc.reshape(B, -1) + delta_expanded[:, 0] * 0.01
        mean_y = base_values.mean_y_ndc.reshape(B, -1) + delta_expanded[:, 1] * 0.01
        mean_z = base_values.mean_inverse_z_ndc.reshape(B, -1) + delta_expanded[:, 2] * 0.01
        mean_vectors = torch.stack([mean_x, mean_y, mean_z], dim=-1) * self.mix_weight

        base_scales_flat = base_values.scales.reshape(B, -1)
        delta_scales = delta_expanded[:, 3:6].permute(0, 2, 1)
        singular_values = (base_scales_flat.unsqueeze(-1) + delta_scales * 0.01).abs() + 1e-4

        base_quat = base_values.quaternions.reshape(B, 4, -1).permute(0, 2, 1)
        delta_quat = delta_expanded[:, 6:10].permute(0, 2, 1)
        quaternions = base_quat + delta_quat * 0.01
        quaternions = quaternions / (quaternions.norm(dim=-1, keepdim=True) + 1e-8)

        base_colors = base_values.colors.reshape(B, 3, -1).permute(0, 2, 1)
        delta_colors = delta_expanded[:, 10:13].permute(0, 2, 1)
        colors = torch.sigmoid(base_colors + delta_colors * 0.1)

        base_opacities = base_values.opacities.reshape(B, -1)
        delta_opacities = delta_expanded[:, 13]
        opacities = torch.sigmoid(base_opacities + delta_opacities * 0.1)

        return Gaussians3D(
            mean_vectors=mean_vectors,
            singular_values=singular_values,
            quaternions=quaternions,
            colors=colors,
            opacities=opacities,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_stub_predictor() -> RGBGaussianPredictor:
    """Build a tiny stub predictor whose submodule paths match the FreezeController."""
    monodepth_model = _StubMonodepthModel()
    scale_map_estimator = _StubDepthAlignmentEstimator()
    init_model = _StubInitModel()
    feature_model = _StubFeatureModel(in_channels=4)
    prediction_head = _StubPredictionHead()
    gaussian_composer = _StubGaussianComposer()

    predictor = RGBGaussianPredictor(
        init_model=init_model,
        monodepth_model=monodepth_model,
        feature_model=feature_model,
        prediction_head=prediction_head,
        gaussian_composer=gaussian_composer,
        scale_map_estimator=scale_map_estimator,
    )
    return predictor


def _snapshot_frozen_params(
    predictor: RGBGaussianPredictor,
) -> dict[str, torch.Tensor]:
    """Snapshot all parameters with requires_grad=False."""
    return {
        name: param.detach().clone()
        for name, param in predictor.named_parameters()
        if not param.requires_grad
    }


# ---------------------------------------------------------------------------
# Property test
# ---------------------------------------------------------------------------


@given(
    batch_size=st.integers(min_value=1, max_value=2),
    provide_depth=st.booleans(),
    lr=st.sampled_from([1e-3, 1e-4, 5e-4]),
)
@settings(max_examples=50, deadline=None)
def test_frozen_parameters_unchanged_across_step(
    batch_size: int,
    provide_depth: bool,
    lr: float,
) -> None:
    """Property 19: Frozen parameters do not change across a step.

    **Validates: Requirements 17.7**

    For any training step, parameters with requires_grad=False have identical
    values before and after the step (no modification from optimizer or backward).
    """
    # --- Setup: build predictor and apply freeze policy ---
    predictor = _build_stub_predictor()
    predictor.train()

    freeze_controller = FreezeController()
    policy = FreezePolicy()
    freeze_controller.apply(predictor, policy)

    # --- Setup: build optimizer over trainable params only ---
    trainable_params = list(freeze_controller.trainable_parameters(predictor))
    assert len(trainable_params) > 0, "Must have at least one trainable parameter"

    optim_config = OptimConfig(warmup_steps=10, peak_lr=lr, floor_lr=lr * 0.1)
    opt_scheduler = OptimizerScheduler(
        parameters=iter(trainable_params),
        config=optim_config,
        total_steps=100,
    )

    # --- Verify frozen params exist ---
    frozen_before = _snapshot_frozen_params(predictor)
    assert len(frozen_before) > 0, "Must have at least one frozen parameter"

    # --- Run a training step: forward + backward + optimizer step ---
    training_forward = TrainingForward(predictor)

    image = torch.randn(batch_size, 3, _H, _W)
    disparity_factor = torch.rand(batch_size) * 10 + 1.0

    depth: torch.Tensor | None = None
    if provide_depth:
        depth = torch.rand(batch_size, 1, _H, _W) * 5 + 0.1

    # Forward pass
    outputs = training_forward(image, disparity_factor, depth=depth)

    # Compute a simple loss from all outputs
    loss = (
        outputs.gaussians.mean_vectors.sum()
        + outputs.gaussians.singular_values.sum()
        + outputs.gaussians.colors.sum()
        + outputs.gaussians.opacities.sum()
        + outputs.aligned_depth.sum()
        + outputs.disparity_pred.sum()
        + outputs.base_xy_ndc.sum()
    )
    if outputs.scale_map is not None:
        loss = loss + outputs.scale_map.sum()

    # Backward
    opt_scheduler.zero_grad()
    loss.backward()

    # Optimizer step
    opt_scheduler.step()

    # --- Verify all frozen parameters are unchanged ---
    frozen_after = _snapshot_frozen_params(predictor)

    for name in frozen_before:
        assert name in frozen_after, (
            f"Frozen parameter '{name}' disappeared after the step"
        )
        assert torch.equal(frozen_before[name], frozen_after[name]), (
            f"Frozen parameter '{name}' changed during the training step. "
            f"Max diff: {(frozen_before[name] - frozen_after[name]).abs().max().item():.2e}"
        )

    # Also verify no frozen param accumulated a gradient
    for name, param in predictor.named_parameters():
        if not param.requires_grad:
            assert param.grad is None, (
                f"Frozen parameter '{name}' accumulated a gradient "
                f"(grad should be None). "
                f"Grad norm: {param.grad.norm().item():.2e}"
            )
