# Feature: sharp-training-framework, Property 24
"""Property test for Stage 1 sample completeness (Property 24).

**Validates: Requirements 20.1, 20.2, 20.3**

Property 24: Stage 1 samples are schema-complete and correctly sized.

Every TrainingSample yielded by Stage1_Pipeline has: input_image and novel_image
as [3, 1536, 1536] tensors, non-None cameras with all 4 matrices, non-None
input_depth, and a finite positive disparity_factor.
"""

from __future__ import annotations

from typing import Iterator

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.camera import ViewCameras
from sharp.training.pipeline import (
    RawSample,
    SampleSource,
    Stage1_Pipeline,
    TrainingSample,
)


# --- Stub SampleSource for testing ---


class StubSampleSource:
    """A stub SampleSource that yields a fixed number of RawSamples.

    Each sample has valid images at a random resolution, complete cameras,
    GT depth, and focal/width metadata for disparity_factor computation.
    """

    def __init__(
        self,
        num_samples: int,
        input_h: int,
        input_w: int,
        focal_length_px: float,
    ) -> None:
        self._num_samples = num_samples
        self._input_h = input_h
        self._input_w = input_w
        self._focal_length_px = focal_length_px

    def __iter__(self) -> Iterator[RawSample]:
        """Yield raw samples with valid data."""
        for i in range(self._num_samples):
            yield RawSample(
                sample_id=f"stub_sample_{i}",
                input_image=torch.rand(3, self._input_h, self._input_w),
                novel_image=torch.rand(3, self._input_h, self._input_w),
                cameras=ViewCameras(
                    k_src=torch.eye(3).unsqueeze(0) * self._focal_length_px,
                    e_src=torch.eye(4).unsqueeze(0),
                    k_tgt=torch.eye(3).unsqueeze(0) * self._focal_length_px,
                    e_tgt=torch.eye(4).unsqueeze(0),
                ),
                input_depth=torch.rand(1, self._input_h, self._input_w) + 0.1,
                focal_length_px=self._focal_length_px,
                image_width=self._input_w,
            )

    def __len__(self) -> int:
        return self._num_samples


# --- Hypothesis strategies ---


@st.composite
def raw_sample_params(draw):
    """Generate parameters for a valid StubSampleSource.

    Draws random image dimensions (small for speed) and focal length.
    """
    input_h = draw(st.integers(min_value=4, max_value=64))
    input_w = draw(st.integers(min_value=4, max_value=64))
    focal_length_px = draw(
        st.floats(min_value=100.0, max_value=5000.0, allow_nan=False, allow_infinity=False)
    )
    num_samples = draw(st.integers(min_value=1, max_value=3))
    return num_samples, input_h, input_w, focal_length_px


# --- Property tests ---


class TestStage1SampleCompleteness:
    """Property 24: Stage 1 samples are schema-complete and correctly sized."""

    @settings(max_examples=100)
    @given(params=raw_sample_params())
    def test_output_images_are_1536x1536(self, params):
        """Every yielded TrainingSample has input_image and novel_image of shape [3, 1536, 1536]."""
        num_samples, input_h, input_w, focal_length_px = params

        source = StubSampleSource(num_samples, input_h, input_w, focal_length_px)
        pipeline = Stage1_Pipeline(source, total_steps=num_samples, resolution=1536)

        for sample in pipeline:
            assert sample.input_image.shape == (3, 1536, 1536), (
                f"input_image shape {sample.input_image.shape} != (3, 1536, 1536)"
            )
            assert sample.novel_image.shape == (3, 1536, 1536), (
                f"novel_image shape {sample.novel_image.shape} != (3, 1536, 1536)"
            )

    @settings(max_examples=100)
    @given(params=raw_sample_params())
    def test_cameras_are_non_none_with_all_matrices(self, params):
        """Every yielded TrainingSample has non-None cameras with k_src, e_src, k_tgt, e_tgt."""
        num_samples, input_h, input_w, focal_length_px = params

        source = StubSampleSource(num_samples, input_h, input_w, focal_length_px)
        pipeline = Stage1_Pipeline(source, total_steps=num_samples, resolution=1536)

        for sample in pipeline:
            assert sample.cameras is not None, "cameras must not be None"
            assert sample.cameras.k_src is not None, "cameras.k_src must not be None"
            assert sample.cameras.e_src is not None, "cameras.e_src must not be None"
            assert sample.cameras.k_tgt is not None, "cameras.k_tgt must not be None"
            assert sample.cameras.e_tgt is not None, "cameras.e_tgt must not be None"

    @settings(max_examples=100)
    @given(params=raw_sample_params())
    def test_input_depth_is_non_none(self, params):
        """Every yielded TrainingSample has non-None input_depth."""
        num_samples, input_h, input_w, focal_length_px = params

        source = StubSampleSource(num_samples, input_h, input_w, focal_length_px)
        pipeline = Stage1_Pipeline(source, total_steps=num_samples, resolution=1536)

        for sample in pipeline:
            assert sample.input_depth is not None, "input_depth must not be None"

    @settings(max_examples=100)
    @given(params=raw_sample_params())
    def test_disparity_factor_is_finite_and_positive(self, params):
        """Every yielded TrainingSample has a finite positive disparity_factor."""
        num_samples, input_h, input_w, focal_length_px = params

        source = StubSampleSource(num_samples, input_h, input_w, focal_length_px)
        pipeline = Stage1_Pipeline(source, total_steps=num_samples, resolution=1536)

        for sample in pipeline:
            df = sample.disparity_factor
            assert torch.isfinite(df).all(), (
                f"disparity_factor must be finite, got {df}"
            )
            assert (df > 0).all(), (
                f"disparity_factor must be positive, got {df.item()}"
            )
