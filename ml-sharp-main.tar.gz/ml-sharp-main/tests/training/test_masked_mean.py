# Feature: sharp-training-framework, Property 6
"""Property test for masked normalization (Property 6).

**Validates: Requirements 4.4, 5.3, 5.5, 5.6, 6.2, 6.3, 8.2, 8.3**

Property 6: Masked normalization divides by contributing-pixel count.

For any per-pixel loss map and mask M, the masked reduction equals
sum(loss * M) / sum(M) when sum(M) > 0 and equals exactly 0.0 (with no
division) when sum(M) == 0; the result is always finite.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.masking import masked_mean


# --- Hypothesis strategies ---

@st.composite
def loss_and_mask(draw, allow_empty_mask: bool = True):
    """Generate a random per-pixel loss tensor and a binary mask."""
    batch = draw(st.integers(min_value=1, max_value=3))
    channels = draw(st.integers(min_value=1, max_value=3))
    height = draw(st.integers(min_value=1, max_value=8))
    width = draw(st.integers(min_value=1, max_value=8))

    # Per-pixel loss: non-negative floats
    loss_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
            min_size=batch * channels * height * width,
            max_size=batch * channels * height * width,
        )
    )
    loss_tensor = torch.tensor(loss_vals, dtype=torch.float32).reshape(batch, channels, height, width)

    # Binary mask: 0 or 1 values, broadcastable shape [B, 1, H, W]
    if allow_empty_mask:
        mask_vals = draw(
            st.lists(
                st.sampled_from([0.0, 1.0]),
                min_size=batch * 1 * height * width,
                max_size=batch * 1 * height * width,
            )
        )
    else:
        # Ensure at least one pixel is 1
        mask_vals = draw(
            st.lists(
                st.sampled_from([0.0, 1.0]),
                min_size=batch * 1 * height * width,
                max_size=batch * 1 * height * width,
            )
        )
        # Force at least one entry to 1
        if all(v == 0.0 for v in mask_vals):
            mask_vals[0] = 1.0

    mask_tensor = torch.tensor(mask_vals, dtype=torch.float32).reshape(batch, 1, height, width)

    return loss_tensor, mask_tensor


@st.composite
def loss_and_nonempty_mask(draw):
    """Generate a loss tensor and a mask with at least one contributing pixel."""
    return draw(loss_and_mask(allow_empty_mask=False))


@st.composite
def loss_and_empty_mask(draw):
    """Generate a loss tensor and a mask with all zeros."""
    batch = draw(st.integers(min_value=1, max_value=3))
    channels = draw(st.integers(min_value=1, max_value=3))
    height = draw(st.integers(min_value=1, max_value=8))
    width = draw(st.integers(min_value=1, max_value=8))

    loss_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=100.0, allow_nan=False, allow_infinity=False),
            min_size=batch * channels * height * width,
            max_size=batch * channels * height * width,
        )
    )
    loss_tensor = torch.tensor(loss_vals, dtype=torch.float32).reshape(batch, channels, height, width)

    # All-zero mask
    mask_tensor = torch.zeros(batch, 1, height, width, dtype=torch.float32)

    return loss_tensor, mask_tensor


@st.composite
def arbitrary_loss_and_mask(draw):
    """Generate a loss tensor (possibly negative) and a binary mask."""
    batch = draw(st.integers(min_value=1, max_value=3))
    channels = draw(st.integers(min_value=1, max_value=3))
    height = draw(st.integers(min_value=1, max_value=8))
    width = draw(st.integers(min_value=1, max_value=8))

    loss_vals = draw(
        st.lists(
            st.floats(min_value=-100.0, max_value=100.0, allow_nan=False, allow_infinity=False),
            min_size=batch * channels * height * width,
            max_size=batch * channels * height * width,
        )
    )
    loss_tensor = torch.tensor(loss_vals, dtype=torch.float32).reshape(batch, channels, height, width)

    mask_vals = draw(
        st.lists(
            st.sampled_from([0.0, 1.0]),
            min_size=batch * 1 * height * width,
            max_size=batch * 1 * height * width,
        )
    )
    mask_tensor = torch.tensor(mask_vals, dtype=torch.float32).reshape(batch, 1, height, width)

    return loss_tensor, mask_tensor


# --- Property tests ---


class TestMaskedMeanProperty6:
    """Property 6: Masked normalization divides by contributing-pixel count."""

    @settings(max_examples=100)
    @given(data=loss_and_nonempty_mask())
    def test_nonempty_mask_equals_sum_over_count(self, data):
        """When sum(M) > 0, masked_mean equals sum(loss * M) / sum(M)."""
        loss_tensor, mask_tensor = data

        result = masked_mean(loss_tensor, mask_tensor)

        # Reference computation
        expected = (loss_tensor * mask_tensor).sum() / mask_tensor.sum()

        assert torch.allclose(result, expected, atol=1e-6), (
            f"masked_mean={result.item()}, expected={expected.item()}"
        )

    @settings(max_examples=100)
    @given(data=loss_and_empty_mask())
    def test_empty_mask_returns_zero(self, data):
        """When sum(M) == 0, masked_mean equals exactly 0.0."""
        loss_tensor, mask_tensor = data

        result = masked_mean(loss_tensor, mask_tensor)

        assert result.item() == 0.0, f"Expected 0.0 but got {result.item()}"

    @settings(max_examples=100)
    @given(data=arbitrary_loss_and_mask())
    def test_result_always_finite(self, data):
        """The result is always a finite scalar regardless of mask content."""
        loss_tensor, mask_tensor = data

        result = masked_mean(loss_tensor, mask_tensor)

        assert torch.isfinite(result).item(), f"Result is not finite: {result.item()}"
        assert result.dim() == 0, f"Result is not scalar, dim={result.dim()}"

    @settings(max_examples=100)
    @given(data=loss_and_nonempty_mask())
    def test_nonneg_loss_gives_nonneg_result(self, data):
        """When per_pixel_loss is non-negative, the result is non-negative."""
        loss_tensor, mask_tensor = data
        # loss_and_nonempty_mask already generates non-negative loss values

        result = masked_mean(loss_tensor, mask_tensor)

        assert result.item() >= 0.0, f"Expected non-negative result but got {result.item()}"
