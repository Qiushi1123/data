# Feature: sharp-training-framework, Property 17
"""Property test for loss aggregation (Property 17).

**Validates: Requirements 6.5, 7.3, 8.4, 9.5, 10.3, 11.5, 12.3, 13.5, 15.2, 16.1, 16.2, 16.3, 16.5**

Property 17: Loss aggregation is the weighted sum over active, finite terms
with faithful records.

For any collection of loss terms with weights, active flags, and (possibly
non-finite) values, the aggregated total equals Σ λ_k · L_k over exactly the
active terms whose values are finite; non-finite active terms are excluded from
the total; inactive terms are excluded silently; the total is a rank-0 tensor
connected to every included term; and for each active term the records report
both the unweighted value and the weighted value λ_k · L_k.
"""

from __future__ import annotations

import warnings

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.aggregator import LossAggregator
from sharp.training.types import AggregateResult, LossContext, LossRecord


# --- Stub loss module ---


class StubLossModule:
    """A controllable stub loss module for testing the aggregator."""

    def __init__(self, name: str, weight: float, value: torch.Tensor) -> None:
        self.name = name
        self.weight = weight
        self._value = value

    def __call__(self, ctx: LossContext) -> LossRecord:
        return LossRecord(
            name=self.name,
            value=self._value,
            weight=self.weight,
            active=True,
            finite=torch.isfinite(self._value).item(),
        )


class InactiveStubLossModule:
    """A stub module that reports unavailable supervision."""

    def __init__(self, name: str, weight: float, value: torch.Tensor) -> None:
        self.name = name
        self.weight = weight
        self._value = value

    def __call__(self, ctx: LossContext) -> LossRecord:
        return LossRecord(
            name=self.name,
            value=self._value,
            weight=self.weight,
            active=False,
            finite=True,
            diagnostics={"reason": "unavailable"},
        )


# --- Hypothesis strategies ---


@st.composite
def finite_loss_term(draw):
    """Generate a single finite loss term with a random weight and value."""
    name = draw(st.text(alphabet="abcdefghijklmnop", min_size=3, max_size=8))
    weight = draw(st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False))
    # Use requires_grad=True so we can verify graph connectivity
    val = draw(st.floats(min_value=-50.0, max_value=50.0, allow_nan=False, allow_infinity=False))
    value = torch.tensor(val, dtype=torch.float32, requires_grad=True)
    return name, weight, value


@st.composite
def nonfinite_value(draw):
    """Generate a non-finite tensor value (NaN or Inf)."""
    choice = draw(st.sampled_from(["nan", "inf", "-inf"]))
    if choice == "nan":
        return torch.tensor(float("nan"), dtype=torch.float32)
    elif choice == "inf":
        return torch.tensor(float("inf"), dtype=torch.float32)
    else:
        return torch.tensor(float("-inf"), dtype=torch.float32)


@st.composite
def loss_term_collection(draw):
    """Generate a collection of loss terms: some active-finite, some active-nonfinite, some inactive.

    Returns (modules, active_names, expected_finite_active, expected_nonfinite_active_names).
    """
    # Number of terms in each category
    n_active_finite = draw(st.integers(min_value=0, max_value=5))
    n_active_nonfinite = draw(st.integers(min_value=0, max_value=3))
    n_inactive = draw(st.integers(min_value=0, max_value=3))

    modules = []
    active_names = set()
    expected_finite_active = []  # (name, weight, value_tensor)
    expected_nonfinite_names = []

    used_names = set()

    # Active finite terms
    for i in range(n_active_finite):
        name = f"fin_{i}"
        used_names.add(name)
        weight = draw(st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False))
        val = draw(st.floats(min_value=-50.0, max_value=50.0, allow_nan=False, allow_infinity=False))
        value = torch.tensor(val, dtype=torch.float32, requires_grad=True)
        modules.append(StubLossModule(name, weight, value))
        active_names.add(name)
        expected_finite_active.append((name, weight, value))

    # Active non-finite terms
    for i in range(n_active_nonfinite):
        name = f"nonf_{i}"
        used_names.add(name)
        weight = draw(st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False))
        value = draw(nonfinite_value())
        modules.append(StubLossModule(name, weight, value))
        active_names.add(name)
        expected_nonfinite_names.append(name)

    # Inactive terms (not in active_names)
    for i in range(n_inactive):
        name = f"inact_{i}"
        used_names.add(name)
        weight = draw(st.floats(min_value=0.01, max_value=10.0, allow_nan=False, allow_infinity=False))
        val = draw(st.floats(min_value=-50.0, max_value=50.0, allow_nan=False, allow_infinity=False))
        value = torch.tensor(val, dtype=torch.float32, requires_grad=True)
        modules.append(StubLossModule(name, weight, value))
        # NOT added to active_names

    return modules, active_names, expected_finite_active, expected_nonfinite_names


# --- Property tests ---


class TestLossAggregationProperty17:
    """Property 17: Loss aggregation is the weighted sum over active, finite terms."""

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_total_equals_weighted_sum_of_active_finite(self, data):
        """The aggregated total equals Σ λ_k · L_k over active finite terms."""
        modules, active_names, expected_finite_active, _ = data

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        # Compute expected total
        if expected_finite_active:
            expected_total = sum(w * v for _, w, v in expected_finite_active)
            assert torch.allclose(result.total, expected_total, atol=1e-5), (
                f"total={result.total.item()}, expected={expected_total.item()}"
            )
        else:
            # No active finite terms → total should be 0.0
            assert result.total.item() == 0.0, (
                f"Expected 0.0 when no active finite terms, got {result.total.item()}"
            )

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_nonfinite_active_excluded_from_total(self, data):
        """Non-finite active terms are excluded from total and reported in skipped."""
        modules, active_names, expected_finite_active, expected_nonfinite_names = data
        assume(len(expected_nonfinite_names) > 0)

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        # Non-finite terms should appear in skipped
        for name in expected_nonfinite_names:
            assert name in result.skipped, (
                f"Non-finite term '{name}' not in skipped: {result.skipped}"
            )

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_inactive_terms_excluded_silently(self, data):
        """Inactive terms are excluded silently (not in records or skipped)."""
        modules, active_names, _, _ = data

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        # Inactive module names should not appear in records
        inactive_names = {m.name for m in modules} - active_names
        record_names = {r.name for r in result.records}
        for name in inactive_names:
            assert name not in record_names, (
                f"Inactive term '{name}' found in records"
            )
            # Also not in skipped (silently excluded)
            assert name not in result.skipped, (
                f"Inactive term '{name}' found in skipped"
            )

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_total_is_rank0_tensor(self, data):
        """The total is always a rank-0 tensor."""
        modules, active_names, _, _ = data

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        assert result.total.dim() == 0, (
            f"Expected rank-0 total, got dim={result.total.dim()}"
        )

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_total_connected_to_active_finite_terms(self, data):
        """The total is graph-connected to every active finite included term."""
        modules, active_names, expected_finite_active, _ = data
        assume(len(expected_finite_active) > 0)

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        # The total should have a grad_fn (connected to the graph)
        assert result.total.grad_fn is not None, (
            "Total has no grad_fn, not connected to autograd graph"
        )

        # Backward should produce gradients on each finite active value tensor
        result.total.backward()
        for name, weight, value in expected_finite_active:
            assert value.grad is not None, (
                f"No gradient on active finite term '{name}'"
            )
            assert torch.isfinite(value.grad).all(), (
                f"Non-finite gradient on term '{name}'"
            )

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_records_contain_correct_values_and_weights(self, data):
        """Records report both the unweighted value and the weight for each active term."""
        modules, active_names, expected_finite_active, expected_nonfinite_names = data

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        # All active terms (finite and nonfinite) should have records
        active_module_names = [m.name for m in modules if m.name in active_names]
        record_map = {r.name: r for r in result.records}

        for m in modules:
            if m.name in active_names:
                assert m.name in record_map, (
                    f"Active term '{m.name}' missing from records"
                )
                record = record_map[m.name]
                # Check unweighted value matches
                if torch.isfinite(m._value):
                    assert torch.allclose(record.value, m._value, atol=1e-6), (
                        f"Record value mismatch for '{m.name}': "
                        f"got {record.value.item()}, expected {m._value.item()}"
                    )
                # Check weight is recorded
                assert record.weight == m.weight, (
                    f"Record weight mismatch for '{m.name}': "
                    f"got {record.weight}, expected {m.weight}"
                )

    @settings(max_examples=100)
    @given(
        n_terms=st.integers(min_value=1, max_value=5),
        weights=st.lists(
            st.floats(min_value=0.1, max_value=5.0, allow_nan=False, allow_infinity=False),
            min_size=1, max_size=5,
        ),
    )
    def test_empty_active_set_returns_zero_with_warning(self, n_terms, weights):
        """Empty active set returns 0.0 with a warning."""
        # Create modules but none are in the active set
        modules = []
        for i in range(min(n_terms, len(weights))):
            val = torch.tensor(1.0, requires_grad=True)
            modules.append(StubLossModule(f"term_{i}", weights[i], val))

        active_names: set[str] = set()  # Empty - no terms active
        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = aggregator.aggregate(ctx)

        assert result.total.item() == 0.0, (
            f"Expected 0.0 for empty active set, got {result.total.item()}"
        )
        # Should have issued a warning
        assert len(w) > 0, "Expected a warning when no active terms contributed"

    def test_stage_active_but_record_inactive_terms_are_diagnostic_only(self):
        """Unavailable per-sample losses are recorded but excluded from total."""
        active_value = torch.tensor(2.0, device="cpu", requires_grad=True)
        inactive_cpu_zero = torch.tensor(0.0, device="cpu")
        modules = [
            StubLossModule("color", 3.0, active_value),
            InactiveStubLossModule("depth", 10.0, inactive_cpu_zero),
        ]
        aggregator = LossAggregator(
            modules=modules,
            active_names={"color", "depth"},
        )

        result = aggregator.aggregate(LossContext())

        assert torch.allclose(result.total, torch.tensor(6.0))
        assert [record.name for record in result.records] == ["color", "depth"]
        assert result.records[1].active is False
        result.total.backward()
        assert active_value.grad is not None

    @settings(max_examples=100)
    @given(data=loss_term_collection())
    def test_weighted_values_in_records(self, data):
        """For each active finite term, records enable computing λ_k · L_k."""
        modules, active_names, expected_finite_active, _ = data
        assume(len(expected_finite_active) > 0)

        ctx = LossContext()
        aggregator = LossAggregator(modules=modules, active_names=active_names)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = aggregator.aggregate(ctx)

        record_map = {r.name: r for r in result.records}

        for name, weight, value in expected_finite_active:
            record = record_map[name]
            # The weighted value can be computed from record.weight * record.value
            weighted = record.weight * record.value
            expected_weighted = weight * value
            assert torch.allclose(weighted, expected_weighted, atol=1e-5), (
                f"Weighted value mismatch for '{name}': "
                f"got {weighted.item()}, expected {expected_weighted.item()}"
            )
