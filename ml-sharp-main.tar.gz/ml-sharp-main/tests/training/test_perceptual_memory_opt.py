# Feature: sharp-training-framework, Property 27
"""Property test for perceptual memory optimization equivalence (Property 27).

**Validates: Requirements 23.1, 23.3, 23.4**

Property 27: Perceptual memory optimization matches standard autograd.

When memory_opt is enabled, the perceptual loss value and gradients through
the input are numerically equivalent (within tolerance) to the standard
autograd path.

- Loss value relative difference <= 1e-4
- Gradient max absolute difference <= 1e-4
- Gradient max relative difference <= 1e-3

Uses the stub feature extractor from test_perceptual_loss.py for speed.
"""

from __future__ import annotations

from typing import List

import torch
import torch.nn as nn
from hypothesis import given, settings, HealthCheck
from hypothesis import strategies as st

from sharp.training.losses.perceptual import PerceptualLoss
from sharp.training.types import LossContext, RenderTrainOutputs

# Import the stub extractor from the existing perceptual loss test
from tests.training.test_perceptual_loss import _StubFeatureExtractor


# --- Helpers ---


def _create_memory_opt_loss() -> PerceptualLoss:
    """Create a PerceptualLoss with memory_opt=True using the stub extractor."""
    loss_fn = PerceptualLoss.__new__(PerceptualLoss)
    loss_fn.name = "perceptual"
    loss_fn.weight = 3.0
    loss_fn.memory_opt = True
    loss_fn._cached_grads = None
    loss_fn._extractor = _StubFeatureExtractor(seed=42)
    loss_fn._extractor.eval()
    return loss_fn


def _create_standard_loss() -> PerceptualLoss:
    """Create a PerceptualLoss with memory_opt=False using the stub extractor."""
    loss_fn = PerceptualLoss.__new__(PerceptualLoss)
    loss_fn.name = "perceptual"
    loss_fn.weight = 3.0
    loss_fn.memory_opt = False
    loss_fn._cached_grads = None
    loss_fn._extractor = _StubFeatureExtractor(seed=42)
    loss_fn._extractor.eval()
    return loss_fn


def _make_context(
    novel_rendered: torch.Tensor,
    novel_gt: torch.Tensor,
    mask: torch.Tensor,
) -> LossContext:
    """Build a LossContext for the perceptual loss (novel view only)."""
    B, C, H, W = novel_rendered.shape
    novel_render = RenderTrainOutputs(
        color=novel_rendered,
        depth=torch.zeros(B, 1, H, W),
        alpha=torch.ones(B, 1, H, W),
        meta={},
    )
    return LossContext(
        novel_render=novel_render,
        novel_gt_image=novel_gt,
        mask=mask,
    )


# --- Hypothesis strategies ---


@st.composite
def image_pair_strategy(draw):
    """Generate a pair of random image tensors [B, 3, H, W] in [0, 1].

    Uses small spatial sizes to keep ResNet stub fast under Hypothesis.
    """
    batch = draw(st.integers(min_value=1, max_value=2))
    # Need at least 8x8 to support the stub extractor's pooling
    height = draw(st.integers(min_value=8, max_value=16))
    width = draw(st.integers(min_value=8, max_value=16))

    rendered_vals = draw(
        st.lists(
            st.floats(
                min_value=0.01, max_value=0.99,
                allow_nan=False, allow_infinity=False,
            ),
            min_size=batch * 3 * height * width,
            max_size=batch * 3 * height * width,
        )
    )
    gt_vals = draw(
        st.lists(
            st.floats(
                min_value=0.01, max_value=0.99,
                allow_nan=False, allow_infinity=False,
            ),
            min_size=batch * 3 * height * width,
            max_size=batch * 3 * height * width,
        )
    )

    rendered = torch.tensor(rendered_vals, dtype=torch.float32).reshape(
        batch, 3, height, width
    )
    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(
        batch, 3, height, width
    )

    return rendered, gt, batch, height, width


# --- Property tests ---


class TestPerceptualMemoryOptProperty27:
    """Property 27: Perceptual memory optimization matches standard autograd."""

    @settings(max_examples=10, suppress_health_check=[HealthCheck.data_too_large])
    @given(data=image_pair_strategy())
    def test_loss_value_equivalence(self, data):
        """Memory-opt loss value has relative difference <= 1e-4 vs standard."""
        rendered, gt, B, H, W = data
        mask = torch.ones(B, 1, H, W)

        # Standard path
        rendered_std = rendered.clone().requires_grad_(True)
        ctx_std = _make_context(rendered_std, gt.clone(), mask.clone())
        loss_std = _create_standard_loss()
        record_std = loss_std(ctx_std)

        # Memory-opt path
        rendered_opt = rendered.clone().requires_grad_(True)
        ctx_opt = _make_context(rendered_opt, gt.clone(), mask.clone())
        loss_opt = _create_memory_opt_loss()
        record_opt = loss_opt(ctx_opt)

        # Compare loss values (relative difference <= 1e-4)
        std_val = record_std.value.item()
        opt_val = record_opt.value.item()

        if abs(std_val) > 1e-8:
            rel_diff = abs(opt_val - std_val) / abs(std_val)
            assert rel_diff <= 1e-4, (
                f"Loss value relative difference {rel_diff:.6e} exceeds 1e-4. "
                f"Standard={std_val:.8f}, Memory-opt={opt_val:.8f}"
            )
        else:
            # Both should be near zero
            assert abs(opt_val - std_val) <= 1e-8, (
                f"Loss values differ near zero: std={std_val}, opt={opt_val}"
            )

    @settings(max_examples=10, suppress_health_check=[HealthCheck.data_too_large])
    @given(data=image_pair_strategy())
    def test_gradient_equivalence(self, data):
        """Memory-opt gradients match standard autograd within tolerance.

        Max absolute difference <= 1e-4 and max relative difference <= 1e-3.
        """
        rendered, gt, B, H, W = data
        mask = torch.ones(B, 1, H, W)

        # Standard path: compute loss and backprop
        rendered_std = rendered.clone().requires_grad_(True)
        ctx_std = _make_context(rendered_std, gt.clone(), mask.clone())
        loss_std = _create_standard_loss()
        record_std = loss_std(ctx_std)
        record_std.value.backward()
        grad_std = rendered_std.grad.clone()

        # Memory-opt path: compute loss and backprop
        rendered_opt = rendered.clone().requires_grad_(True)
        ctx_opt = _make_context(rendered_opt, gt.clone(), mask.clone())
        loss_opt = _create_memory_opt_loss()
        record_opt = loss_opt(ctx_opt)
        record_opt.value.backward()
        grad_opt = rendered_opt.grad.clone()

        # Max absolute difference <= 1e-4
        abs_diff = (grad_opt - grad_std).abs().max().item()
        assert abs_diff <= 1e-4, (
            f"Gradient max absolute difference {abs_diff:.6e} exceeds 1e-4"
        )

        # Max relative difference <= 1e-3 (where standard grad is non-negligible)
        nontrivial_mask = grad_std.abs() > 1e-6
        if nontrivial_mask.any():
            rel_diff = (
                (grad_opt[nontrivial_mask] - grad_std[nontrivial_mask]).abs()
                / grad_std[nontrivial_mask].abs()
            ).max().item()
            assert rel_diff <= 1e-3, (
                f"Gradient max relative difference {rel_diff:.6e} exceeds 1e-3"
            )

    @settings(max_examples=10, suppress_health_check=[HealthCheck.data_too_large])
    @given(data=image_pair_strategy())
    def test_both_paths_produce_finite_results(self, data):
        """Both paths produce finite loss values and gradients."""
        rendered, gt, B, H, W = data
        mask = torch.ones(B, 1, H, W)

        # Standard path
        rendered_std = rendered.clone().requires_grad_(True)
        ctx_std = _make_context(rendered_std, gt.clone(), mask.clone())
        loss_std = _create_standard_loss()
        record_std = loss_std(ctx_std)
        record_std.value.backward()

        assert record_std.finite, "Standard loss should be finite"
        assert torch.isfinite(rendered_std.grad).all(), (
            "Standard gradients should be all finite"
        )

        # Memory-opt path
        rendered_opt = rendered.clone().requires_grad_(True)
        ctx_opt = _make_context(rendered_opt, gt.clone(), mask.clone())
        loss_opt = _create_memory_opt_loss()
        record_opt = loss_opt(ctx_opt)
        record_opt.value.backward()

        assert record_opt.finite, "Memory-opt loss should be finite"
        assert torch.isfinite(rendered_opt.grad).all(), (
            "Memory-opt gradients should be all finite"
        )

    @settings(max_examples=10, suppress_health_check=[HealthCheck.data_too_large])
    @given(data=image_pair_strategy())
    def test_memory_opt_uses_graph_surgery(self, data):
        """Memory-opt path reports memory_opt=True in diagnostics."""
        rendered, gt, B, H, W = data
        mask = torch.ones(B, 1, H, W)

        rendered_opt = rendered.clone().requires_grad_(True)
        ctx_opt = _make_context(rendered_opt, gt.clone(), mask.clone())
        loss_opt = _create_memory_opt_loss()
        record_opt = loss_opt(ctx_opt)

        assert record_opt.diagnostics.get("memory_opt") is True, (
            "Memory-opt path should set diagnostics['memory_opt'] = True"
        )
