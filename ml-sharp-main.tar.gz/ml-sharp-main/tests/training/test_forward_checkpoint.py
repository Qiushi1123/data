"""Property test for gradient-checkpointing loss equivalence.

# Feature: sharp-training-framework, Property 3

Validates: Requirements 2.6

Property 3: Gradient checkpointing preserves the loss value.
For any valid input, the total loss computed with gradient checkpointing enabled
differs from the non-checkpointed total loss by at most an absolute tolerance of 1e-5.

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from hypothesis import given, settings
from hypothesis import strategies as st
from torch.utils.checkpoint import checkpoint

from sharp.utils.training import checkpoint_wrapper


# --- Stub model that supports gradient checkpointing toggle ---


class CheckpointBlock(nn.Module):
    """A small block that applies a sequence of linear+activation operations."""

    def __init__(self, dim: int) -> None:
        super().__init__()
        self.linear1 = nn.Linear(dim, dim)
        self.linear2 = nn.Linear(dim, dim)
        self.activation = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.activation(self.linear1(x))
        x = self.activation(self.linear2(x))
        return x


class StubCheckpointModel(nn.Module):
    """A minimal model that supports gradient checkpointing via checkpoint_wrapper.

    Mimics the pattern used in the SHARP codebase: a `grad_checkpointing` attribute
    controls whether `checkpoint_wrapper` applies `torch.utils.checkpoint.checkpoint`
    to each sub-block.
    """

    def __init__(self, dim: int = 16, num_blocks: int = 3) -> None:
        super().__init__()
        self.blocks = nn.ModuleList([CheckpointBlock(dim) for _ in range(num_blocks)])
        self.grad_checkpointing = False

    def set_grad_checkpointing(self, enabled: bool = True) -> None:
        """Toggle gradient checkpointing."""
        self.grad_checkpointing = enabled

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block in self.blocks:
            x = checkpoint_wrapper(self, block, x)
        return x


# --- Hypothesis strategies ---

# Generate batch size and sequence length for CPU-friendly small tensors
batch_strategy = st.integers(min_value=1, max_value=4)
seq_strategy = st.integers(min_value=2, max_value=16)
dim_strategy = st.integers(min_value=4, max_value=16)


@given(
    batch_size=batch_strategy,
    seq_len=seq_strategy,
    dim=dim_strategy,
    seed=st.integers(min_value=0, max_value=2**31 - 1),
)
@settings(max_examples=100, deadline=None)
def test_gradient_checkpointing_preserves_loss(
    batch_size: int, seq_len: int, dim: int, seed: int
) -> None:
    """Property 3: Gradient checkpointing preserves the loss value.

    **Validates: Requirements 2.6**

    For any valid input, the total loss computed with gradient checkpointing
    enabled differs from the non-checkpointed total loss by at most 1e-5.
    """
    # Use a fixed seed per example to create identical model weights
    gen = torch.Generator().manual_seed(seed)

    # Create the model with deterministic weights
    model = StubCheckpointModel(dim=dim, num_blocks=3)
    # Re-initialize with the generator for reproducibility within the example
    for param in model.parameters():
        nn.init.normal_(param, mean=0.0, std=0.1, generator=gen)

    # Create a deterministic input that requires grad (to test grad flow)
    input_gen = torch.Generator().manual_seed(seed + 1)
    x = torch.randn(batch_size, seq_len, dim, generator=input_gen, requires_grad=True)

    # --- Run WITHOUT gradient checkpointing ---
    model.set_grad_checkpointing(False)
    model.zero_grad()
    out_normal = model(x)
    loss_normal = out_normal.sum()

    # --- Run WITH gradient checkpointing ---
    # Need a fresh input clone to avoid graph contamination
    x_cp = x.detach().clone().requires_grad_(True)
    model.set_grad_checkpointing(True)
    model.zero_grad()
    out_checkpoint = model(x_cp)
    loss_checkpoint = out_checkpoint.sum()

    # --- Assert loss equivalence within tolerance ---
    assert torch.isfinite(loss_normal), "Normal loss is not finite"
    assert torch.isfinite(loss_checkpoint), "Checkpointed loss is not finite"
    assert torch.allclose(loss_normal, loss_checkpoint, atol=1e-5), (
        f"Checkpointed loss ({loss_checkpoint.item()}) differs from normal loss "
        f"({loss_normal.item()}) by more than 1e-5. "
        f"Difference: {abs(loss_normal.item() - loss_checkpoint.item())}"
    )

    # --- Also verify gradients are equivalent ---
    loss_normal.backward()
    grads_normal = [p.grad.clone() for p in model.parameters() if p.grad is not None]

    model.zero_grad()
    loss_checkpoint.backward()
    grads_checkpoint = [p.grad.clone() for p in model.parameters() if p.grad is not None]

    assert len(grads_normal) == len(grads_checkpoint), (
        "Different number of parameter gradients between normal and checkpointed paths"
    )

    for i, (g_normal, g_checkpoint) in enumerate(zip(grads_normal, grads_checkpoint)):
        assert torch.allclose(g_normal, g_checkpoint, atol=1e-5), (
            f"Gradient mismatch for parameter {i}: "
            f"max diff = {(g_normal - g_checkpoint).abs().max().item()}"
        )
