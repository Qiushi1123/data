# Feature: sharp-training-framework, Property 26
"""Property test for Stage 2 active-loss set (Property 26).

**Validates: Requirements 21.5**

Property 26: Stage 2 active-loss set supports frozen-teacher pseudo-depth terms.

The Stage 2 pipeline's active_losses set includes the image terms, geometry
regularizers, and weak teacher-pseudo-depth terms used by the paper-like SSFT
pass.

This is a structural property test — it verifies that regardless of the
pipeline's construction parameters (total_steps, resolution),
the active_losses set always satisfies the Stage 2 constraint.
"""

from __future__ import annotations

from typing import Iterator
from unittest.mock import MagicMock

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.aggregator import STAGE2_ACTIVE_LOSSES
from sharp.training.pipeline import (
    RawSample,
    SampleSource,
    Stage2_Pipeline,
)


# --- The expected Stage 2 active loss set for pseudo-depth-capable SSFT ---

EXPECTED_STAGE2_ACTIVE: set[str] = {
    "color",
    "perceptual",
    "alpha",
    "depth",
    "tv",
    "grad",
    "delta",
    "splat",
    "scale",
    "grad_scale",
}

# Teacher-pseudo-depth terms that Stage 2 can enable when pseudo depth exists.
PSEUDO_DEPTH_TERMS: set[str] = {"depth", "scale", "grad_scale"}


# --- Stub source and mocks for pipeline construction ---


class _MinimalSource:
    """Minimal SampleSource stub for constructing Stage2_Pipeline."""

    def __iter__(self) -> Iterator[RawSample]:
        yield RawSample(
            sample_id="dummy",
            input_image=torch.rand(3, 64, 64),
            novel_image=None,
            cameras=None,
            input_depth=None,
            focal_length_px=500.0,
            image_width=64,
        )

    def __len__(self) -> int:
        return 1


# --- Hypothesis strategies ---


@st.composite
def stage2_pipeline_params(draw):
    """Generate valid Stage2_Pipeline construction parameters.

    Varies total_steps and resolution to ensure the
    active_losses property holds regardless of configuration.
    """
    total_steps = draw(st.integers(min_value=1, max_value=200000))
    resolution = draw(st.sampled_from([256, 512, 768, 1024, 1536]))
    return total_steps, resolution


# --- Property tests ---


class TestStage2ActiveLossSet:
    """Property 26: Stage 2 active-loss set supports pseudo-depth terms."""

    @settings(max_examples=100)
    @given(params=stage2_pipeline_params())
    def test_active_losses_includes_pseudo_depth_terms(self, params):
        """The Stage 2 active_losses set includes teacher-pseudo-depth terms."""
        total_steps, resolution = params

        pipeline = Stage2_Pipeline(
            source=_MinimalSource(),
            pseudo_view_generator=MagicMock(),
            total_steps=total_steps,
            resolution=resolution,
        )

        active = pipeline.active_losses

        for depth_term in PSEUDO_DEPTH_TERMS:
            assert depth_term in active, (
                f"Pseudo-depth term '{depth_term}' missing from Stage 2 active_losses: "
                f"{active}"
            )

    @settings(max_examples=100)
    @given(params=stage2_pipeline_params())
    def test_active_losses_includes_all_expected_terms(self, params):
        """The Stage 2 active_losses set includes all configured SSFT terms."""
        total_steps, resolution = params

        pipeline = Stage2_Pipeline(
            source=_MinimalSource(),
            pseudo_view_generator=MagicMock(),
            total_steps=total_steps,
            resolution=resolution,
        )

        active = pipeline.active_losses

        for expected_term in EXPECTED_STAGE2_ACTIVE:
            assert expected_term in active, (
                f"Expected term '{expected_term}' missing from Stage 2 active_losses. "
                f"Got: {active}"
            )

    @settings(max_examples=100)
    @given(params=stage2_pipeline_params())
    def test_active_losses_equals_expected_set(self, params):
        """The Stage 2 active_losses set is exactly the expected set (no extra, no missing)."""
        total_steps, resolution = params

        pipeline = Stage2_Pipeline(
            source=_MinimalSource(),
            pseudo_view_generator=MagicMock(),
            total_steps=total_steps,
            resolution=resolution,
        )

        active = pipeline.active_losses

        assert active == EXPECTED_STAGE2_ACTIVE, (
            f"Stage 2 active_losses mismatch.\n"
            f"  Expected: {sorted(EXPECTED_STAGE2_ACTIVE)}\n"
            f"  Got:      {sorted(active)}\n"
            f"  Missing:  {sorted(EXPECTED_STAGE2_ACTIVE - active)}\n"
            f"  Extra:    {sorted(active - EXPECTED_STAGE2_ACTIVE)}"
        )

    def test_stage2_constant_includes_pseudo_depth_terms(self):
        """The module-level STAGE2_ACTIVE_LOSSES constant includes pseudo-depth terms."""
        for depth_term in PSEUDO_DEPTH_TERMS:
            assert depth_term in STAGE2_ACTIVE_LOSSES, (
                f"Pseudo-depth term '{depth_term}' must be in STAGE2_ACTIVE_LOSSES"
            )

    def test_stage2_constant_matches_expected(self):
        """The module-level STAGE2_ACTIVE_LOSSES constant equals the expected set."""
        assert STAGE2_ACTIVE_LOSSES == EXPECTED_STAGE2_ACTIVE, (
            f"STAGE2_ACTIVE_LOSSES mismatch.\n"
            f"  Expected: {sorted(EXPECTED_STAGE2_ACTIVE)}\n"
            f"  Got:      {sorted(STAGE2_ACTIVE_LOSSES)}\n"
            f"  Missing:  {sorted(EXPECTED_STAGE2_ACTIVE - STAGE2_ACTIVE_LOSSES)}\n"
            f"  Extra:    {sorted(STAGE2_ACTIVE_LOSSES - EXPECTED_STAGE2_ACTIVE)}"
        )
