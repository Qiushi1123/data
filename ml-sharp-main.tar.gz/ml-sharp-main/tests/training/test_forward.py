"""Property-based tests for the training forward pass autograd connectivity.

# Feature: sharp-training-framework, Property 1

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

from typing import NamedTuple

import torch
from hypothesis import given, settings
from hypothesis import strategies as st
from torch import nn

from sharp.models.initializer import GaussianBaseValues, InitializerOutput
from sharp.models.monodepth import MonodepthOutput
from sharp.models.predictor import DepthAlignment, RGBGaussianPredictor
from sharp.training.forward import TrainingForward, TrainingOutputs
from sharp.utils.gaussians import Gaussians3D


# ---------------------------------------------------------------------------
# Tiny stub submodules that mimic the real predictor pipeline on CPU with
# small tensors. Each produces autograd-connected outputs so the property
# test can verify gradient flow without loading real model weights.
# ---------------------------------------------------------------------------

_NUM_LAYERS = 2
_H = 4  # spatial height (tiny)
_W = 4  # spatial width (tiny)


class StubMonodepthOutput(NamedTuple):
    """Mimics MonodepthOutput with minimal fields."""

    disparity: torch.Tensor
    encoder_features: list[torch.Tensor]
    decoder_features: torch.Tensor
    output_features: list[torch.Tensor]
    intermediate_features: list[torch.Tensor]


class StubMonodepthModel(nn.Module):
    """Tiny monodepth model that returns a 2-layer disparity + features."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(3, _NUM_LAYERS, bias=True)

    def forward(self, image: torch.Tensor) -> StubMonodepthOutput:
        B, C, H, W = image.shape
        # Produce 2-layer disparity [B, 2, H, W] connected to self.linear
        feat = self.linear(image.permute(0, 2, 3, 1))  # [B, H, W, 2]
        disparity = feat.permute(0, 3, 1, 2).abs() + 0.1  # positive disparity

        decoder_features = image.mean(dim=1, keepdim=True).expand(B, 4, H, W)
        output_features = [image[:, :1].expand(B, 4, H, W)]
        return StubMonodepthOutput(
            disparity=disparity,
            encoder_features=[],
            decoder_features=decoder_features,
            output_features=output_features,
            intermediate_features=[],
        )

    def internal_resolution(self) -> int:
        return _H * 2


class StubDepthAlignmentEstimator(nn.Module):
    """Stub scale-map estimator: returns a trainable scale map near 1."""

    def __init__(self) -> None:
        super().__init__()
        self.scale_bias = nn.Parameter(torch.zeros(1))

    def forward(
        self,
        monodepth_layer0: torch.Tensor,
        depth: torch.Tensor,
        decoder_features: torch.Tensor | None = None,
    ) -> torch.Tensor:
        # Return a scale map near 1, connected to self.scale_bias
        return torch.ones_like(monodepth_layer0) + self.scale_bias * 0.01


class StubInitModel(nn.Module):
    """Stub initializer producing base Gaussian values from image + depth."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = nn.Linear(3, 1, bias=True)

    def forward(self, image: torch.Tensor, depth: torch.Tensor) -> InitializerOutput:
        B, C, H, W = image.shape
        # Produce shapes [B, 1, num_layers, H, W]
        base_signal = self.linear(image.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)
        # Expand to [B, 1, _NUM_LAYERS, H, W]
        base_signal = base_signal.unsqueeze(2).expand(B, 1, _NUM_LAYERS, H, W)

        mean_x_ndc = torch.tanh(base_signal)
        mean_y_ndc = torch.tanh(base_signal * 0.5)
        mean_inverse_z_ndc = base_signal.abs() + 0.1

        scales = torch.ones(B, 1, _NUM_LAYERS, H, W, device=image.device) * 0.01
        quaternions = torch.zeros(B, 4, _NUM_LAYERS, H, W, device=image.device)
        quaternions[:, 0] = 1.0  # identity quaternion
        colors = torch.ones(B, 3, _NUM_LAYERS, H, W, device=image.device) * 0.5
        opacities = torch.ones(B, 1, _NUM_LAYERS, H, W, device=image.device) * 0.5

        base_values = GaussianBaseValues(
            mean_x_ndc=mean_x_ndc,
            mean_y_ndc=mean_y_ndc,
            mean_inverse_z_ndc=mean_inverse_z_ndc,
            scales=scales,
            quaternions=quaternions,
            colors=colors,
            opacities=opacities,
        )

        # feature_input: [B, C_feat, H, W]
        feature_input = torch.cat([image, depth[:, :1]], dim=1)
        # global_scale: [B, 1, 1, 1]
        global_scale = torch.ones(B, 1, 1, 1, device=image.device)

        return InitializerOutput(
            gaussian_base_values=base_values,
            feature_input=feature_input,
            global_scale=global_scale,
        )


class StubFeatureModel(nn.Module):
    """Stub gaussian decoder: simple conv producing features."""

    def __init__(self, in_channels: int = 4) -> None:
        super().__init__()
        # Expects feature_input channels (image 3 + depth 1 = 4)
        self.conv = nn.Conv2d(in_channels, 14, kernel_size=1)

    def forward(
        self, feature_input: torch.Tensor, encodings: list[torch.Tensor] | None = None
    ) -> torch.Tensor:
        return self.conv(feature_input)


class StubPredictionHead(nn.Module):
    """Stub prediction head: identity-like pass-through."""

    def __init__(self) -> None:
        super().__init__()
        self.bias = nn.Parameter(torch.zeros(14))

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        # features: [B, 14, H, W]
        return features + self.bias[None, :, None, None]


class StubGaussianComposer(nn.Module):
    """Stub composer that produces Gaussians3D from delta + base values."""

    def __init__(self) -> None:
        super().__init__()
        self.scale_factor = 1
        self.base_scale_on_predicted_mean = False

    def forward(
        self,
        delta: torch.Tensor,
        base_values: GaussianBaseValues,
        global_scale: torch.Tensor | None = None,
        flatten_output: bool = True,
    ) -> Gaussians3D:
        B = delta.shape[0]
        # delta: [B, 14, H, W] — channels: xy(2), z(1), scale(3), quat(4), color(3), opacity(1)
        # base_values fields: [B, dim, num_layers, H, W]
        # N_base = num_layers * H * W (from base_values)
        # N_delta = H_delta * W_delta (from delta)
        # The real composer upsamples delta to match base; our stub repeats delta.
        H_d, W_d = delta.shape[2], delta.shape[3]
        N_delta = H_d * W_d
        N_base = base_values.mean_x_ndc.reshape(B, -1).shape[1]

        # Repeat delta spatially to match base_values count
        # delta_flat: [B, 14, N_delta] -> repeat to [B, 14, N_base]
        delta_flat = delta.reshape(B, 14, N_delta)
        repeats = (N_base + N_delta - 1) // N_delta  # ceil division
        delta_expanded = delta_flat.repeat(1, 1, repeats)[:, :, :N_base]  # [B, 14, N_base]

        # Compute mean vectors from base + delta offsets
        mean_x = base_values.mean_x_ndc.reshape(B, -1) + delta_expanded[:, 0] * 0.01
        mean_y = base_values.mean_y_ndc.reshape(B, -1) + delta_expanded[:, 1] * 0.01
        mean_z = base_values.mean_inverse_z_ndc.reshape(B, -1) + delta_expanded[:, 2] * 0.01
        mean_vectors = torch.stack([mean_x, mean_y, mean_z], dim=-1)  # [B, N_base, 3]

        # Scales from base + delta
        base_scales_flat = base_values.scales.reshape(B, -1)  # [B, N_base]
        delta_scales = delta_expanded[:, 3:6].permute(0, 2, 1)  # [B, N_base, 3]
        singular_values = (base_scales_flat.unsqueeze(-1) + delta_scales * 0.01).abs() + 1e-4

        # Quaternions
        base_quat = base_values.quaternions.reshape(B, 4, -1).permute(0, 2, 1)  # [B, N_base, 4]
        delta_quat = delta_expanded[:, 6:10].permute(0, 2, 1)  # [B, N_base, 4]
        quaternions = base_quat + delta_quat * 0.01
        quaternions = quaternions / (quaternions.norm(dim=-1, keepdim=True) + 1e-8)

        # Colors
        base_colors = base_values.colors.reshape(B, 3, -1).permute(0, 2, 1)  # [B, N_base, 3]
        delta_colors = delta_expanded[:, 10:13].permute(0, 2, 1)
        colors = torch.sigmoid(base_colors + delta_colors * 0.1)

        # Opacities
        base_opacities = base_values.opacities.reshape(B, -1)  # [B, N_base]
        delta_opacities = delta_expanded[:, 13]  # [B, N_base]
        opacities = torch.sigmoid(base_opacities + delta_opacities * 0.1)

        return Gaussians3D(
            mean_vectors=mean_vectors,
            singular_values=singular_values,
            quaternions=quaternions,
            colors=colors,
            opacities=opacities,
        )


def _build_stub_predictor() -> RGBGaussianPredictor:
    """Build a tiny stub predictor for CPU testing."""
    monodepth_model = StubMonodepthModel()
    scale_map_estimator = StubDepthAlignmentEstimator()
    init_model = StubInitModel()
    feature_model = StubFeatureModel(in_channels=4)  # image(3) + depth(1)
    prediction_head = StubPredictionHead()
    gaussian_composer = StubGaussianComposer()

    predictor = RGBGaussianPredictor(
        init_model=init_model,
        monodepth_model=monodepth_model,
        feature_model=feature_model,
        prediction_head=prediction_head,
        gaussian_composer=gaussian_composer,
        scale_map_estimator=scale_map_estimator,
    )
    return predictor


# ---------------------------------------------------------------------------
# Property test
# ---------------------------------------------------------------------------


@given(
    batch_size=st.integers(min_value=1, max_value=2),
    provide_depth=st.booleans(),
)
@settings(max_examples=100)
def test_training_forward_autograd_connectivity(
    batch_size: int,
    provide_depth: bool,
) -> None:
    """Property 1: Training forward produces autograd-connected Gaussians.

    **Validates: Requirements 2.1, 4.2, 6.6**

    For any valid input image and disparity_factor, running TrainingForward
    (without torch.no_grad) produces Gaussians3D and intermediate tensors that
    each have requires_grad == True and a non-null grad_fn connected to
    trainable parameters.
    """
    predictor = _build_stub_predictor()
    predictor.train()
    training_forward = TrainingForward(predictor)

    # Generate inputs
    image = torch.randn(batch_size, 3, _H, _W, requires_grad=False)
    disparity_factor = torch.rand(batch_size) * 10 + 1.0  # positive disparity factor

    depth: torch.Tensor | None = None
    if provide_depth:
        depth = torch.rand(batch_size, 1, _H, _W) * 5 + 0.1  # positive depth

    # Run training forward (no torch.no_grad!)
    outputs: TrainingOutputs = training_forward(image, disparity_factor, depth=depth)

    # --- Assert autograd connectivity on Gaussians3D fields ---
    gaussians = outputs.gaussians
    gaussian_fields = {
        "mean_vectors": gaussians.mean_vectors,
        "singular_values": gaussians.singular_values,
        "quaternions": gaussians.quaternions,
        "colors": gaussians.colors,
        "opacities": gaussians.opacities,
    }
    for name, tensor in gaussian_fields.items():
        assert tensor.requires_grad, (
            f"Gaussians3D.{name} must have requires_grad=True"
        )
        assert tensor.grad_fn is not None, (
            f"Gaussians3D.{name} must have a non-null grad_fn"
        )

    # --- Assert autograd connectivity on intermediate tensors ---
    assert outputs.aligned_depth.requires_grad, (
        "aligned_depth must have requires_grad=True"
    )
    assert outputs.aligned_depth.grad_fn is not None, (
        "aligned_depth must have a non-null grad_fn"
    )

    assert outputs.disparity_pred.requires_grad, (
        "disparity_pred must have requires_grad=True"
    )
    assert outputs.disparity_pred.grad_fn is not None, (
        "disparity_pred must have a non-null grad_fn"
    )

    assert outputs.base_xy_ndc.requires_grad, (
        "base_xy_ndc must have requires_grad=True"
    )
    assert outputs.base_xy_ndc.grad_fn is not None, (
        "base_xy_ndc must have a non-null grad_fn"
    )

    assert outputs.monodepth_disparity.requires_grad, (
        "monodepth_disparity must have requires_grad=True"
    )
    assert outputs.monodepth_disparity.grad_fn is not None, (
        "monodepth_disparity must have a non-null grad_fn"
    )

    # scale_map: if depth was provided, it should be connected; otherwise None
    if provide_depth:
        assert outputs.scale_map is not None, (
            "scale_map must be present when depth is provided"
        )
        assert outputs.scale_map.requires_grad, (
            "scale_map must have requires_grad=True when depth is provided"
        )
        assert outputs.scale_map.grad_fn is not None, (
            "scale_map must have a non-null grad_fn when depth is provided"
        )
    else:
        assert outputs.scale_map is None, (
            "scale_map must be None when depth is not provided"
        )

    # --- Verify gradient actually flows to trainable parameters ---
    # Sum all outputs and backward to verify connectivity
    total = (
        gaussians.mean_vectors.sum()
        + gaussians.singular_values.sum()
        + gaussians.quaternions.sum()
        + gaussians.colors.sum()
        + gaussians.opacities.sum()
        + outputs.aligned_depth.sum()
        + outputs.disparity_pred.sum()
        + outputs.base_xy_ndc.sum()
        + outputs.monodepth_disparity.sum()
    )
    if outputs.scale_map is not None:
        total = total + outputs.scale_map.sum()

    total.backward()

    # At least some trainable parameters must have received gradients
    has_grad = False
    for param in predictor.parameters():
        if param.requires_grad and param.grad is not None:
            has_grad = True
            break

    assert has_grad, (
        "At least one trainable parameter must receive a gradient from "
        "the TrainingForward outputs"
    )
