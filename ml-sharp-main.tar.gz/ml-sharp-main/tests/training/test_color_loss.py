# Feature: sharp-training-framework, Property 7
"""Property test for color loss (Property 7).

**Validates: Requirements 6.1**

Property 7: Color loss is mean per-pixel per-channel L1.

For any pair of equal-shape images, the input-view color loss equals the mean
absolute difference over all pixels and channels, and equals exactly 0.0 when
the two images are identical.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.color import ColorLoss
from sharp.training.types import LossContext, RenderTrainOutputs


# --- Hypothesis strategies ---


@st.composite
def image_dims(draw):
    """Draw small image dimensions [B, 3, H, W]."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))
    return batch, 3, height, width


@st.composite
def image_pair(draw):
    """Generate a pair of random image tensors [B, 3, H, W] with requires_grad."""
    B, C, H, W = draw(image_dims())

    rendered_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )
    gt_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )

    rendered = torch.tensor(rendered_vals, dtype=torch.float32).reshape(B, C, H, W)
    rendered.requires_grad_(True)
    gt = torch.tensor(gt_vals, dtype=torch.float32).reshape(B, C, H, W)

    return rendered, gt, B, C, H, W


@st.composite
def identical_image(draw):
    """Generate a single image tensor used as both rendered and GT."""
    B, C, H, W = draw(image_dims())

    vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=B * C * H * W,
            max_size=B * C * H * W,
        )
    )

    img = torch.tensor(vals, dtype=torch.float32).reshape(B, C, H, W)
    return img, B, C, H, W


def _make_loss_context(
    input_rendered: torch.Tensor,
    input_gt: torch.Tensor,
    novel_rendered: torch.Tensor,
    novel_gt: torch.Tensor,
    mask: torch.Tensor,
) -> LossContext:
    """Build a LossContext with the given tensors for ColorLoss."""
    input_render = RenderTrainOutputs(
        color=input_rendered,
        depth=torch.zeros(input_rendered.shape[0], 1, input_rendered.shape[2], input_rendered.shape[3]),
        alpha=torch.ones(input_rendered.shape[0], 1, input_rendered.shape[2], input_rendered.shape[3]),
        meta={},
    )
    novel_render = RenderTrainOutputs(
        color=novel_rendered,
        depth=torch.zeros(novel_rendered.shape[0], 1, novel_rendered.shape[2], novel_rendered.shape[3]),
        alpha=torch.ones(novel_rendered.shape[0], 1, novel_rendered.shape[2], novel_rendered.shape[3]),
        meta={},
    )
    return LossContext(
        input_render=input_render,
        novel_render=novel_render,
        input_gt_image=input_gt,
        novel_gt_image=novel_gt,
        mask=mask,
    )


# --- Property tests ---


class TestColorLossProperty7:
    """Property 7: Color loss is mean per-pixel per-channel L1."""

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_input_view_loss_equals_mean_l1(self, data):
        """For random rendered/GT images: input-view loss equals torch.abs(rendered - gt).mean()."""
        rendered, gt, B, C, H, W = data

        # Build a context with all-ones mask so novel loss is also L1 mean
        novel_rendered = torch.zeros(B, C, H, W, requires_grad=True)
        novel_gt = torch.zeros(B, C, H, W)
        mask = torch.ones(B, 1, H, W)

        ctx = _make_loss_context(rendered, gt, novel_rendered, novel_gt, mask)

        loss_fn = ColorLoss(weight=1.0)
        record = loss_fn(ctx)

        # The input_loss component is torch.abs(rendered - gt).mean()
        expected_input_loss = torch.abs(rendered - gt).mean()

        # novel_rendered == novel_gt == 0, so novel_loss = 0
        # total = input_loss + novel_loss = input_loss
        assert torch.allclose(record.value, expected_input_loss, atol=1e-6), (
            f"color loss={record.value.item()}, expected={expected_input_loss.item()}"
        )

    @settings(max_examples=100)
    @given(data=identical_image())
    def test_identical_images_give_zero_loss(self, data):
        """When rendered == gt: loss is 0.0."""
        img, B, C, H, W = data

        rendered = img.clone().requires_grad_(True)
        gt = img.clone()

        # Novel view also identical
        novel_rendered = img.clone().requires_grad_(True)
        novel_gt = img.clone()
        mask = torch.ones(B, 1, H, W)

        ctx = _make_loss_context(rendered, gt, novel_rendered, novel_gt, mask)

        loss_fn = ColorLoss(weight=1.0)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 for identical images but got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_novel_view_all_ones_mask_equals_mean_l1(self, data):
        """Novel-view loss with all-ones mask equals mean L1 over masked region."""
        rendered, gt, B, C, H, W = data

        # Use zeros for input so input_loss = 0
        input_rendered = torch.zeros(B, C, H, W, requires_grad=True)
        input_gt = torch.zeros(B, C, H, W)
        mask = torch.ones(B, 1, H, W)

        ctx = _make_loss_context(input_rendered, input_gt, rendered, gt, mask)

        loss_fn = ColorLoss(weight=1.0)
        record = loss_fn(ctx)

        # input_loss = 0 (input_rendered == input_gt == 0)
        # novel_loss = masked_mean(abs(rendered - gt), mask) with all-ones mask
        #            = abs(rendered - gt).mean() (since all pixels are selected)
        # But masked_mean divides by mask.sum() which counts B*1*H*W pixels,
        # while novel L1 has B*3*H*W elements. Let's compute the reference.
        novel_l1 = torch.abs(rendered - gt)
        # masked_mean: (novel_l1 * mask).sum() / mask.sum()
        expected_novel_loss = (novel_l1 * mask).sum() / mask.sum()

        assert torch.allclose(record.value, expected_novel_loss, atol=1e-6), (
            f"color loss={record.value.item()}, expected novel_loss={expected_novel_loss.item()}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_novel_view_all_zeros_mask_equals_zero(self, data):
        """Novel-view loss with all-zeros mask equals 0.0."""
        rendered, gt, B, C, H, W = data

        # Use zeros for input so input_loss = 0
        input_rendered = torch.zeros(B, C, H, W, requires_grad=True)
        input_gt = torch.zeros(B, C, H, W)
        mask = torch.zeros(B, 1, H, W)

        ctx = _make_loss_context(input_rendered, input_gt, rendered, gt, mask)

        loss_fn = ColorLoss(weight=1.0)
        record = loss_fn(ctx)

        # input_loss = 0, novel_loss = 0 (all-zeros mask)
        assert record.value.item() == 0.0, (
            f"Expected 0.0 with all-zeros mask but got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=image_pair())
    def test_result_has_autograd_graph(self, data):
        """Result has autograd graph (grad_fn not None)."""
        rendered, gt, B, C, H, W = data

        novel_rendered = torch.randn(B, C, H, W, requires_grad=True)
        novel_gt = torch.randn(B, C, H, W).abs()
        mask = torch.ones(B, 1, H, W)

        ctx = _make_loss_context(rendered, gt, novel_rendered, novel_gt, mask)

        loss_fn = ColorLoss(weight=1.0)
        record = loss_fn(ctx)

        assert record.value.grad_fn is not None, (
            "Color loss should have a non-null grad_fn (autograd graph attached)"
        )
