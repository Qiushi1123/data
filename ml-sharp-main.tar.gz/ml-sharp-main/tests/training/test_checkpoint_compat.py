"""Property test for saved-weight compatibility with create_predictor.

# Feature: sharp-training-framework, Property 22

**Validates: Requirements 19.3**

Property 22: Saved weights load into a fresh predictor without key or shape mismatch.
For any model produced by the framework, the saved model_state_dict loads into a
freshly constructed RGBGaussianPredictor (via create_predictor) through load_state_dict
with no missing keys, unexpected keys, or tensor-shape mismatches.

NOTE: This test uses stub predictors on CPU. The real predictor compatibility with
create_predictor(PredictorParams()) is verified in the CUDA-gated integration test
(task 16.1).

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import tempfile
import pathlib

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.checkpoint import CheckpointManager
from tests.training.test_forward import _build_stub_predictor


@given(
    step=st.integers(min_value=1, max_value=100000),
    checkpoint_interval=st.integers(min_value=1, max_value=1000),
)
@settings(max_examples=10, deadline=None)
def test_saved_weights_load_into_fresh_predictor(
    step: int,
    checkpoint_interval: int,
) -> None:
    """Property 22: Saved weights load into a fresh predictor without key or shape mismatch.

    **Validates: Requirements 19.3**

    For any model produced by the framework, the saved model_state_dict loads into a
    freshly constructed predictor through load_state_dict with no missing keys,
    unexpected keys, or tensor-shape mismatches.
    """
    # Build a stub predictor (simulates the training predictor)
    predictor = _build_stub_predictor()
    predictor.train()

    # Randomize weights so we're not just checking a zero-initialized model
    with torch.no_grad():
        for param in predictor.parameters():
            param.uniform_(-1.0, 1.0)

    # Create a dummy optimizer (required by CheckpointManager.save)
    optimizer = torch.optim.Adam(predictor.parameters(), lr=1e-4)

    # Save checkpoint using CheckpointManager
    with tempfile.TemporaryDirectory() as tmpdir:
        output_dir = pathlib.Path(tmpdir)
        manager = CheckpointManager(
            output_dir=output_dir,
            checkpoint_interval=checkpoint_interval,
        )

        saved_path = manager.save(
            predictor=predictor,
            optimizer=optimizer,
            scheduler_state=step,
            step=step,
        )

        # Load the checkpoint back
        checkpoint_data = manager.load(saved_path)
        model_state_dict = checkpoint_data["model_state_dict"]

        # Build a fresh stub predictor (simulates create_predictor(PredictorParams()))
        fresh_predictor = _build_stub_predictor()

        # Verify load_state_dict succeeds without missing or unexpected keys
        result = fresh_predictor.load_state_dict(model_state_dict, strict=True)

        # strict=True raises on mismatch, but also check the result explicitly
        assert len(result.missing_keys) == 0, (
            f"Missing keys when loading saved weights into fresh predictor: "
            f"{result.missing_keys}"
        )
        assert len(result.unexpected_keys) == 0, (
            f"Unexpected keys when loading saved weights into fresh predictor: "
            f"{result.unexpected_keys}"
        )

        # Verify all parameter shapes match by comparing state_dict keys and shapes
        saved_keys = set(model_state_dict.keys())
        fresh_keys = set(fresh_predictor.state_dict().keys())

        assert saved_keys == fresh_keys, (
            f"Key mismatch between saved and fresh predictor.\n"
            f"Only in saved: {saved_keys - fresh_keys}\n"
            f"Only in fresh: {fresh_keys - saved_keys}"
        )

        # Verify tensor shapes match for every key
        for key in saved_keys:
            saved_shape = model_state_dict[key].shape
            fresh_shape = fresh_predictor.state_dict()[key].shape
            assert saved_shape == fresh_shape, (
                f"Shape mismatch for key '{key}': "
                f"saved={saved_shape}, fresh={fresh_shape}"
            )

        # Verify the loaded weights are numerically identical to what was saved
        for key in saved_keys:
            assert torch.equal(
                fresh_predictor.state_dict()[key],
                model_state_dict[key],
            ), f"Weight mismatch after loading for key '{key}'"
