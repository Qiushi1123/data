# Feature: sharp-training-framework, Property 14
"""Property test for delta-offset penalty (Property 14).

**Validates: Requirements 12.1, 12.2**

Property 14: Delta-offset penalty thresholds at delta and is monotonic beyond it.

For any predicted xy offset, the delta-offset penalty is exactly 0.0 when the
offset magnitude is ≤ δ = 400.0 and increases monotonically with the amount by
which the magnitude exceeds δ.
"""

from __future__ import annotations

import math

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.losses.delta import DeltaLoss
from sharp.training.types import LossContext, LossRecord
from sharp.utils.gaussians import Gaussians3D


# --- Constants ---
DELTA = 400.0


# --- Helpers ---


def _make_gaussians_with_offsets(
    base_xy: torch.Tensor, offsets: torch.Tensor
) -> tuple[object, torch.Tensor]:
    """Create a Gaussians3D-like object with mean_vectors = base_xy + offsets.

    Args:
        base_xy: [B, N, 2] base xy positions.
        offsets: [B, N, 2] xy offsets from base.

    Returns:
        A Gaussians3D with mean_vectors [B, N, 3] (xy from base+offset, z=0)
        and the base_xy_ndc tensor.
    """
    B, N, _ = base_xy.shape
    # mean_vectors needs [B, N, 3]: xy = base + offset, z = 0
    mean_xy = base_xy + offsets
    mean_z = torch.zeros(B, N, 1)
    mean_vectors = torch.cat([mean_xy, mean_z], dim=-1)

    gaussians = Gaussians3D(
        mean_vectors=mean_vectors,
        singular_values=torch.ones(B, N, 3),
        quaternions=torch.zeros(B, N, 4),
        colors=torch.zeros(B, N, 3),
        opacities=torch.ones(B, N),
    )
    return gaussians, base_xy


def _make_loss_context(
    offset_magnitudes: torch.Tensor, B: int = 1
) -> LossContext:
    """Build a LossContext from a 1-D tensor of offset magnitudes.

    Each offset is placed along the x-axis so its L2 magnitude equals the
    given scalar magnitude.
    """
    N = offset_magnitudes.numel()
    base_xy = torch.zeros(B, N, 2)
    # Place offset along x-axis: offset = (mag, 0)
    offsets = torch.zeros(B, N, 2)
    offsets[:, :, 0] = offset_magnitudes.unsqueeze(0).expand(B, N)

    gaussians, base_xy_ndc = _make_gaussians_with_offsets(base_xy, offsets)

    return LossContext(gaussians=gaussians, base_xy_ndc=base_xy_ndc)


# --- Property tests ---


class TestDeltaLossProperty14:
    """Property 14: Delta-offset penalty thresholds at delta and is monotonic beyond it."""

    @settings(max_examples=100)
    @given(
        magnitude=st.floats(
            min_value=0.0, max_value=DELTA,
            allow_nan=False, allow_infinity=False,
        )
    )
    def test_zero_penalty_at_or_below_delta(self, magnitude: float):
        """Penalty is exactly 0.0 when offset magnitude ≤ δ = 400.0.

        **Validates: Requirements 12.2**
        """
        loss_fn = DeltaLoss(weight=1.0, delta=DELTA)
        mags = torch.tensor([magnitude])
        ctx = _make_loss_context(mags)

        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Expected 0.0 penalty for magnitude={magnitude} ≤ δ={DELTA}, "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(
        excess=st.floats(
            min_value=0.01, max_value=1000.0,
            allow_nan=False, allow_infinity=False,
        )
    )
    def test_positive_penalty_above_delta(self, excess: float):
        """Penalty is positive when offset magnitude exceeds δ.

        **Validates: Requirements 12.1**
        """
        magnitude = DELTA + excess
        loss_fn = DeltaLoss(weight=1.0, delta=DELTA)
        mags = torch.tensor([magnitude])
        ctx = _make_loss_context(mags)

        record = loss_fn(ctx)

        assert record.value.item() > 0.0, (
            f"Expected positive penalty for magnitude={magnitude} > δ={DELTA}, "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(
        excess_low=st.floats(
            min_value=0.01, max_value=500.0,
            allow_nan=False, allow_infinity=False,
        ),
        extra=st.floats(
            min_value=0.01, max_value=500.0,
            allow_nan=False, allow_infinity=False,
        ),
    )
    def test_monotonically_increasing_beyond_delta(self, excess_low: float, extra: float):
        """Penalty increases monotonically as magnitude exceeds δ by more.

        **Validates: Requirements 12.1**

        If mag_high > mag_low > δ, then penalty(mag_high) > penalty(mag_low).
        """
        mag_low = DELTA + excess_low
        mag_high = mag_low + extra

        loss_fn = DeltaLoss(weight=1.0, delta=DELTA)

        ctx_low = _make_loss_context(torch.tensor([mag_low]))
        ctx_high = _make_loss_context(torch.tensor([mag_high]))

        record_low = loss_fn(ctx_low)
        record_high = loss_fn(ctx_high)

        assert record_high.value.item() > record_low.value.item(), (
            f"Penalty should increase monotonically beyond δ: "
            f"penalty(mag={mag_high})={record_high.value.item()} should be > "
            f"penalty(mag={mag_low})={record_low.value.item()}"
        )

    @settings(max_examples=100)
    @given(
        magnitude=st.floats(
            min_value=0.0, max_value=2000.0,
            allow_nan=False, allow_infinity=False,
        )
    )
    def test_penalty_is_non_negative(self, magnitude: float):
        """Penalty is always non-negative for any offset magnitude.

        **Validates: Requirements 12.1, 12.2**
        """
        loss_fn = DeltaLoss(weight=1.0, delta=DELTA)
        mags = torch.tensor([magnitude])
        ctx = _make_loss_context(mags)

        record = loss_fn(ctx)

        assert record.value.item() >= 0.0, (
            f"Penalty should be non-negative, got {record.value.item()} "
            f"for magnitude={magnitude}"
        )

    @settings(max_examples=100)
    @given(
        angle=st.floats(
            min_value=0.0, max_value=2 * math.pi,
            allow_nan=False, allow_infinity=False,
        ),
        magnitude=st.floats(
            min_value=0.0, max_value=1000.0,
            allow_nan=False, allow_infinity=False,
        ),
    )
    def test_penalty_depends_on_magnitude_not_direction(self, angle: float, magnitude: float):
        """Penalty depends only on L2 magnitude, not direction of the offset.

        **Validates: Requirements 12.1, 12.2**

        Two offsets with the same magnitude but different directions should
        produce the same penalty.
        """
        loss_fn = DeltaLoss(weight=1.0, delta=DELTA)

        # Offset along x-axis
        B, N = 1, 1
        base_xy = torch.zeros(B, N, 2)

        # Offset at given angle
        offsets_angled = torch.zeros(B, N, 2)
        offsets_angled[0, 0, 0] = magnitude * math.cos(angle)
        offsets_angled[0, 0, 1] = magnitude * math.sin(angle)

        gaussians_angled, base_ndc = _make_gaussians_with_offsets(base_xy, offsets_angled)
        ctx_angled = LossContext(gaussians=gaussians_angled, base_xy_ndc=base_ndc)

        # Offset along x-axis only (same magnitude)
        offsets_x = torch.zeros(B, N, 2)
        offsets_x[0, 0, 0] = magnitude

        gaussians_x, base_ndc_x = _make_gaussians_with_offsets(base_xy, offsets_x)
        ctx_x = LossContext(gaussians=gaussians_x, base_xy_ndc=base_ndc_x)

        record_angled = loss_fn(ctx_angled)
        record_x = loss_fn(ctx_x)

        assert abs(record_angled.value.item() - record_x.value.item()) < 1e-3, (
            f"Penalty should depend only on magnitude, not direction. "
            f"angle={angle:.3f}, mag={magnitude}: "
            f"angled={record_angled.value.item()}, x-axis={record_x.value.item()}"
        )
