# Feature: sharp-training-framework, Property 9
"""Property test for frozen perceptual feature extractor (Property 9).

**Validates: Requirements 7.5**

Property 9: Perceptual feature extractor stays frozen.

For any training step, the ResNet-50 feature-extraction parameters have
requires_grad == False and their values are identical before and after the step.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st

from sharp.training.losses.perceptual import PerceptualLoss, _FeatureExtractor
from sharp.training.types import LossContext, RenderTrainOutputs


# --- Hypothesis strategies ---


@st.composite
def image_pair_with_mask(draw):
    """Generate a pair of novel-view images and a mask for perceptual loss computation.

    Uses small spatial dimensions to keep ResNet forward feasible on CPU.
    """
    batch = draw(st.integers(min_value=1, max_value=2))
    # Use spatial sizes that survive ResNet-50 downsampling (at least 32x32)
    height = draw(st.sampled_from([32, 64]))
    width = draw(st.sampled_from([32, 64]))

    # Generate rendered and GT images in [0, 1] range
    rendered = torch.rand(batch, 3, height, width, dtype=torch.float32, requires_grad=True)
    gt = torch.rand(batch, 3, height, width, dtype=torch.float32)
    mask = torch.ones(batch, 1, height, width, dtype=torch.float32)

    return rendered, gt, mask, batch, height, width


@st.composite
def training_step_config(draw):
    """Generate configurations for simulating a training step."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.sampled_from([32, 64]))
    width = draw(st.sampled_from([32, 64]))

    return batch, height, width


# --- Helper functions ---


def _snapshot_parameters(extractor: _FeatureExtractor) -> dict[str, torch.Tensor]:
    """Take a snapshot of all extractor parameters as detached clones."""
    return {
        name: param.detach().clone()
        for name, param in extractor.named_parameters()
    }


def _make_perceptual_loss_context(
    rendered: torch.Tensor, gt: torch.Tensor, mask: torch.Tensor
) -> LossContext:
    """Build a LossContext for the perceptual loss with novel-view data."""
    novel_render = RenderTrainOutputs(
        color=rendered,
        depth=torch.zeros(rendered.shape[0], 1, rendered.shape[2], rendered.shape[3]),
        alpha=torch.ones(rendered.shape[0], 1, rendered.shape[2], rendered.shape[3]),
        meta={},
    )
    return LossContext(
        novel_render=novel_render,
        novel_gt_image=gt,
        mask=mask,
    )


# --- Property tests ---


class TestPerceptualFrozenProperty9:
    """Property 9: Perceptual feature extractor stays frozen."""

    @settings(max_examples=10, deadline=None)
    @given(data=image_pair_with_mask())
    def test_all_extractor_params_have_requires_grad_false(self, data):
        """All ResNet-50 feature-extraction parameters have requires_grad == False."""
        rendered, gt, mask, B, H, W = data

        loss_fn = PerceptualLoss(weight=3.0)
        extractor = loss_fn.extractor

        # Check every parameter in the extractor
        for name, param in extractor.named_parameters():
            assert param.requires_grad is False, (
                f"Extractor parameter '{name}' has requires_grad=True, "
                f"expected False (frozen)"
            )

    @settings(max_examples=10, deadline=None)
    @given(data=image_pair_with_mask())
    def test_extractor_params_unchanged_after_forward(self, data):
        """Extractor parameter values are identical before and after a forward pass."""
        rendered, gt, mask, B, H, W = data

        loss_fn = PerceptualLoss(weight=3.0)
        extractor = loss_fn.extractor

        # Snapshot parameters before the forward pass
        params_before = _snapshot_parameters(extractor)

        # Compute perceptual loss (runs a forward through the extractor)
        ctx = _make_perceptual_loss_context(rendered, gt, mask)
        record = loss_fn(ctx)

        # Snapshot parameters after the forward pass
        params_after = _snapshot_parameters(extractor)

        # Verify all parameters are identical
        for name in params_before:
            assert torch.equal(params_before[name], params_after[name]), (
                f"Extractor parameter '{name}' changed during forward pass. "
                f"Max diff: {(params_before[name] - params_after[name]).abs().max().item()}"
            )

    @settings(max_examples=10, deadline=None)
    @given(config=training_step_config())
    def test_extractor_params_unchanged_after_backward(self, config):
        """Extractor parameter values are identical before and after a full
        forward + backward pass (simulating a training step)."""
        B, H, W = config

        loss_fn = PerceptualLoss(weight=3.0)
        extractor = loss_fn.extractor

        # Create inputs with gradients (simulating renderer output)
        rendered = torch.rand(B, 3, H, W, dtype=torch.float32, requires_grad=True)
        gt = torch.rand(B, 3, H, W, dtype=torch.float32)
        mask = torch.ones(B, 1, H, W, dtype=torch.float32)

        # Snapshot parameters before forward + backward
        params_before = _snapshot_parameters(extractor)

        # Forward pass through perceptual loss
        ctx = _make_perceptual_loss_context(rendered, gt, mask)
        record = loss_fn(ctx)

        # Backward pass (simulates the training step)
        if record.active and record.value.requires_grad:
            record.value.backward()

        # Snapshot parameters after backward
        params_after = _snapshot_parameters(extractor)

        # All parameters must be unchanged
        for name in params_before:
            assert torch.equal(params_before[name], params_after[name]), (
                f"Extractor parameter '{name}' changed after backward pass. "
                f"Max diff: {(params_before[name] - params_after[name]).abs().max().item()}"
            )

    @settings(max_examples=10, deadline=None)
    @given(config=training_step_config())
    def test_extractor_params_receive_no_gradient(self, config):
        """After backward, no extractor parameter accumulates a .grad tensor."""
        B, H, W = config

        loss_fn = PerceptualLoss(weight=3.0)
        extractor = loss_fn.extractor

        # Create inputs with gradients
        rendered = torch.rand(B, 3, H, W, dtype=torch.float32, requires_grad=True)
        gt = torch.rand(B, 3, H, W, dtype=torch.float32)
        mask = torch.ones(B, 1, H, W, dtype=torch.float32)

        # Forward + backward
        ctx = _make_perceptual_loss_context(rendered, gt, mask)
        record = loss_fn(ctx)

        if record.active and record.value.requires_grad:
            record.value.backward()

        # No extractor parameter should have accumulated gradients
        for name, param in extractor.named_parameters():
            assert param.grad is None, (
                f"Extractor parameter '{name}' accumulated a gradient "
                f"(should be None since requires_grad=False). "
                f"Grad norm: {param.grad.norm().item() if param.grad is not None else 'N/A'}"
            )

    @settings(max_examples=10, deadline=None)
    @given(config=training_step_config())
    def test_extractor_stays_frozen_after_optimizer_step(self, config):
        """Simulating a full training step with an optimizer does not modify
        extractor parameters (they are excluded from the optimizer)."""
        B, H, W = config

        loss_fn = PerceptualLoss(weight=3.0)
        extractor = loss_fn.extractor

        # Create a dummy "trainable" parameter (simulates model params)
        trainable_param = torch.nn.Parameter(torch.randn(3, 3))

        # Set up optimizer only over the trainable parameter (not the extractor)
        optimizer = torch.optim.Adam([trainable_param], lr=1e-3)

        # Create inputs
        rendered = torch.rand(B, 3, H, W, dtype=torch.float32, requires_grad=True)
        gt = torch.rand(B, 3, H, W, dtype=torch.float32)
        mask = torch.ones(B, 1, H, W, dtype=torch.float32)

        # Snapshot extractor state before the step
        params_before = _snapshot_parameters(extractor)

        # Forward pass
        ctx = _make_perceptual_loss_context(rendered, gt, mask)
        record = loss_fn(ctx)

        # Add a dummy loss from the trainable param to ensure backward runs
        total_loss = record.value + trainable_param.sum() * 0.001 if record.active else trainable_param.sum()

        # Backward + optimizer step
        optimizer.zero_grad()
        if total_loss.requires_grad:
            total_loss.backward()
        optimizer.step()

        # Extractor parameters must remain unchanged
        params_after = _snapshot_parameters(extractor)
        for name in params_before:
            assert torch.equal(params_before[name], params_after[name]), (
                f"Extractor parameter '{name}' changed after optimizer step. "
                f"Max diff: {(params_before[name] - params_after[name]).abs().max().item()}"
            )
