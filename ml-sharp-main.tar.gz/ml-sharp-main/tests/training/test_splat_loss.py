# Feature: sharp-training-framework, Property 15
"""Property test for splat regularizer (Property 15).

**Validates: Requirements 13.1, 13.2, 13.3, 13.4**

Property 15: Splat penalty bands the projected variance and averages over
visible splats.

For any set of screen-space projected variances, each per-splat penalty is 0
when the variance lies within [σ_min = 1e-1, σ_max = 1e2] and is a non-negative
value increasing monotonically with the distance past the nearest violated
bound; the loss is the arithmetic mean of per-splat penalties over visible
splats (depth > 1e-2) and is exactly 0.0 when no splat is visible.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.losses.splat import SplatLoss
from sharp.training.types import LossContext, RenderTrainOutputs


# --- Constants matching SplatLoss defaults ---
SIGMA_MIN = 1e-1
SIGMA_MAX = 1e2
DEPTH_THRESHOLD = 1e-2


# --- Hypothesis strategies ---


@st.composite
def symmetric_2x2_matrix(draw, min_eig: float = 0.0, max_eig: float = 200.0):
    """Generate a 2x2 symmetric positive semi-definite matrix with eigenvalues in range.

    Constructs the matrix as R^T @ diag(e1, e2) @ R where R is a rotation.
    """
    e1 = draw(st.floats(min_value=min_eig, max_value=max_eig,
                        allow_nan=False, allow_infinity=False))
    e2 = draw(st.floats(min_value=min_eig, max_value=max_eig,
                        allow_nan=False, allow_infinity=False))
    angle = draw(st.floats(min_value=0.0, max_value=3.14159,
                           allow_nan=False, allow_infinity=False))
    c, s = torch.cos(torch.tensor(angle)), torch.sin(torch.tensor(angle))
    R = torch.tensor([[c, -s], [s, c]], dtype=torch.float32)
    D = torch.diag(torch.tensor([e1, e2], dtype=torch.float32))
    return R.T @ D @ R


@st.composite
def covars2d_and_depths(draw, batch: int = 1, n_splats: int = 4):
    """Generate covars2d [B, N, 2, 2] and depths [B, N] for testing."""
    matrices = []
    depths_list = []
    for _b in range(batch):
        row_matrices = []
        row_depths = []
        for _n in range(n_splats):
            mat = draw(symmetric_2x2_matrix(min_eig=0.01, max_eig=200.0))
            row_matrices.append(mat)
            d = draw(st.floats(min_value=-0.1, max_value=10.0,
                               allow_nan=False, allow_infinity=False))
            row_depths.append(d)
        matrices.append(torch.stack(row_matrices))
        depths_list.append(torch.tensor(row_depths, dtype=torch.float32))

    covars2d = torch.stack([m for m in matrices])  # [B, N, 2, 2]
    depths = torch.stack(depths_list)  # [B, N]
    return covars2d, depths


def _make_splat_context(covars2d: torch.Tensor, depths: torch.Tensor) -> LossContext:
    """Build a LossContext with covars2d and depths in input_render meta."""
    B = covars2d.shape[0]
    H, W = 4, 4
    input_render = RenderTrainOutputs(
        color=torch.zeros(B, 3, H, W),
        depth=torch.ones(B, 1, H, W),
        alpha=torch.ones(B, 1, H, W),
        meta={"covars2d": covars2d, "depths": depths},
    )
    return LossContext(input_render=input_render)


# --- Property tests ---


class TestSplatLossProperty15:
    """Property 15: Splat penalty bands the projected variance and averages
    over visible splats."""

    @settings(max_examples=100)
    @given(data=st.data())
    def test_zero_penalty_when_variance_within_band(self, data):
        """Per-splat penalty is 0 when eigenvalues lie within [σ_min, σ_max].

        Validates Requirement 13.1.
        """
        B, N = 1, 4
        # Draw eigenvalues strictly within the band
        eigenvalues = []
        for _ in range(N):
            e1 = data.draw(st.floats(min_value=SIGMA_MIN, max_value=SIGMA_MAX,
                                     allow_nan=False, allow_infinity=False))
            e2 = data.draw(st.floats(min_value=SIGMA_MIN, max_value=SIGMA_MAX,
                                     allow_nan=False, allow_infinity=False))
            eigenvalues.append((e1, e2))

        # Build diagonal covariance matrices (eigenvalues = diagonal entries)
        covars2d = torch.zeros(B, N, 2, 2)
        for i, (e1, e2) in enumerate(eigenvalues):
            covars2d[0, i, 0, 0] = e1
            covars2d[0, i, 1, 1] = e2

        # All splats visible (depth > threshold)
        depths = torch.ones(B, N) * 1.0

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Loss should be 0 when all eigenvalues are within band, "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_nonnegative_penalty_outside_band(self, data):
        """Per-splat penalty is non-negative when variance is outside band.

        Validates Requirement 13.2.
        """
        B, N = 1, 1
        # Draw eigenvalue outside the band (either below or above)
        below = data.draw(st.booleans())
        if below:
            e = data.draw(st.floats(min_value=0.001, max_value=SIGMA_MIN - 1e-4,
                                    allow_nan=False, allow_infinity=False))
        else:
            e = data.draw(st.floats(min_value=SIGMA_MAX + 1e-2, max_value=500.0,
                                    allow_nan=False, allow_infinity=False))

        covars2d = torch.zeros(B, N, 2, 2)
        covars2d[0, 0, 0, 0] = e
        covars2d[0, 0, 1, 1] = 1.0  # second eigenvalue within band

        depths = torch.ones(B, N) * 1.0

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        assert record.value.item() >= 0.0, (
            f"Penalty should be non-negative, got {record.value.item()}"
        )
        assert record.value.item() > 0.0, (
            f"Penalty should be > 0 when eigenvalue outside band, "
            f"got {record.value.item()} for eigenvalue={e}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_monotonically_increasing_with_distance_below_min(self, data):
        """Penalty increases monotonically with distance below σ_min.

        Validates Requirement 13.2 (monotonicity below).
        """
        B, N = 1, 1
        # Draw two eigenvalues below σ_min
        e_closer = data.draw(st.floats(min_value=0.01, max_value=SIGMA_MIN - 1e-4,
                                       allow_nan=False, allow_infinity=False))
        e_farther = data.draw(st.floats(min_value=0.001, max_value=e_closer - 1e-4,
                                        allow_nan=False, allow_infinity=False))
        assume(e_closer > e_farther)

        # e_farther is farther from σ_min so should have higher penalty
        def compute_loss(e_val):
            covars2d = torch.zeros(B, N, 2, 2)
            covars2d[0, 0, 0, 0] = e_val
            covars2d[0, 0, 1, 1] = 1.0  # within band
            depths = torch.ones(B, N) * 1.0
            ctx = _make_splat_context(covars2d, depths)
            return SplatLoss(weight=1.0)(ctx).value.item()

        loss_closer = compute_loss(e_closer)
        loss_farther = compute_loss(e_farther)

        assert loss_farther >= loss_closer - 1e-6, (
            f"Penalty should increase with distance below σ_min: "
            f"loss(e={e_farther})={loss_farther} should >= loss(e={e_closer})={loss_closer}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_monotonically_increasing_with_distance_above_max(self, data):
        """Penalty increases monotonically with distance above σ_max.

        Validates Requirement 13.2 (monotonicity above).
        """
        B, N = 1, 1
        # Draw two eigenvalues above σ_max
        e_closer = data.draw(st.floats(min_value=SIGMA_MAX + 0.01, max_value=400.0,
                                       allow_nan=False, allow_infinity=False))
        e_farther = data.draw(st.floats(min_value=e_closer + 0.01, max_value=500.0,
                                        allow_nan=False, allow_infinity=False))
        assume(e_farther > e_closer)

        def compute_loss(e_val):
            covars2d = torch.zeros(B, N, 2, 2)
            covars2d[0, 0, 0, 0] = e_val
            covars2d[0, 0, 1, 1] = 1.0  # within band
            depths = torch.ones(B, N) * 1.0
            ctx = _make_splat_context(covars2d, depths)
            return SplatLoss(weight=1.0)(ctx).value.item()

        loss_closer = compute_loss(e_closer)
        loss_farther = compute_loss(e_farther)

        assert loss_farther >= loss_closer - 1e-6, (
            f"Penalty should increase with distance above σ_max: "
            f"loss(e={e_farther})={loss_farther} should >= loss(e={e_closer})={loss_closer}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_loss_is_arithmetic_mean_over_visible_splats(self, data):
        """Loss equals arithmetic mean of per-splat penalties over visible splats.

        Validates Requirement 13.3.
        """
        B, N = 1, data.draw(st.integers(min_value=2, max_value=8))

        # Generate eigenvalues (some within band, some outside)
        eigenvalues_list = []
        depths_list = []
        for _ in range(N):
            e1 = data.draw(st.floats(min_value=0.01, max_value=200.0,
                                     allow_nan=False, allow_infinity=False))
            e2 = data.draw(st.floats(min_value=0.01, max_value=200.0,
                                     allow_nan=False, allow_infinity=False))
            eigenvalues_list.append((e1, e2))
            # Mix visible and invisible splats
            d = data.draw(st.floats(min_value=-0.05, max_value=5.0,
                                    allow_nan=False, allow_infinity=False))
            depths_list.append(d)

        # Ensure at least one visible splat
        depths_list[0] = 1.0
        assume(sum(1 for d in depths_list if d > DEPTH_THRESHOLD) > 0)

        # Build diagonal covariance matrices
        covars2d = torch.zeros(B, N, 2, 2)
        for i, (e1, e2) in enumerate(eigenvalues_list):
            covars2d[0, i, 0, 0] = e1
            covars2d[0, i, 1, 1] = e2

        depths = torch.tensor([depths_list], dtype=torch.float32)  # [1, N]

        # Compute expected loss manually
        visible_penalties = []
        for i in range(N):
            if depths_list[i] > DEPTH_THRESHOLD:
                e1, e2 = eigenvalues_list[i]
                # penalty per eigenvalue: relu(σ_min - v) + relu(v - σ_max)
                p1 = max(0.0, SIGMA_MIN - e1) + max(0.0, e1 - SIGMA_MAX)
                p2 = max(0.0, SIGMA_MIN - e2) + max(0.0, e2 - SIGMA_MAX)
                visible_penalties.append(p1)
                visible_penalties.append(p2)

        expected_loss = sum(visible_penalties) / len(visible_penalties)

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        assert abs(record.value.item() - expected_loss) < 1e-5, (
            f"Loss should be arithmetic mean of visible splat penalties: "
            f"got {record.value.item()}, expected {expected_loss}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_invisible_splats_excluded(self, data):
        """Splats with depth <= threshold are excluded from the loss.

        Validates Requirement 13.3 (visible splats only).
        """
        B, N = 1, 4

        # All splats have eigenvalues outside the band (would contribute penalty)
        covars2d = torch.zeros(B, N, 2, 2)
        for i in range(N):
            e = data.draw(st.floats(min_value=SIGMA_MAX + 1.0, max_value=300.0,
                                    allow_nan=False, allow_infinity=False))
            covars2d[0, i, 0, 0] = e
            covars2d[0, i, 1, 1] = e

        # Mix visible and invisible splats
        n_visible = data.draw(st.integers(min_value=1, max_value=N))
        depths_list = []
        for i in range(N):
            if i < n_visible:
                depths_list.append(1.0)  # visible
            else:
                depths_list.append(DEPTH_THRESHOLD * 0.5)  # invisible

        depths = torch.tensor([depths_list], dtype=torch.float32)

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        # The loss should only average over visible splats
        assert record.diagnostics["visible_splats"] == n_visible, (
            f"Expected {n_visible} visible splats, "
            f"got {record.diagnostics['visible_splats']}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_zero_loss_when_no_visible_splat(self, data):
        """Loss is exactly 0.0 when no splat is visible.

        Validates Requirement 13.4.
        """
        B = 1
        N = data.draw(st.integers(min_value=1, max_value=8))

        # All splats have penalty-producing eigenvalues
        covars2d = torch.zeros(B, N, 2, 2)
        for i in range(N):
            covars2d[0, i, 0, 0] = 200.0  # above σ_max
            covars2d[0, i, 1, 1] = 200.0

        # All splats invisible (depth <= threshold)
        depths = torch.full((B, N), DEPTH_THRESHOLD * 0.5)

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Loss should be exactly 0.0 when no splat visible, "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_result_always_finite(self, data):
        """Result is always finite for valid inputs.

        General correctness property.
        """
        B, N = 1, data.draw(st.integers(min_value=1, max_value=6))

        covars2d = torch.zeros(B, N, 2, 2)
        for i in range(N):
            e1 = data.draw(st.floats(min_value=0.01, max_value=300.0,
                                     allow_nan=False, allow_infinity=False))
            e2 = data.draw(st.floats(min_value=0.01, max_value=300.0,
                                     allow_nan=False, allow_infinity=False))
            covars2d[0, i, 0, 0] = e1
            covars2d[0, i, 1, 1] = e2

        depths_vals = [
            data.draw(st.floats(min_value=-0.1, max_value=5.0,
                                allow_nan=False, allow_infinity=False))
            for _ in range(N)
        ]
        depths = torch.tensor([depths_vals], dtype=torch.float32)

        loss_fn = SplatLoss(weight=1.0)
        ctx = _make_splat_context(covars2d, depths)
        record = loss_fn(ctx)

        assert record.finite, (
            f"Loss should be finite, got value={record.value.item()}"
        )
        assert torch.isfinite(record.value), (
            f"Loss tensor should be finite, got {record.value.item()}"
        )
