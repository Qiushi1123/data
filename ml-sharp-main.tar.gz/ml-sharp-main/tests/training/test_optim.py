# Feature: sharp-training-framework, Property 20
"""Property test for the learning-rate schedule (Property 20).

**Validates: Requirements 18.2, 18.3, 18.4, 18.5**

Property 20: Learning rate is a deterministic function of step and resume-consistent.

For any step, the LR is deterministic (pure function of step). Resume from any
step recomputes the exact same LR that uninterrupted training would have produced.
"""

from __future__ import annotations

import math

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.config import OptimConfig
from sharp.training.optim import OptimizerScheduler, _make_lr_lambda


# --- Hypothesis strategies ---


@st.composite
def total_steps_strategy(draw):
    """Generate a valid total_steps value (must be > warmup_steps=10000)."""
    return draw(st.integers(min_value=15000, max_value=200000))


@st.composite
def warmup_step(draw, total_steps=100000):
    """Generate a step in the warmup phase [0, 10000)."""
    return draw(st.integers(min_value=0, max_value=9999))


@st.composite
def cosine_step(draw, total_steps=100000):
    """Generate a step in the cosine-decay phase [10000, total_steps]."""
    return draw(st.integers(min_value=10000, max_value=total_steps))


@st.composite
def beyond_final_step(draw, total_steps=100000):
    """Generate a step beyond the final step (> total_steps)."""
    return draw(st.integers(min_value=total_steps + 1, max_value=total_steps + 50000))


@st.composite
def any_valid_step(draw):
    """Generate any non-negative step."""
    return draw(st.integers(min_value=0, max_value=250000))


def _create_optimizer_scheduler(total_steps: int) -> OptimizerScheduler:
    """Create an OptimizerScheduler with a dummy parameter."""
    param = torch.nn.Parameter(torch.randn(4, 4))
    config = OptimConfig(warmup_steps=10000, peak_lr=1.6e-4, floor_lr=1.6e-5)
    return OptimizerScheduler(
        parameters=iter([param]),
        config=config,
        total_steps=total_steps,
    )


def _expected_lr(step: int, total_steps: int) -> float:
    """Compute the expected LR from the specification formula.

    lr(step) = 1.6e-4 * step/10000                             if step < 10000
             = 1.6e-5 + 0.5*(1.6e-4 - 1.6e-5)*(1+cos(π*(step-10000)/(final-10000)))
                                                                if 10000 <= step <= final
             = 1.6e-5                                           if step > final
    """
    peak_lr = 1.6e-4
    floor_lr = 1.6e-5
    warmup_steps = 10000

    if step < warmup_steps:
        return peak_lr * (step / warmup_steps)
    elif step > total_steps:
        return floor_lr
    else:
        progress = (step - warmup_steps) / (total_steps - warmup_steps)
        return floor_lr + 0.5 * (peak_lr - floor_lr) * (1.0 + math.cos(math.pi * progress))


# --- Property tests ---


class TestLRScheduleProperty20:
    """Property 20: Learning rate is a deterministic function of step and resume-consistent."""

    @settings(max_examples=100)
    @given(step=st.integers(min_value=0, max_value=9999))
    def test_warmup_phase_linear(self, step):
        """Req 18.2: During warmup [0, 10000), LR = 1.6e-4 * step/10000."""
        total_steps = 100000
        expected = _expected_lr(step, total_steps)

        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        # The actual LR = peak_lr * lr_lambda(step)
        actual_lr = 1.6e-4 * lr_lambda(step)

        assert abs(actual_lr - expected) < 1e-12, (
            f"Warmup LR at step={step}: expected={expected}, got={actual_lr}"
        )

    @settings(max_examples=100)
    @given(
        total_steps=st.integers(min_value=15000, max_value=200000),
        data=st.data(),
    )
    def test_cosine_phase_matches_formula(self, total_steps, data):
        """Req 18.3: During cosine phase [10000, total_steps], LR follows cosine decay."""
        step = data.draw(st.integers(min_value=10000, max_value=total_steps))
        expected = _expected_lr(step, total_steps)

        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        actual_lr = 1.6e-4 * lr_lambda(step)

        # Use relative tolerance of 1e-6 as spec requires
        if expected > 0:
            rel_diff = abs(actual_lr - expected) / expected
            assert rel_diff < 1e-6, (
                f"Cosine LR at step={step}, total_steps={total_steps}: "
                f"expected={expected}, got={actual_lr}, rel_diff={rel_diff}"
            )
        else:
            assert abs(actual_lr - expected) < 1e-12

    @settings(max_examples=100)
    @given(
        total_steps=st.integers(min_value=15000, max_value=200000),
        data=st.data(),
    )
    def test_beyond_final_step_clamped_to_floor(self, total_steps, data):
        """Req 18.4: Beyond final step, LR is clamped to floor 1.6e-5."""
        step = data.draw(
            st.integers(min_value=total_steps + 1, max_value=total_steps + 50000)
        )
        floor_lr = 1.6e-5

        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=floor_lr,
            total_steps=total_steps,
        )
        actual_lr = 1.6e-4 * lr_lambda(step)

        assert abs(actual_lr - floor_lr) < 1e-12, (
            f"LR beyond final step ({step} > {total_steps}) should be "
            f"{floor_lr}, got {actual_lr}"
        )

    @settings(max_examples=100, deadline=None)
    @given(
        total_steps=st.integers(min_value=15000, max_value=200000),
        data=st.data(),
    )
    def test_resume_produces_same_lr_as_uninterrupted(self, total_steps, data):
        """Req 18.5: Resume from checkpoint recomputes the exact same LR as
        uninterrupted training, within 1e-6 relative tolerance.

        The LR schedule is a pure function of step. resume(step) must produce
        the exact same LR that the lambda would yield at that step (which is
        what uninterrupted training computes).
        """
        step = data.draw(st.integers(min_value=0, max_value=total_steps + 5000))

        # The ground truth: LR is peak_lr * lr_lambda(step)
        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        expected_lr = 1.6e-4 * lr_lambda(step)

        # Resume from the given step and check the LR matches
        sched_resumed = _create_optimizer_scheduler(total_steps)
        sched_resumed.resume(step)
        resumed_lr = sched_resumed.get_lr()

        # They must match within 1e-6 relative tolerance
        if expected_lr > 0:
            rel_diff = abs(resumed_lr - expected_lr) / expected_lr
            assert rel_diff < 1e-6, (
                f"Resume LR mismatch at step={step}: expected={expected_lr}, "
                f"resumed={resumed_lr}, rel_diff={rel_diff}"
            )
        else:
            assert abs(resumed_lr - expected_lr) < 1e-12

    @settings(max_examples=100)
    @given(step=st.integers(min_value=0, max_value=200000))
    def test_lr_is_deterministic_pure_function_of_step(self, step):
        """LR is a pure function of step — calling lr_lambda twice yields
        the same result."""
        total_steps = 100000
        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        lr1 = lr_lambda(step)
        lr2 = lr_lambda(step)

        assert lr1 == lr2, (
            f"LR must be deterministic: step={step}, lr1={lr1}, lr2={lr2}"
        )

    @settings(max_examples=100)
    @given(
        total_steps=st.integers(min_value=15000, max_value=200000),
        data=st.data(),
    )
    def test_cosine_phase_is_monotonically_decreasing(self, total_steps, data):
        """Req 18.3: Cosine phase decreases monotonically from peak to floor."""
        step_a = data.draw(st.integers(min_value=10000, max_value=total_steps - 1))
        step_b = data.draw(st.integers(min_value=step_a + 1, max_value=total_steps))

        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        lr_a = 1.6e-4 * lr_lambda(step_a)
        lr_b = 1.6e-4 * lr_lambda(step_b)

        assert lr_a >= lr_b - 1e-12, (
            f"Cosine phase must be monotonically decreasing: "
            f"step_a={step_a} (lr={lr_a}) > step_b={step_b} (lr={lr_b})"
        )

    @settings(max_examples=100)
    @given(step=st.integers(min_value=0, max_value=200000))
    def test_lr_is_always_within_bounds(self, step):
        """LR is always in [0, peak_lr=1.6e-4] for any step."""
        total_steps = 100000
        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        actual_lr = 1.6e-4 * lr_lambda(step)

        assert actual_lr >= 0.0, f"LR must be >= 0, got {actual_lr} at step={step}"
        assert actual_lr <= 1.6e-4 + 1e-12, (
            f"LR must be <= peak (1.6e-4), got {actual_lr} at step={step}"
        )

    @settings(max_examples=100)
    @given(step=st.integers(min_value=0, max_value=9999))
    def test_warmup_is_monotonically_increasing(self, step):
        """Req 18.2: Warmup phase increases monotonically."""
        assume(step < 9999)
        total_steps = 100000
        lr_lambda = _make_lr_lambda(
            warmup_steps=10000,
            peak_lr=1.6e-4,
            floor_lr=1.6e-5,
            total_steps=total_steps,
        )
        lr_at_step = 1.6e-4 * lr_lambda(step)
        lr_at_next = 1.6e-4 * lr_lambda(step + 1)

        assert lr_at_next >= lr_at_step, (
            f"Warmup must be monotonically increasing: "
            f"step={step} (lr={lr_at_step}) <= step={step+1} (lr={lr_at_next})"
        )
