# Feature: sharp-training-framework, Property 13
"""Property test for floater-suppression gating (Property 13).

**Validates: Requirements 11.2, 11.3, 11.4**

Property 13: Floater-suppression gating is zero below epsilon, monotonic,
and opacity-weighted.

For any set of disparity-gradient magnitudes g and opacities alpha, each
per-Gaussian penalty 1 - exp(-(1/sigma)*max(0, g - epsilon)) (sigma = epsilon = 1e-2)
equals exactly 0 when g <= epsilon, lies in [0, 1), increases monotonically with g,
and the loss equals the mean of alpha * penalty over in-bounds Gaussians, so
opacity-0 Gaussians contribute nothing.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.losses.floater import FloaterLoss
from sharp.training.types import LossContext, LossRecord, RenderTrainOutputs


# --- Constants matching the implementation ---
SIGMA = 1e-2
EPSILON = 1e-2


# --- Pure gating function (reference implementation for direct testing) ---


def _gating_penalty(g: torch.Tensor) -> torch.Tensor:
    """Reference implementation of the floater gating penalty.

    penalty = 1 - exp(-(1/sigma) * max(0, g - epsilon))
    """
    g_minus_eps = torch.clamp(g - EPSILON, min=0.0)
    return 1.0 - torch.exp(-(1.0 / SIGMA) * g_minus_eps)


# --- Hypothesis strategies ---


@st.composite
def gradient_magnitudes_below_epsilon(draw):
    """Generate gradient magnitudes at or below epsilon."""
    n = draw(st.integers(min_value=1, max_value=50))
    vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=EPSILON,
                      allow_nan=False, allow_infinity=False),
            min_size=n,
            max_size=n,
        )
    )
    return torch.tensor(vals, dtype=torch.float32)


@st.composite
def gradient_magnitudes_above_epsilon(draw):
    """Generate gradient magnitudes strictly above epsilon."""
    n = draw(st.integers(min_value=1, max_value=50))
    vals = draw(
        st.lists(
            st.floats(min_value=EPSILON + 1e-6, max_value=10.0,
                      allow_nan=False, allow_infinity=False),
            min_size=n,
            max_size=n,
        )
    )
    return torch.tensor(vals, dtype=torch.float32)


@st.composite
def gradient_magnitudes_general(draw):
    """Generate arbitrary non-negative gradient magnitudes."""
    n = draw(st.integers(min_value=1, max_value=50))
    vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=100.0,
                      allow_nan=False, allow_infinity=False),
            min_size=n,
            max_size=n,
        )
    )
    return torch.tensor(vals, dtype=torch.float32)


@st.composite
def opacities_tensor(draw, n: int):
    """Generate opacities in [0, 1]."""
    vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0,
                      allow_nan=False, allow_infinity=False),
            min_size=n,
            max_size=n,
        )
    )
    return torch.tensor(vals, dtype=torch.float32)


@st.composite
def floater_loss_inputs(draw):
    """Generate full inputs for the FloaterLoss module.

    Creates a disparity map, base_xy_ndc positions (in-bounds), and opacities.
    The disparity map is constructed with known gradient magnitudes to enable
    controlled testing of the full pipeline.
    """
    B = 1
    H = draw(st.integers(min_value=8, max_value=16))
    W = draw(st.integers(min_value=8, max_value=16))
    N = draw(st.integers(min_value=2, max_value=20))

    # Generate a disparity map [B, 2, H, W]
    disp_vals = draw(
        st.lists(
            st.floats(min_value=0.1, max_value=5.0,
                      allow_nan=False, allow_infinity=False),
            min_size=B * 2 * H * W,
            max_size=B * 2 * H * W,
        )
    )
    disparity_pred = torch.tensor(disp_vals, dtype=torch.float32).reshape(B, 2, H, W)

    # Generate in-bounds NDC positions in [-1, 1]
    ndc_vals = draw(
        st.lists(
            st.floats(min_value=-0.9, max_value=0.9,
                      allow_nan=False, allow_infinity=False),
            min_size=B * N * 2,
            max_size=B * N * 2,
        )
    )
    base_xy_ndc = torch.tensor(ndc_vals, dtype=torch.float32).reshape(B, N, 2)

    # Generate opacities in [0, 1]
    opacity_vals = draw(
        st.lists(
            st.floats(min_value=0.0, max_value=1.0,
                      allow_nan=False, allow_infinity=False),
            min_size=B * N,
            max_size=B * N,
        )
    )
    opacities = torch.tensor(opacity_vals, dtype=torch.float32).reshape(B, N)

    return disparity_pred, base_xy_ndc, opacities, B, N, H, W


# --- Helper: build LossContext for FloaterLoss ---


class _FakeGaussians:
    """Minimal fake Gaussians3D with just opacities attribute."""

    def __init__(self, opacities: torch.Tensor):
        self.opacities = opacities


def _make_floater_context(
    disparity_pred: torch.Tensor,
    base_xy_ndc: torch.Tensor,
    opacities: torch.Tensor,
) -> LossContext:
    """Build a LossContext for the FloaterLoss module."""
    return LossContext(
        disparity_pred=disparity_pred,
        base_xy_ndc=base_xy_ndc,
        gaussians=_FakeGaussians(opacities),
    )


# --- Property tests: Direct gating function ---


class TestFloaterGatingDirect:
    """Test the gating function directly (not through the full loss module)."""

    @settings(max_examples=100)
    @given(g=gradient_magnitudes_below_epsilon())
    def test_penalty_exactly_zero_below_epsilon(self, g: torch.Tensor):
        """Penalty is exactly 0 when g <= epsilon.

        Requirements 11.2: Any disparity-gradient magnitude at or below
        epsilon = 1e-2 yields a per-Gaussian penalty of exactly 0.
        """
        penalty = _gating_penalty(g)
        assert torch.all(penalty == 0.0), (
            f"Penalty should be exactly 0 for g <= epsilon={EPSILON}, "
            f"got max penalty={penalty.max().item()} for g values up to {g.max().item()}"
        )

    @settings(max_examples=100)
    @given(g=gradient_magnitudes_above_epsilon())
    def test_penalty_in_zero_one_range(self, g: torch.Tensor):
        """Penalty lies in [0, 1] for any g > epsilon.

        The exponential gating 1 - exp(-x) for x > 0 is mathematically in (0, 1),
        but in float32, exp(-x) can underflow to 0 for large x (when
        (1/sigma)*(g - epsilon) > ~88), yielding penalty = 1.0 exactly.
        We therefore check [0, 1] (inclusive) in the float32 domain.
        """
        penalty = _gating_penalty(g)
        assert torch.all(penalty >= 0.0), (
            f"Penalty should be >= 0, got min={penalty.min().item()}"
        )
        assert torch.all(penalty <= 1.0), (
            f"Penalty should be <= 1, got max={penalty.max().item()}"
        )

    @settings(max_examples=100)
    @given(g=gradient_magnitudes_general())
    def test_penalty_always_non_negative_and_at_most_one(self, g: torch.Tensor):
        """For any g >= 0, penalty is in [0, 1].

        Mathematically in [0, 1), but float32 exp underflow can produce
        exactly 1.0 when (1/sigma)*(g - epsilon) is large.
        """
        penalty = _gating_penalty(g)
        assert torch.all(penalty >= 0.0), (
            f"Penalty should be >= 0, got min={penalty.min().item()}"
        )
        assert torch.all(penalty <= 1.0), (
            f"Penalty should be <= 1, got max={penalty.max().item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_penalty_monotonically_increasing_with_g(self, data):
        """Penalty increases monotonically with g.

        For g1 < g2, penalty(g1) <= penalty(g2).
        """
        g1_val = data.draw(
            st.floats(min_value=0.0, max_value=50.0,
                      allow_nan=False, allow_infinity=False)
        )
        g2_val = data.draw(
            st.floats(min_value=g1_val, max_value=100.0,
                      allow_nan=False, allow_infinity=False)
        )
        assume(g2_val >= g1_val)

        g1 = torch.tensor([g1_val])
        g2 = torch.tensor([g2_val])

        penalty1 = _gating_penalty(g1)
        penalty2 = _gating_penalty(g2)

        assert penalty2.item() >= penalty1.item() - 1e-7, (
            f"Penalty should be monotonically increasing: "
            f"penalty(g={g1_val})={penalty1.item()}, "
            f"penalty(g={g2_val})={penalty2.item()}"
        )


# --- Property tests: Full FloaterLoss module behavior ---


class TestFloaterLossModule:
    """Test the full FloaterLoss module behavior (Property 13)."""

    @settings(max_examples=100)
    @given(inputs=floater_loss_inputs())
    def test_loss_equals_mean_opacity_weighted_penalty_over_inbounds(self, inputs):
        """Loss equals mean of alpha * penalty over in-bounds Gaussians.

        Requirements 11.3: The floater-suppression loss is the mean over all
        evaluated Gaussians of alpha_i * penalty_i.
        """
        disparity_pred, base_xy_ndc, opacities, B, N, H, W = inputs

        loss_fn = FloaterLoss(weight=0.5)
        ctx = _make_floater_context(disparity_pred, base_xy_ndc, opacities)
        record = loss_fn(ctx)

        # All positions are in-bounds (generated in [-0.9, 0.9])
        # so in_bounds_count should equal B * N
        assert record.diagnostics["in_bounds_count"] == B * N, (
            f"All gaussians should be in-bounds, got {record.diagnostics['in_bounds_count']}/{B * N}"
        )

        # Manually compute: sample grad at ndc positions, apply gating, weight by alpha
        # We replicate the module's computation independently
        disp_layer0 = disparity_pred[:, 0:1]  # [B, 1, H, W]

        # Compute gradient magnitude using the same Sobel approach
        grad_mag = loss_fn._compute_gradient_magnitude(disp_layer0)

        # Sample at NDC positions
        import torch.nn.functional as F
        grid = base_xy_ndc.unsqueeze(1)  # [B, 1, N, 2]
        sampled_grad = F.grid_sample(
            grad_mag, grid, mode="bilinear", padding_mode="zeros", align_corners=True
        ).squeeze(1).squeeze(1)  # [B, N]

        # Compute penalties
        g_minus_eps = torch.clamp(sampled_grad - EPSILON, min=0.0)
        penalty = 1.0 - torch.exp(-(1.0 / SIGMA) * g_minus_eps)

        # Weight by opacity and take mean
        weighted = opacities * penalty
        expected_loss = weighted.mean()

        assert abs(record.value.item() - expected_loss.item()) < 1e-5, (
            f"Loss mismatch: got {record.value.item()}, expected {expected_loss.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_zero_opacity_contributes_nothing(self, data):
        """Gaussians with opacity=0 contribute nothing to the loss.

        Requirements 11.3, 11.4: opacity-0 Gaussians contribute nothing.
        """
        B, H, W = 1, 10, 10
        N = data.draw(st.integers(min_value=2, max_value=10))

        # Non-constant disparity to produce non-zero gradients
        disparity_pred = torch.randn(B, 2, H, W).abs() + 0.5

        # In-bounds positions
        ndc_vals = data.draw(
            st.lists(
                st.floats(min_value=-0.8, max_value=0.8,
                          allow_nan=False, allow_infinity=False),
                min_size=B * N * 2,
                max_size=B * N * 2,
            )
        )
        base_xy_ndc = torch.tensor(ndc_vals, dtype=torch.float32).reshape(B, N, 2)

        # All opacities = 0
        opacities_zero = torch.zeros(B, N)

        loss_fn = FloaterLoss(weight=0.5)
        ctx = _make_floater_context(disparity_pred, base_xy_ndc, opacities_zero)
        record = loss_fn(ctx)

        assert record.value.item() == 0.0, (
            f"Loss should be 0.0 when all opacities are 0, got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_out_of_bounds_excluded_from_mean(self, data):
        """Out-of-bounds Gaussians are excluded from the mean.

        Requirements 11.4: If a Gaussian's projection falls outside image
        bounds, it is excluded from the mean.
        """
        B, H, W = 1, 10, 10
        N_in = data.draw(st.integers(min_value=2, max_value=5))
        N_out = data.draw(st.integers(min_value=1, max_value=5))
        N = N_in + N_out

        # Non-constant disparity for non-zero gradients
        disparity_pred = torch.randn(B, 2, H, W).abs() + 0.5

        # In-bounds positions (first N_in)
        in_bounds_vals = data.draw(
            st.lists(
                st.floats(min_value=-0.8, max_value=0.8,
                          allow_nan=False, allow_infinity=False),
                min_size=N_in * 2,
                max_size=N_in * 2,
            )
        )
        # Out-of-bounds positions (last N_out) - beyond [-1, 1]
        out_bounds_vals = data.draw(
            st.lists(
                st.floats(min_value=1.5, max_value=3.0,
                          allow_nan=False, allow_infinity=False),
                min_size=N_out * 2,
                max_size=N_out * 2,
            )
        )

        ndc_in = torch.tensor(in_bounds_vals, dtype=torch.float32).reshape(N_in, 2)
        ndc_out = torch.tensor(out_bounds_vals, dtype=torch.float32).reshape(N_out, 2)
        base_xy_ndc = torch.cat([ndc_in, ndc_out], dim=0).unsqueeze(0)  # [1, N, 2]

        # All opacities = 1 for clear contribution
        opacities = torch.ones(B, N)

        loss_fn = FloaterLoss(weight=0.5)
        ctx = _make_floater_context(disparity_pred, base_xy_ndc, opacities)
        record = loss_fn(ctx)

        # Only in-bounds Gaussians should contribute
        assert record.diagnostics["in_bounds_count"] == N_in, (
            f"Only {N_in} in-bounds Gaussians should be counted, "
            f"got {record.diagnostics['in_bounds_count']}"
        )

        # Compute expected loss from in-bounds only
        disp_layer0 = disparity_pred[:, 0:1]
        grad_mag = loss_fn._compute_gradient_magnitude(disp_layer0)

        import torch.nn.functional as F
        grid_in = ndc_in.unsqueeze(0).unsqueeze(1)  # [1, 1, N_in, 2]
        sampled_in = F.grid_sample(
            grad_mag, grid_in, mode="bilinear", padding_mode="zeros", align_corners=True
        ).squeeze(1).squeeze(1)  # [1, N_in]

        g_minus_eps = torch.clamp(sampled_in - EPSILON, min=0.0)
        penalty_in = 1.0 - torch.exp(-(1.0 / SIGMA) * g_minus_eps)
        expected_loss = penalty_in.mean()  # opacity=1 so alpha*penalty = penalty

        assert abs(record.value.item() - expected_loss.item()) < 1e-5, (
            f"Loss should be mean over in-bounds only: "
            f"got {record.value.item()}, expected {expected_loss.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_constant_disparity_yields_zero_loss(self, data):
        """A constant disparity map has zero gradient, so penalty is 0 everywhere.

        When the disparity is constant, |nabla D^-1| = 0 <= epsilon, so all
        penalties are exactly 0 and the loss is 0.
        """
        B, H, W = 1, 10, 10
        N = data.draw(st.integers(min_value=2, max_value=20))

        # Constant disparity -> zero gradient
        const_val = data.draw(
            st.floats(min_value=0.1, max_value=10.0,
                      allow_nan=False, allow_infinity=False)
        )
        disparity_pred = torch.full((B, 2, H, W), const_val)

        # In-bounds positions
        ndc_vals = data.draw(
            st.lists(
                st.floats(min_value=-0.9, max_value=0.9,
                          allow_nan=False, allow_infinity=False),
                min_size=N * 2,
                max_size=N * 2,
            )
        )
        base_xy_ndc = torch.tensor(ndc_vals, dtype=torch.float32).reshape(B, N, 2)

        # Non-zero opacities
        opacities = torch.ones(B, N)

        loss_fn = FloaterLoss(weight=0.5)
        ctx = _make_floater_context(disparity_pred, base_xy_ndc, opacities)
        record = loss_fn(ctx)

        assert abs(record.value.item()) < 1e-5, (
            f"Loss should be ~0 for constant disparity (zero gradient), "
            f"got {record.value.item()}"
        )

    @settings(max_examples=100)
    @given(inputs=floater_loss_inputs())
    def test_loss_is_finite_and_non_negative(self, inputs):
        """The loss is always finite and non-negative for valid inputs."""
        disparity_pred, base_xy_ndc, opacities, B, N, H, W = inputs

        loss_fn = FloaterLoss(weight=0.5)
        ctx = _make_floater_context(disparity_pred, base_xy_ndc, opacities)
        record = loss_fn(ctx)

        assert record.finite, f"Loss should be finite, got {record.value.item()}"
        assert record.value.item() >= 0.0, (
            f"Loss should be non-negative, got {record.value.item()}"
        )
