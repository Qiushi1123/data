# Feature: sharp-training-framework, Property 10
"""Property test for alpha loss (Property 10).

**Validates: Requirements 8.1**

Property 10: Alpha loss is BCE toward 1 and vanishes at alpha=1.

For any rendered alpha map with values in (0, 1), the input-view alpha loss
equals the binary cross-entropy between the alpha and a target of 1
(i.e. mean(-log alpha)), is monotonically non-increasing as alpha increases
toward 1, and approaches 0 as alpha approaches 1.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.losses.alpha import AlphaLoss
from sharp.training.types import LossContext, LossRecord, RenderTrainOutputs


# --- Hypothesis strategies ---


@st.composite
def alpha_tensor(draw, min_val: float = 0.01, max_val: float = 0.99):
    """Generate a random alpha tensor [B, 1, H, W] in (min_val, max_val)."""
    batch = draw(st.integers(min_value=1, max_value=2))
    height = draw(st.integers(min_value=2, max_value=8))
    width = draw(st.integers(min_value=2, max_value=8))

    vals = draw(
        st.lists(
            st.floats(min_value=min_val, max_value=max_val,
                      allow_nan=False, allow_infinity=False),
            min_size=batch * 1 * height * width,
            max_size=batch * 1 * height * width,
        )
    )
    return torch.tensor(vals, dtype=torch.float32).reshape(batch, 1, height, width)


@st.composite
def alpha_tensor_fixed_shape(draw, batch: int = 1, height: int = 4, width: int = 4,
                              min_val: float = 0.01, max_val: float = 0.99):
    """Generate an alpha tensor with a fixed shape."""
    vals = draw(
        st.lists(
            st.floats(min_value=min_val, max_value=max_val,
                      allow_nan=False, allow_infinity=False),
            min_size=batch * 1 * height * width,
            max_size=batch * 1 * height * width,
        )
    )
    return torch.tensor(vals, dtype=torch.float32).reshape(batch, 1, height, width)


def _make_loss_context_input_only(alpha: torch.Tensor) -> LossContext:
    """Build a LossContext with only input render (for input-view alpha tests).

    Novel render and mask are set to trivial values so the loss computes
    both views but we focus on the input-view contribution.
    """
    B, C, H, W = alpha.shape
    input_render = RenderTrainOutputs(
        color=torch.zeros(B, 3, H, W),
        depth=torch.ones(B, 1, H, W),
        alpha=alpha,
        meta={},
    )
    # Provide novel render with alpha=1 (contributes ~0 novel loss)
    # and a full mask so the module activates normally
    novel_render = RenderTrainOutputs(
        color=torch.zeros(B, 3, H, W),
        depth=torch.ones(B, 1, H, W),
        alpha=torch.ones(B, 1, H, W) * 0.999,
        meta={},
    )
    mask = torch.ones(B, 1, H, W)

    return LossContext(
        input_render=input_render,
        novel_render=novel_render,
        mask=mask,
    )


def _make_loss_context_novel_zero_mask(alpha: torch.Tensor) -> LossContext:
    """Build a LossContext with zero mask for novel view.

    This tests that novel-view loss is 0 when mask selects no pixels.
    """
    B, C, H, W = alpha.shape
    input_render = RenderTrainOutputs(
        color=torch.zeros(B, 3, H, W),
        depth=torch.ones(B, 1, H, W),
        alpha=alpha,
        meta={},
    )
    novel_render = RenderTrainOutputs(
        color=torch.zeros(B, 3, H, W),
        depth=torch.ones(B, 1, H, W),
        alpha=alpha,
        meta={},
    )
    # Zero mask -> novel loss should be 0
    mask = torch.zeros(B, 1, H, W)

    return LossContext(
        input_render=input_render,
        novel_render=novel_render,
        mask=mask,
    )


# --- Property tests ---


class TestAlphaLossProperty10:
    """Property 10: Alpha loss is BCE toward 1 and vanishes at alpha=1."""

    @settings(max_examples=100)
    @given(alpha=alpha_tensor(min_val=0.01, max_val=0.99))
    def test_input_view_loss_equals_mean_neg_log_alpha(self, alpha: torch.Tensor):
        """Input-view loss equals mean(-log(alpha)) for values in (eps, 1-eps).

        The AlphaLoss for the input view applies BCE(alpha, target=1) which is
        -log(alpha), averaged over all valid pixels.
        """
        loss_fn = AlphaLoss(weight=1.0)
        ctx = _make_loss_context_input_only(alpha)

        record = loss_fn(ctx)

        # Compute expected input-view loss: mean(-log(alpha)) with clamping
        eps = 1e-7
        alpha_clamped = alpha.clamp(min=eps, max=1.0 - eps)
        expected_input_loss = (-torch.log(alpha_clamped)).mean()

        # The total loss includes a small novel-view contribution from alpha=0.999
        # So we check the input_loss diagnostic directly
        input_loss_actual = record.diagnostics["input_loss"]

        assert abs(input_loss_actual - expected_input_loss.item()) < 1e-5, (
            f"input_loss={input_loss_actual}, expected={expected_input_loss.item()}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_monotonically_nonincreasing_as_alpha_increases(self, data):
        """Loss is monotonically non-increasing as alpha increases toward 1.

        If all alpha values increase, the loss should decrease (or stay equal).
        """
        B, H, W = 1, 4, 4
        # Draw two sets of alpha values and sort them
        alpha_low_val = data.draw(
            st.floats(min_value=0.05, max_value=0.5,
                      allow_nan=False, allow_infinity=False)
        )
        alpha_high_val = data.draw(
            st.floats(min_value=alpha_low_val + 0.01, max_value=0.99,
                      allow_nan=False, allow_infinity=False)
        )
        assume(alpha_high_val > alpha_low_val)

        alpha_low = torch.full((B, 1, H, W), alpha_low_val)
        alpha_high = torch.full((B, 1, H, W), alpha_high_val)

        loss_fn = AlphaLoss(weight=1.0)

        ctx_low = _make_loss_context_input_only(alpha_low)
        ctx_high = _make_loss_context_input_only(alpha_high)

        record_low = loss_fn(ctx_low)
        record_high = loss_fn(ctx_high)

        loss_low = record_low.diagnostics["input_loss"]
        loss_high = record_high.diagnostics["input_loss"]

        # Higher alpha -> lower loss (monotonically non-increasing)
        assert loss_high <= loss_low + 1e-6, (
            f"Loss should decrease as alpha increases: "
            f"loss(alpha={alpha_low_val})={loss_low}, "
            f"loss(alpha={alpha_high_val})={loss_high}"
        )

    @settings(max_examples=100)
    @given(data=st.data())
    def test_loss_approaches_zero_as_alpha_approaches_one(self, data):
        """Loss approaches 0 as alpha approaches 1.

        For alpha=0.999, the loss -log(0.999) ~ 0.001 which is very small.
        """
        B, H, W = 1, 4, 4
        # Draw alpha very close to 1
        alpha_val = data.draw(
            st.floats(min_value=0.999, max_value=0.9999,
                      allow_nan=False, allow_infinity=False)
        )

        alpha = torch.full((B, 1, H, W), alpha_val)
        loss_fn = AlphaLoss(weight=1.0)
        ctx = _make_loss_context_input_only(alpha)

        record = loss_fn(ctx)
        input_loss = record.diagnostics["input_loss"]

        # -log(0.999) ≈ 0.001, -log(0.9999) ≈ 0.0001
        # Should be very small (< 0.01)
        assert input_loss < 0.01, (
            f"Loss should approach 0 for alpha near 1, got {input_loss} "
            f"for alpha={alpha_val}"
        )

    @settings(max_examples=100)
    @given(alpha=alpha_tensor(min_val=0.01, max_val=0.99))
    def test_novel_view_zero_mask_gives_zero_novel_loss(self, alpha: torch.Tensor):
        """Novel-view with zero mask gives novel loss = 0.0."""
        loss_fn = AlphaLoss(weight=1.0)
        ctx = _make_loss_context_novel_zero_mask(alpha)

        record = loss_fn(ctx)

        novel_loss = record.diagnostics["novel_loss"]
        assert novel_loss == 0.0, (
            f"Novel loss should be 0.0 with zero mask, got {novel_loss}"
        )

    @settings(max_examples=100)
    @given(alpha=alpha_tensor(min_val=0.01, max_val=0.99))
    def test_result_always_finite_for_valid_alpha(self, alpha: torch.Tensor):
        """Result is always finite for valid alpha in (0, 1)."""
        loss_fn = AlphaLoss(weight=1.0)
        ctx = _make_loss_context_input_only(alpha)

        record = loss_fn(ctx)

        assert record.finite, (
            f"Loss should be finite for valid alpha, got value={record.value.item()}"
        )
        assert torch.isfinite(record.value), (
            f"Loss tensor should be finite, got {record.value.item()}"
        )
