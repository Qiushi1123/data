"""Property-based tests for single-device residency during training.

# Feature: sharp-training-framework, Property 23

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import torch
from hypothesis import given, settings
from hypothesis import strategies as st
from torch import nn

from sharp.training.aggregator import LossAggregator
from sharp.training.camera import CameraModule, ViewCameras
from sharp.training.forward import TrainingForward, TrainingOutputs
from sharp.training.losses.alpha import AlphaLoss
from sharp.training.losses.color import ColorLoss
from sharp.training.masking import ViewMasker
from sharp.training.step import TrainingSample
from sharp.training.types import LossContext, RenderTrainOutputs
from sharp.utils.gaussians import Gaussians3D

# Reuse the stub predictor and mock renderer from existing tests
from tests.training.test_backward import MockRenderer, _make_cameras
from tests.training.test_forward import _build_stub_predictor, _H, _W


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _collect_all_tensors_from_sample(sample: TrainingSample) -> dict[str, torch.Tensor]:
    """Collect all tensor fields from a TrainingSample."""
    tensors: dict[str, torch.Tensor] = {
        "sample.input_image": sample.input_image,
        "sample.novel_image": sample.novel_image,
        "sample.disparity_factor": sample.disparity_factor,
        "sample.cameras.k_src": sample.cameras.k_src,
        "sample.cameras.e_src": sample.cameras.e_src,
        "sample.cameras.k_tgt": sample.cameras.k_tgt,
        "sample.cameras.e_tgt": sample.cameras.e_tgt,
    }
    if sample.input_depth is not None:
        tensors["sample.input_depth"] = sample.input_depth
    return tensors


def _collect_all_tensors_from_render(
    render: RenderTrainOutputs, prefix: str
) -> dict[str, torch.Tensor]:
    """Collect all tensor fields from a RenderTrainOutputs."""
    tensors: dict[str, torch.Tensor] = {
        f"{prefix}.color": render.color,
        f"{prefix}.depth": render.depth,
        f"{prefix}.alpha": render.alpha,
    }
    if render.meta:
        for key, val in render.meta.items():
            if isinstance(val, torch.Tensor):
                tensors[f"{prefix}.meta.{key}"] = val
    return tensors


def _collect_all_tensors_from_outputs(
    outputs: TrainingOutputs,
) -> dict[str, torch.Tensor]:
    """Collect all tensor fields from TrainingOutputs."""
    gaussians = outputs.gaussians
    tensors: dict[str, torch.Tensor] = {
        "outputs.gaussians.mean_vectors": gaussians.mean_vectors,
        "outputs.gaussians.singular_values": gaussians.singular_values,
        "outputs.gaussians.quaternions": gaussians.quaternions,
        "outputs.gaussians.colors": gaussians.colors,
        "outputs.gaussians.opacities": gaussians.opacities,
        "outputs.aligned_depth": outputs.aligned_depth,
        "outputs.disparity_pred": outputs.disparity_pred,
        "outputs.base_xy_ndc": outputs.base_xy_ndc,
        "outputs.monodepth_disparity": outputs.monodepth_disparity,
    }
    if outputs.scale_map is not None:
        tensors["outputs.scale_map"] = outputs.scale_map
    return tensors


# ---------------------------------------------------------------------------
# Property test
# ---------------------------------------------------------------------------


@given(
    batch_size=st.integers(min_value=1, max_value=2),
    provide_depth=st.booleans(),
)
@settings(max_examples=50)
def test_all_step_tensors_reside_on_single_device(
    batch_size: int,
    provide_depth: bool,
) -> None:
    """Property 23: All step tensors reside on the single selected device.

    **Validates: Requirements 22.4, 22.5**

    For any training step, all model parameters, sample tensors, and loss
    tensors reside on the single selected device (cpu).

    This test verifies that during a full training step:
    1. All model parameters are on the selected device (cpu).
    2. All training sample tensors are on the selected device.
    3. All forward-pass output tensors are on the selected device.
    4. All rendered output tensors are on the selected device.
    5. The view mask tensor is on the selected device.
    6. The aggregated loss tensor is on the selected device.
    """
    device = torch.device("cpu")

    # --- Build model on the target device ---
    predictor = _build_stub_predictor()
    predictor.to(device)
    predictor.train()
    training_forward = TrainingForward(predictor)

    # --- Verify: all model parameters reside on the selected device ---
    for name, param in predictor.named_parameters():
        assert param.device == device, (
            f"Model parameter '{name}' resides on {param.device}, "
            f"expected {device}"
        )

    # --- Build sample on the target device ---
    image = torch.rand(batch_size, 3, _H, _W, device=device) * 0.8 + 0.1
    novel_image = torch.rand(batch_size, 3, _H, _W, device=device)
    disparity_factor = torch.rand(batch_size, device=device) * 10 + 1.0

    depth: torch.Tensor | None = None
    if provide_depth:
        depth = torch.rand(batch_size, 1, _H, _W, device=device) * 5 + 0.1

    cameras = _make_cameras(batch_size)
    # Cameras from _make_cameras are already on cpu

    sample = TrainingSample(
        input_image=image,
        novel_image=novel_image,
        cameras=cameras,
        disparity_factor=disparity_factor,
        input_depth=depth,
    )

    # --- Verify: all sample tensors are on the selected device ---
    sample_tensors = _collect_all_tensors_from_sample(sample)
    for name, tensor in sample_tensors.items():
        assert tensor.device == device, (
            f"Sample tensor '{name}' resides on {tensor.device}, "
            f"expected {device}"
        )

    # --- Step 1: Training forward ---
    outputs: TrainingOutputs = training_forward(
        image, disparity_factor, depth=depth
    )

    # --- Verify: all forward outputs are on the selected device ---
    output_tensors = _collect_all_tensors_from_outputs(outputs)
    for name, tensor in output_tensors.items():
        assert tensor.device == device, (
            f"Forward output tensor '{name}' resides on {tensor.device}, "
            f"expected {device}"
        )

    # --- Step 2: Dual-view rendering (mock) ---
    mock_renderer = MockRenderer()
    camera_module = CameraModule()

    input_extrinsics, input_intrinsics = camera_module.input_view(cameras)
    novel_extrinsics, novel_intrinsics = camera_module.novel_view(cameras)

    input_render = mock_renderer.forward_train(
        gaussians=outputs.gaussians,
        extrinsics=input_extrinsics,
        intrinsics=input_intrinsics,
        image_width=_W,
        image_height=_H,
    )
    novel_render = mock_renderer.forward_train(
        gaussians=outputs.gaussians,
        extrinsics=novel_extrinsics,
        intrinsics=novel_intrinsics,
        image_width=_W,
        image_height=_H,
    )

    # --- Verify: all render output tensors are on the selected device ---
    input_render_tensors = _collect_all_tensors_from_render(
        input_render, "input_render"
    )
    for name, tensor in input_render_tensors.items():
        assert tensor.device == device, (
            f"Render tensor '{name}' resides on {tensor.device}, "
            f"expected {device}"
        )

    novel_render_tensors = _collect_all_tensors_from_render(
        novel_render, "novel_render"
    )
    for name, tensor in novel_render_tensors.items():
        assert tensor.device == device, (
            f"Render tensor '{name}' resides on {tensor.device}, "
            f"expected {device}"
        )

    # --- Step 3: View mask ---
    view_masker = ViewMasker()
    mask = view_masker.compute(novel_render.depth, cameras)

    # --- Verify: mask is on the selected device ---
    assert mask.device == device, (
        f"View mask resides on {mask.device}, expected {device}"
    )

    # --- Step 4: Aggregate losses ---
    ctx = LossContext(
        input_render=input_render,
        novel_render=novel_render,
        input_gt_image=sample.input_image,
        novel_gt_image=sample.novel_image,
        mask=mask,
        gaussians=outputs.gaussians,
        aligned_depth=outputs.aligned_depth,
        disparity_pred=outputs.disparity_pred,
        scale_map=outputs.scale_map,
        base_xy_ndc=outputs.base_xy_ndc,
        monodepth_disparity=outputs.monodepth_disparity,
        cameras=cameras,
    )

    color_loss = ColorLoss(weight=1.0)
    alpha_loss = AlphaLoss(weight=1.0)
    aggregator = LossAggregator(
        modules=[color_loss, alpha_loss],
        active_names={"color", "alpha"},
    )
    result = aggregator.aggregate(ctx)

    # --- Verify: aggregated loss tensor is on the selected device ---
    assert result.total.device == device, (
        f"Aggregated total loss resides on {result.total.device}, "
        f"expected {device}"
    )

    # --- Verify: each individual loss record value is on the selected device ---
    for record in result.records:
        assert record.value.device == device, (
            f"Loss record '{record.name}' value resides on "
            f"{record.value.device}, expected {device}"
        )

    # --- Step 5: Backward pass (verify no device mismatch occurs) ---
    if result.total.requires_grad:
        result.total.backward()

    # --- Final check: after backward, all gradients are on the selected device ---
    for name, param in predictor.named_parameters():
        if param.requires_grad and param.grad is not None:
            assert param.grad.device == device, (
                f"Gradient for parameter '{name}' resides on "
                f"{param.grad.device}, expected {device}"
            )
