# Feature: sharp-training-framework, Property 5
"""Property test for ViewMasker: mask equals 1 iff source-view normalized coords
are in [-1.05, 1.05] AND source-view depth > 0; mask shape is [B, 1, H, W].

**Validates: Requirements 5.1, 5.2, 5.4**
"""

from __future__ import annotations

import torch
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from sharp.training.camera import ViewCameras
from sharp.training.masking import ViewMasker


# ---------------------------------------------------------------------------
# Hypothesis strategies
# ---------------------------------------------------------------------------

# Small spatial dims suitable for CPU property tests
dims_strategy = st.integers(min_value=4, max_value=16)


@st.composite
def novel_depth_strategy(draw: st.DrawFn) -> tuple[torch.Tensor, int, int, int]:
    """Generate a novel-view depth map [B, 1, H, W] with strictly positive values."""
    B = draw(st.integers(min_value=1, max_value=2))
    H = draw(dims_strategy)
    W = draw(dims_strategy)
    # Positive depths in a sensible range
    depth = torch.rand(B, 1, H, W) * 9.0 + 1.0  # [1.0, 10.0]
    return depth, B, H, W


@st.composite
def invertible_intrinsics(draw: st.DrawFn, B: int) -> torch.Tensor:
    """Generate a batch of invertible 3x3 intrinsic matrices.

    Uses a pinhole camera model: fx, fy > 0, cx, cy reasonable.
    """
    fx = draw(st.floats(min_value=50.0, max_value=500.0))
    fy = draw(st.floats(min_value=50.0, max_value=500.0))
    cx = draw(st.floats(min_value=2.0, max_value=100.0))
    cy = draw(st.floats(min_value=2.0, max_value=100.0))

    K = torch.zeros(B, 3, 3)
    K[:, 0, 0] = fx
    K[:, 1, 1] = fy
    K[:, 0, 2] = cx
    K[:, 1, 2] = cy
    K[:, 2, 2] = 1.0
    return K


@st.composite
def invertible_extrinsics(draw: st.DrawFn, B: int) -> torch.Tensor:
    """Generate a batch of invertible 4x4 extrinsic matrices (world-to-camera).

    We use small rotations + translations for numerical stability.
    """
    # Small rotation angles
    angle_x = draw(st.floats(min_value=-0.5, max_value=0.5))
    angle_y = draw(st.floats(min_value=-0.5, max_value=0.5))
    angle_z = draw(st.floats(min_value=-0.5, max_value=0.5))
    tx = draw(st.floats(min_value=-2.0, max_value=2.0))
    ty = draw(st.floats(min_value=-2.0, max_value=2.0))
    tz = draw(st.floats(min_value=-2.0, max_value=2.0))

    # Build rotation via Rodrigues-style composition
    cx_, sx = torch.cos(torch.tensor(angle_x)), torch.sin(torch.tensor(angle_x))
    cy_, sy = torch.cos(torch.tensor(angle_y)), torch.sin(torch.tensor(angle_y))
    cz_, sz = torch.cos(torch.tensor(angle_z)), torch.sin(torch.tensor(angle_z))

    Rx = torch.tensor([[1, 0, 0], [0, cx_, -sx], [0, sx, cx_]], dtype=torch.float32)
    Ry = torch.tensor([[cy_, 0, sy], [0, 1, 0], [-sy, 0, cy_]], dtype=torch.float32)
    Rz = torch.tensor([[cz_, -sz, 0], [sz, cz_, 0], [0, 0, 1]], dtype=torch.float32)

    R = Rz @ Ry @ Rx  # [3, 3]

    E = torch.eye(4).unsqueeze(0).expand(B, -1, -1).clone()
    E[:, :3, :3] = R
    E[:, 0, 3] = tx
    E[:, 1, 3] = ty
    E[:, 2, 3] = tz
    return E


@st.composite
def camera_pair_strategy(draw: st.DrawFn, B: int) -> ViewCameras:
    """Generate a valid pair of source and target cameras."""
    k_src = draw(invertible_intrinsics(B))
    e_src = draw(invertible_extrinsics(B))
    k_tgt = draw(invertible_intrinsics(B))
    e_tgt = draw(invertible_extrinsics(B))
    return ViewCameras(k_src=k_src, e_src=e_src, k_tgt=k_tgt, e_tgt=e_tgt)


# ---------------------------------------------------------------------------
# Reference implementation (independent of ViewMasker)
# ---------------------------------------------------------------------------

def compute_expected_mask(
    novel_depth: torch.Tensor,
    cams: ViewCameras,
) -> torch.Tensor:
    """Independently compute the expected mask by replicating the math.

    Steps:
    1. Build pixel grid for novel view
    2. Unproject to 3D in target camera space using Ktgt^-1 and depth
    3. Transform to source camera space via Esrc @ Etgt^-1
    4. Project into source pixel coords via Ksrc
    5. Normalize coords and check bounds [-1.05, 1.05]
    6. Check source depth > 0
    """
    B, _, H, W = novel_depth.shape

    # Pixel grid
    v_coords, u_coords = torch.meshgrid(
        torch.arange(H, dtype=torch.float32),
        torch.arange(W, dtype=torch.float32),
        indexing="ij",
    )
    pixels = torch.stack([u_coords, v_coords, torch.ones_like(u_coords)], dim=-1)  # [H, W, 3]
    pixels_flat = pixels.reshape(-1, 3).T  # [3, H*W]

    # Unproject: rays = Ktgt^-1 @ pixels, points = depth * rays
    k_tgt_inv = torch.inverse(cams.k_tgt)  # [B, 3, 3]
    rays = k_tgt_inv @ pixels_flat.unsqueeze(0).expand(B, -1, -1)  # [B, 3, H*W]
    depth_flat = novel_depth.reshape(B, 1, H * W)  # [B, 1, H*W]
    points_tgt = rays * depth_flat  # [B, 3, H*W]

    # Transform to source camera space: T = Esrc @ Etgt^-1
    e_tgt_inv = torch.inverse(cams.e_tgt)  # [B, 4, 4]
    T = cams.e_src @ e_tgt_inv  # [B, 4, 4]

    # Homogeneous points
    ones_row = torch.ones(B, 1, H * W)
    points_tgt_hom = torch.cat([points_tgt, ones_row], dim=1)  # [B, 4, H*W]

    # Apply transform
    points_src = T @ points_tgt_hom  # [B, 4, H*W]
    points_src_3d = points_src[:, :3, :]  # [B, 3, H*W]

    # Source depth
    src_depth = points_src_3d[:, 2:3, :]  # [B, 1, H*W]

    # Project into source pixel coords
    projected = cams.k_src @ points_src_3d  # [B, 3, H*W]

    # Normalize pixel coords
    eps = 1e-8
    safe_z = projected[:, 2:3, :].clamp(min=eps)
    u_src = projected[:, 0:1, :] / safe_z
    v_src = projected[:, 1:2, :] / safe_z

    # Convert to normalized coordinates [-1, 1]
    norm_x = 2.0 * u_src / (W - 1) - 1.0
    norm_y = 2.0 * v_src / (H - 1) - 1.0

    # Mask conditions
    bound = 1.05
    in_bounds_x = (norm_x >= -bound) & (norm_x <= bound)
    in_bounds_y = (norm_y >= -bound) & (norm_y <= bound)
    positive_depth = src_depth > 0.0

    mask = (in_bounds_x & in_bounds_y & positive_depth).float()
    return mask.reshape(B, 1, H, W)


# ---------------------------------------------------------------------------
# Property tests
# ---------------------------------------------------------------------------


class TestViewMaskIndicator:
    """Property 5: View mask is exactly the in-frustum, positive-depth indicator."""

    @given(data=st.data())
    @settings(max_examples=100)
    def test_mask_matches_reference(self, data: st.DataObject) -> None:
        """The ViewMasker mask equals 1 iff source-view normalized coords in
        [-1.05, 1.05] and source-view depth > 0, and 0 otherwise."""
        depth_data = data.draw(novel_depth_strategy())
        novel_depth, B, H, W = depth_data

        cams = data.draw(camera_pair_strategy(B))

        # Ensure matrices are invertible
        assume(torch.linalg.det(cams.k_tgt).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.k_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_tgt).abs().min() > 1e-3)

        masker = ViewMasker()
        actual_mask = masker.compute(novel_depth, cams)
        expected_mask = compute_expected_mask(novel_depth, cams)

        # Assert masks match exactly (both are in {0, 1})
        assert torch.allclose(actual_mask, expected_mask, atol=1e-6), (
            f"Mask mismatch: max diff = {(actual_mask - expected_mask).abs().max().item()}"
        )

    @given(data=st.data())
    @settings(max_examples=100)
    def test_mask_shape(self, data: st.DataObject) -> None:
        """Mask shape is [B, 1, H, W] matching novel_depth spatial dims."""
        depth_data = data.draw(novel_depth_strategy())
        novel_depth, B, H, W = depth_data

        cams = data.draw(camera_pair_strategy(B))
        assume(torch.linalg.det(cams.k_tgt).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.k_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_tgt).abs().min() > 1e-3)

        masker = ViewMasker()
        mask = masker.compute(novel_depth, cams)

        assert mask.shape == (B, 1, H, W), (
            f"Expected shape {(B, 1, H, W)}, got {mask.shape}"
        )

    @given(data=st.data())
    @settings(max_examples=50)
    def test_zero_depth_yields_zero_mask(self, data: st.DataObject) -> None:
        """Edge case: all-zero depth produces all-zero mask (depth > 0 fails)."""
        B = data.draw(st.integers(min_value=1, max_value=2))
        H = data.draw(dims_strategy)
        W = data.draw(dims_strategy)

        novel_depth = torch.zeros(B, 1, H, W)

        cams = data.draw(camera_pair_strategy(B))
        assume(torch.linalg.det(cams.k_tgt).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.k_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_tgt).abs().min() > 1e-3)

        masker = ViewMasker()
        mask = masker.compute(novel_depth, cams)

        # With zero depth, the unprojected 3D points are at origin in target space.
        # After transform, source depth will be the z of the transformed origin.
        # This test checks that when novel_depth=0, the masker computes consistently
        # with the reference: the points have zero magnitude before transform,
        # so source_depth = T[2,:3] @ [0,0,0] + T[2,3] which may be positive or not.
        # But the key condition is: depth * rays = 0, so points are at origin.
        # After T transform: source z = T[:, 2, 3] (the translation z component).
        # If that's > 0, mask could still be 1 if in bounds. But norm coords from 0-pts
        # projected: Ksrc @ [0,0,0]^T = [0,0,0]^T, which divides to 0/eps -> 0.
        # norm_x = 2*0/(W-1) - 1 = -1, similarly norm_y = -1. Both within [-1.05, 1.05].
        # So the mask depends on whether source depth (T[2,3]) > 0.
        # This is camera-dependent; validate against our reference instead.
        expected_mask = compute_expected_mask(novel_depth, cams)
        assert torch.allclose(mask, expected_mask, atol=1e-6)

    def test_identity_cameras(self) -> None:
        """Edge case: identity cameras -> all pixels map to themselves -> mask all 1."""
        B, H, W = 1, 8, 8
        novel_depth = torch.ones(B, 1, H, W) * 5.0  # positive depth

        # Identity cameras: same intrinsics, identity extrinsics
        K = torch.tensor([[[100.0, 0.0, 3.5],
                           [0.0, 100.0, 3.5],
                           [0.0, 0.0, 1.0]]])
        E = torch.eye(4).unsqueeze(0)

        cams = ViewCameras(k_src=K, e_src=E, k_tgt=K, e_tgt=E)

        masker = ViewMasker()
        mask = masker.compute(novel_depth, cams)

        # With identity transform (Esrc @ Etgt^-1 = I), points just get unprojected
        # and reprojected with same K, so pixel coords are preserved.
        # Normalized coords: 2*u/(W-1) - 1 ranges from -1 to 1, all within [-1.05, 1.05].
        # Depth is positive. So mask should be all 1.
        assert mask.shape == (B, 1, H, W)
        assert (mask == 1.0).all(), f"Expected all-ones mask with identity cameras, got sum={mask.sum()}"

    @given(data=st.data())
    @settings(max_examples=50)
    def test_mask_values_binary(self, data: st.DataObject) -> None:
        """Mask values are exactly 0 or 1 (binary indicator)."""
        depth_data = data.draw(novel_depth_strategy())
        novel_depth, B, H, W = depth_data

        cams = data.draw(camera_pair_strategy(B))
        assume(torch.linalg.det(cams.k_tgt).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.k_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_src).abs().min() > 1e-3)
        assume(torch.linalg.det(cams.e_tgt).abs().min() > 1e-3)

        masker = ViewMasker()
        mask = masker.compute(novel_depth, cams)

        # Mask should only contain 0.0 or 1.0
        assert ((mask == 0.0) | (mask == 1.0)).all(), (
            f"Mask contains non-binary values: unique = {mask.unique().tolist()}"
        )
