"""Property-based tests for finite gradients after backward.

# Feature: sharp-training-framework, Property 2

For licensing see accompanying LICENSE file.
Copyright (C) 2025 Apple Inc. All Rights Reserved.
"""

from __future__ import annotations

import pytest
import torch
from hypothesis import given, settings
from hypothesis import strategies as st
from torch import nn

from sharp.training.aggregator import LossAggregator
from sharp.training.camera import CameraModule, ViewCameras
from sharp.training.forward import TrainingForward, TrainingOutputs
from sharp.training.losses.alpha import AlphaLoss
from sharp.training.losses.color import ColorLoss
from sharp.training.masking import ViewMasker, masked_mean
from sharp.training.step import TrainingSample, training_step
from sharp.training.types import LossContext, RenderTrainOutputs
from sharp.utils.gaussians import Gaussians3D

# Import the stub predictor builder from test_forward
from tests.training.test_forward import _build_stub_predictor, _H, _W


# ---------------------------------------------------------------------------
# Mock renderer that passes gradients through (CPU-compatible).
# Returns tensors derived from Gaussian inputs so the autograd graph is
# connected from renderer outputs back to the predictor parameters.
# ---------------------------------------------------------------------------


class MockRendererTrainOutputs:
    """Mimics RenderTrainOutputs for the mock renderer."""

    def __init__(
        self, color: torch.Tensor, depth: torch.Tensor, alpha: torch.Tensor, meta: dict
    ) -> None:
        self.color = color
        self.depth = depth
        self.alpha = alpha
        self.meta = meta


class MockRenderer:
    """A gradient-passing mock renderer for CPU testing.

    Produces color/depth/alpha tensors that are differentiable functions of
    the Gaussian parameters (mean_vectors, colors, opacities), ensuring
    gradients flow through during backward.
    """

    def forward_train(
        self,
        gaussians: Gaussians3D,
        extrinsics: torch.Tensor,
        intrinsics: torch.Tensor,
        image_width: int,
        image_height: int,
    ) -> RenderTrainOutputs:
        """Produce gradient-connected render outputs from Gaussians.

        The outputs are simple differentiable functions of the Gaussian fields,
        not actual rasterization, but they preserve the autograd graph so that
        backward() will produce gradients on all contributing parameters.
        """
        B = gaussians.mean_vectors.shape[0]
        device = gaussians.mean_vectors.device
        dtype = gaussians.mean_vectors.dtype

        # Derive color from gaussian colors: average over all Gaussians then
        # expand to image dims [B, 3, H, W]
        avg_color = gaussians.colors.mean(dim=1)  # [B, 3]
        color = avg_color[:, :, None, None].expand(B, 3, image_height, image_width)
        # Add a contribution from mean_vectors to ensure mean grads flow
        mean_contrib = gaussians.mean_vectors.mean(dim=1).sum(dim=-1)  # [B]
        color = color + mean_contrib[:, None, None, None] * 0.001

        # Derive depth: function of mean_vectors z-component
        avg_z = gaussians.mean_vectors[:, :, 2].mean(dim=1)  # [B]
        depth = (avg_z[:, None, None, None].abs() + 0.5).expand(B, 1, image_height, image_width)

        # Derive alpha: function of opacities (sigmoid of mean to ensure (0,1))
        avg_opacity = gaussians.opacities.mean(dim=1)  # [B]
        alpha_val = torch.sigmoid(avg_opacity)
        alpha = alpha_val[:, None, None, None].expand(B, 1, image_height, image_width)
        # Add singular_values contribution for full gradient coverage
        sv_contrib = gaussians.singular_values.mean()
        alpha = alpha + sv_contrib * 0.0001
        # Clamp alpha to valid range for BCE, maintaining grad
        alpha = alpha.clamp(min=1e-6, max=1.0 - 1e-6)

        # Add quaternion contribution to color for gradient coverage
        quat_contrib = gaussians.quaternions.mean()
        color = color + quat_contrib * 0.0001
        # Clamp color for safety
        color = color.clamp(min=0.0, max=1.0)

        meta = {
            "conics": torch.zeros(B, 1, 3, device=device, dtype=dtype),
            "covars2d": torch.zeros(B, 1, 2, 2, device=device, dtype=dtype),
            "depths": torch.ones(B, 1, device=device, dtype=dtype),
        }

        return RenderTrainOutputs(
            color=color,
            depth=depth,
            alpha=alpha,
            meta=meta,
        )


# ---------------------------------------------------------------------------
# Helper to build cameras for testing
# ---------------------------------------------------------------------------


def _make_cameras(batch_size: int) -> ViewCameras:
    """Build valid test cameras with identity source and slight rotation target."""
    device = torch.device("cpu")
    # Simple intrinsics (focal length = image size for simplicity)
    k = torch.eye(3, device=device).unsqueeze(0).expand(batch_size, -1, -1).clone()
    k[:, 0, 0] = _W  # fx
    k[:, 1, 1] = _H  # fy
    k[:, 0, 2] = _W / 2.0  # cx
    k[:, 1, 2] = _H / 2.0  # cy

    # Source extrinsics: identity (camera at origin looking down +Z)
    e_src = torch.eye(4, device=device).unsqueeze(0).expand(batch_size, -1, -1).clone()

    # Target extrinsics: small translation along X (so we get a valid novel view)
    e_tgt = torch.eye(4, device=device).unsqueeze(0).expand(batch_size, -1, -1).clone()
    e_tgt[:, 0, 3] = 0.1  # 0.1 unit translation along X

    return ViewCameras(
        k_src=k.clone(),
        e_src=e_src,
        k_tgt=k.clone(),
        e_tgt=e_tgt,
    )


# ---------------------------------------------------------------------------
# Property test: CPU with mock renderer
# ---------------------------------------------------------------------------


@given(
    batch_size=st.integers(min_value=1, max_value=2),
    provide_depth=st.booleans(),
)
@settings(max_examples=50)
def test_backward_finite_gradients_cpu(
    batch_size: int,
    provide_depth: bool,
) -> None:
    """Property 2: Backward produces finite gradients on all trainable parameters.

    **Validates: Requirements 2.5**

    For any Training_Sample that yields at least one Gaussian with opacity > 0.0,
    after total_loss.backward() every trainable parameter has a non-null .grad
    containing only finite values (no NaN or Inf).

    This CPU version uses a mock renderer that passes gradients through to
    verify gradient connectivity and finiteness without CUDA.
    """
    # Build the stub predictor and training forward
    predictor = _build_stub_predictor()
    predictor.train()
    training_forward = TrainingForward(predictor)

    # Zero gradients
    predictor.zero_grad()

    # Generate inputs
    image = torch.rand(batch_size, 3, _H, _W) * 0.8 + 0.1
    disparity_factor = torch.rand(batch_size) * 10 + 1.0

    depth: torch.Tensor | None = None
    if provide_depth:
        depth = torch.rand(batch_size, 1, _H, _W) * 5 + 0.1

    # --- Step 1: Training forward ---
    outputs: TrainingOutputs = training_forward(image, disparity_factor, depth=depth)
    gaussians = outputs.gaussians

    # Verify at least one Gaussian has opacity > 0
    assert (gaussians.opacities > 0.0).any(), (
        "Pre-condition: at least one Gaussian must have opacity > 0"
    )

    # --- Step 2: Mock render both views ---
    mock_renderer = MockRenderer()
    cameras = _make_cameras(batch_size)
    camera_module = CameraModule()

    input_extrinsics, input_intrinsics = camera_module.input_view(cameras)
    novel_extrinsics, novel_intrinsics = camera_module.novel_view(cameras)

    input_render = mock_renderer.forward_train(
        gaussians=gaussians,
        extrinsics=input_extrinsics,
        intrinsics=input_intrinsics,
        image_width=_W,
        image_height=_H,
    )

    novel_render = mock_renderer.forward_train(
        gaussians=gaussians,
        extrinsics=novel_extrinsics,
        intrinsics=novel_intrinsics,
        image_width=_W,
        image_height=_H,
    )

    # --- Step 3: Compute view mask ---
    view_masker = ViewMasker()
    mask = view_masker.compute(novel_render.depth, cameras)

    # --- Step 4: Build LossContext and compute losses ---
    # GT images: just random targets for loss computation
    input_gt = torch.rand(batch_size, 3, _H, _W)
    novel_gt = torch.rand(batch_size, 3, _H, _W)

    ctx = LossContext(
        input_render=input_render,
        novel_render=novel_render,
        input_gt_image=input_gt,
        novel_gt_image=novel_gt,
        mask=mask,
        gaussians=gaussians,
        aligned_depth=outputs.aligned_depth,
        disparity_pred=outputs.disparity_pred,
        scale_map=outputs.scale_map,
        base_xy_ndc=outputs.base_xy_ndc,
        monodepth_disparity=outputs.monodepth_disparity,
        cameras=cameras,
    )

    # --- Step 5: Aggregate losses (Color + Alpha) ---
    color_loss = ColorLoss(weight=1.0)
    alpha_loss = AlphaLoss(weight=1.0)
    aggregator = LossAggregator(
        modules=[color_loss, alpha_loss],
        active_names={"color", "alpha"},
    )
    result = aggregator.aggregate(ctx)

    # Verify the total loss is a valid scalar with grad_fn
    assert result.total.dim() == 0, "Total loss must be a rank-0 scalar"
    assert torch.isfinite(result.total), "Total loss must be finite before backward"
    assert result.total.requires_grad, "Total loss must require grad"
    assert result.total.grad_fn is not None, "Total loss must have a grad_fn"

    # --- Step 6: Backward ---
    result.total.backward()

    # --- Step 7: Verify finite gradients on all trainable parameters ---
    # Note: When provide_depth=False, the scale_map_estimator is not invoked
    # (the design explicitly returns scale_map=None and uses ones), so its
    # parameters legitimately receive no gradient. This is expected behavior.
    scale_map_param_prefix = "depth_alignment.scale_map_estimator"

    trainable_params_with_grad = []
    trainable_params_without_grad = []

    for name, param in predictor.named_parameters():
        if param.requires_grad:
            # Skip scale_map_estimator params when depth is not provided
            if not provide_depth and name.startswith(scale_map_param_prefix):
                continue

            if param.grad is not None:
                trainable_params_with_grad.append((name, param))
                # Check all grad values are finite (the core property assertion)
                assert torch.isfinite(param.grad).all(), (
                    f"Parameter '{name}' has non-finite gradient values "
                    f"(contains NaN or Inf)"
                )
            else:
                trainable_params_without_grad.append(name)

    # At least some trainable parameters must have received gradients
    assert len(trainable_params_with_grad) > 0, (
        "At least one trainable parameter must receive a gradient after backward. "
        f"Parameters without grad: {trainable_params_without_grad}"
    )

    # For a well-connected graph, ALL active trainable parameters should get gradients
    # (since the mock renderer is designed to touch all Gaussian fields)
    assert len(trainable_params_without_grad) == 0, (
        f"All active trainable parameters should receive gradients. "
        f"Missing gradients on: {trainable_params_without_grad}"
    )


# ---------------------------------------------------------------------------
# CUDA-gated property test with real renderer
# ---------------------------------------------------------------------------

_CUDA_AVAILABLE = torch.cuda.is_available()


@pytest.mark.skipif(not _CUDA_AVAILABLE, reason="CUDA not available")
@given(
    batch_size=st.just(1),  # Keep batch=1 for CUDA memory efficiency
    provide_depth=st.booleans(),
)
@settings(max_examples=10)  # Fewer examples for expensive CUDA tests
def test_backward_finite_gradients_cuda(
    batch_size: int,
    provide_depth: bool,
) -> None:
    """Property 2 (CUDA): Backward produces finite gradients on all trainable params.

    **Validates: Requirements 2.5**

    Same property as the CPU test but uses the real GSplatRenderer on CUDA.
    This test is skipped on hosts without CUDA.
    """
    from sharp.utils.gsplat import GSplatRenderer

    device = torch.device("cuda")

    # Build the stub predictor on CUDA
    predictor = _build_stub_predictor()
    predictor.to(device)
    predictor.train()
    training_forward = TrainingForward(predictor)

    # Zero gradients
    predictor.zero_grad()

    # Generate inputs on CUDA
    image = torch.rand(batch_size, 3, _H, _W, device=device) * 0.8 + 0.1
    disparity_factor = (torch.rand(batch_size, device=device) * 10 + 1.0)

    depth: torch.Tensor | None = None
    if provide_depth:
        depth = torch.rand(batch_size, 1, _H, _W, device=device) * 5 + 0.1

    # Training forward
    outputs: TrainingOutputs = training_forward(image, disparity_factor, depth=depth)
    gaussians = outputs.gaussians

    # Verify at least one Gaussian has opacity > 0
    assert (gaussians.opacities > 0.0).any(), (
        "Pre-condition: at least one Gaussian must have opacity > 0"
    )

    # Dual-view rendering with real renderer
    renderer = GSplatRenderer()
    cameras = _make_cameras(batch_size)
    # Move cameras to CUDA
    cameras = ViewCameras(
        k_src=cameras.k_src.to(device),
        e_src=cameras.e_src.to(device),
        k_tgt=cameras.k_tgt.to(device),
        e_tgt=cameras.e_tgt.to(device),
    )

    camera_module = CameraModule()
    input_extrinsics, input_intrinsics = camera_module.input_view(cameras)
    novel_extrinsics, novel_intrinsics = camera_module.novel_view(cameras)

    try:
        input_render = renderer.forward_train(
            gaussians=gaussians,
            extrinsics=input_extrinsics,
            intrinsics=input_intrinsics,
            image_width=_W,
            image_height=_H,
        )
        novel_render = renderer.forward_train(
            gaussians=gaussians,
            extrinsics=novel_extrinsics,
            intrinsics=novel_intrinsics,
            image_width=_W,
            image_height=_H,
        )
    except RuntimeError:
        # If the renderer fails (non-finite), skip this example
        # (Req 4.3 says we reject the sample without updating params)
        return

    # View mask
    view_masker = ViewMasker()
    mask = view_masker.compute(novel_render.depth, cameras)

    # GT images
    input_gt = torch.rand(batch_size, 3, _H, _W, device=device)
    novel_gt = torch.rand(batch_size, 3, _H, _W, device=device)

    ctx = LossContext(
        input_render=input_render,
        novel_render=novel_render,
        input_gt_image=input_gt,
        novel_gt_image=novel_gt,
        mask=mask,
        gaussians=gaussians,
        aligned_depth=outputs.aligned_depth,
        disparity_pred=outputs.disparity_pred,
        scale_map=outputs.scale_map,
        base_xy_ndc=outputs.base_xy_ndc,
        monodepth_disparity=outputs.monodepth_disparity,
        cameras=cameras,
    )

    # Aggregate losses
    color_loss = ColorLoss(weight=1.0)
    alpha_loss = AlphaLoss(weight=1.0)
    aggregator = LossAggregator(
        modules=[color_loss, alpha_loss],
        active_names={"color", "alpha"},
    )
    result = aggregator.aggregate(ctx)

    if not torch.isfinite(result.total):
        # Non-finite loss — would be rejected per Req 16.4
        return

    assert result.total.requires_grad, "Total loss must require grad"
    assert result.total.grad_fn is not None, "Total loss must have a grad_fn"

    # Backward
    result.total.backward()

    # Check all trainable parameters have finite gradients
    for name, param in predictor.named_parameters():
        if param.requires_grad:
            if param.grad is not None:
                assert torch.isfinite(param.grad).all(), (
                    f"CUDA: Parameter '{name}' has non-finite gradient values"
                )
